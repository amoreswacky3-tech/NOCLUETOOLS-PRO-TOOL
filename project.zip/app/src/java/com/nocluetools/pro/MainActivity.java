package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnRunParser;
    private boolean isAuthorized = false; // Server check status

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnRunParser = findViewById(R.id.btnRunParser);
        
        // Disable the run button until everything is checked
        btnRunParser.setEnabled(false);

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        Button btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        Button btnSelectIff = findViewById(R.id.btnSelectIff);
        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnRunParser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri == null || iffUri == null) {
                    Toast.makeText(MainActivity.this, "Please select both files first!", Toast.LENGTH_LONG).show();
                    return;
                }
                if (!isAuthorized) {
                    Toast.makeText(MainActivity.this, "Server authorization failed!", Toast.LENGTH_LONG).show();
                    return;
                }
                runPythonParser();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (requestCode == REQUEST_OBB) {
                obbUri = uri;
                tvStatus.setText("OBB selected. Backing up and inspecting...");
                processObbBackupAndInspect();
            } else if (requestCode == REQUEST_IFF) {
                iffUri = uri;
                tvStatus.setText("IFF selected. Copying...");
                try {
                    copyUriToInternalStorage(iffUri, "input.iff", true);
                    checkReadyToRun();
                } catch (Exception e) {
                    tvStatus.setText("Error copying IFF: " + e.getMessage());
                }
            }
        }
    }

    private void processObbBackupAndInspect() {
        try {
            File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
            
            Python py = Python.getInstance();
            PyObject pyModule = py.getModule("iff_viewer");
            PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
            
            String obbSummary = result.toString(); 
            tvStatus.setText(obbSummary);
            
            checkReadyToRun();
        } catch (Exception e) {
            tvStatus.setText("Error backing up OBB: " + e.getMessage());
        }
    }

    private void checkReadyToRun() {
        if (obbUri != null && iffUri != null) {
            tvStatus.setText("Files ready. Checking server authorization...");
            performServerCheck();
        }
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Simulated network delay (Replace with real server check later)
                    Thread.sleep(1500); 
                    isAuthorized = true; 
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Authorized! Ready to parse.");
                            btnRunParser.setEnabled(true);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Server connection failed.");
                        }
                    });
                }
            }
        }).start();
    }

    private void runPythonParser() {
        tvOutput.setText("Processing... Please wait.");
        try {
            File obbFile = new File(getFilesDir() + "/backups/input.obb");
            File iffFile = new File(getFilesDir() + "/backups/input.iff");

            Python py = Python.getInstance();
            PyObject pyModule = py.getModule("iff_viewer");
            PyObject result = pyModule.callAttr("run_tool", obbFile.getAbsolutePath(), iffFile.getAbsolutePath());
            
            tvOutput.setText(result.toString());
        } catch (Exception e) {
            tvOutput.setText("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        File file = new File(dir, fileName);
        
        if (isBackup && file.exists()) {
            return file; 
        }

        InputStream inputStream = getContentResolver().openInputStream(uri);
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.close();
        return file;
    }
}