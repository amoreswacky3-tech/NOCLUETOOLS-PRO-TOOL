package com.nocluetools.pro;

import android.graphics.Bitmap;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Etc2Decoder {

    private static final String TAG = "Etc2Decoder";

    // GL constants
    private static final int GL_COMPRESSED_RGB8_ETC2 = 0x9274;
    private static final int GL_COMPRESSED_RGBA8_ETC2_EAC = 0x9278;

    /**
     * Decode an ETC2 texture to a Bitmap.
     *
     * @param data      Raw ETC2 bytes (8 bytes/block for RGB, 16 bytes/block for RGBA8)
     * @param width     Texture width
     * @param height    Texture height
     * @param hasAlpha  true for ETC2 RGBA8 (format 16), false for ETC2 RGB (format 15)
     * @return          Bitmap with the correct colors
     */
    public static Bitmap decode(byte[] data, int width, int height, boolean hasAlpha) {
        EGLDisplay display = null;
        EGLSurface surface = null;
        EGLContext context = null;
        int[] textures = new int[1];
        int[] fbos = new int[1];
        int program = 0;

        try {
            // ===== 1. Setup EGL =====
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] version = new int[2];
            EGL14.eglInitialize(display, version, 0, version, 1);

            int[] configAttribs = {
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, 0x40, // EGL_OPENGL_ES3_BIT
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_NONE
            };
            EGLConfig[] configs = new EGLConfig[1];
            int[] numConfigs = new int[1];
            EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0);
            if (numConfigs[0] == 0) {
                Log.e(TAG, "No EGL config");
                return null;
            }

            // Pbuffer surface
            int[] surfaceAttribs = {
                    EGL14.EGL_WIDTH, width,
                    EGL14.EGL_HEIGHT, height,
                    EGL14.EGL_NONE
            };
            surface = EGL14.eglCreatePbufferSurface(display, configs[0], surfaceAttribs, 0);

            int[] contextAttribs = {
                    EGL14.EGL_CONTEXT_CLIENT_VERSION, 3,
                    EGL14.EGL_NONE
            };
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0);

            if (!EGL14.eglMakeCurrent(display, surface, surface, context)) {
                Log.e(TAG, "eglMakeCurrent failed");
                return null;
            }

            // ===== 2. Upload ETC2 compressed texture =====
            GLES30.glGenTextures(1, textures, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            ByteBuffer dataBuffer = ByteBuffer.allocateDirect(data.length);
            dataBuffer.order(ByteOrder.nativeOrder());
            dataBuffer.put(data);
            dataBuffer.position(0);

            int glFormat = hasAlpha ? GL_COMPRESSED_RGBA8_ETC2_EAC : GL_COMPRESSED_RGB8_ETC2;
            GLES30.glCompressedTexImage2D(
                    GLES30.GL_TEXTURE_2D,
                    0,
                    glFormat,
                    width,
                    height,
                    0,
                    data.length,
                    dataBuffer
            );

            int err = GLES30.glGetError();
            if (err != GLES30.GL_NO_ERROR) {
                Log.e(TAG, "glCompressedTexImage2D error: " + err);
                return null;
            }

            // ===== 3. Create FBO =====
            GLES30.glGenFramebuffers(1, fbos, 0);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbos[0]);
            GLES30.glFramebufferTexture2D(
                    GLES30.GL_FRAMEBUFFER,
                    GLES30.GL_COLOR_ATTACHMENT0,
                    GLES30.GL_TEXTURE_2D,
                    textures[0],
                    0
            );
            int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
            if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
                Log.e(TAG, "FBO incomplete: " + status);
                return null;
            }

            // ===== 4. Fullscreen quad shader =====
            String vertexSrc =
                    "attribute vec2 aPos;\n" +
                    "varying vec2 vTexCoord;\n" +
                    "void main() {\n" +
                    "    gl_Position = vec4(aPos, 0.0, 1.0);\n" +
                    "    vTexCoord = vec2((aPos.x + 1.0) * 0.5, (aPos.y + 1.0) * 0.5);\n" +
                    "}\n";

            String fragmentSrc =
                    "#extension GL_OES_EGL_image_external_essl3 : enable\n" +
                    "precision mediump float;\n" +
                    "uniform sampler2D uTexture;\n" +
                    "varying vec2 vTexCoord;\n" +
                    "void main() {\n" +
                    "    gl_FragColor = texture2D(uTexture, vTexCoord);\n" +
                    "}\n";

            int vShader = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER);
            GLES30.glShaderSource(vShader, vertexSrc);
            GLES30.glCompileShader(vShader);

            int fShader = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER);
            GLES30.glShaderSource(fShader, fragmentSrc);
            GLES30.glCompileShader(fShader);

            program = GLES30.glCreateProgram();
            GLES30.glAttachShader(program, vShader);
            GLES30.glAttachShader(program, fShader);
            GLES30.glLinkProgram(program);
            GLES30.glUseProgram(program);

            // Quad vertices
            float[] quad = {
                    -1f, -1f,
                     1f, -1f,
                    -1f,  1f,
                     1f,  1f
            };
            FloatBuffer quadBuf = ByteBuffer.allocateDirect(quad.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            quadBuf.put(quad);
            quadBuf.position(0);

            int aPosLoc = GLES30.glGetAttribLocation(program, "aPos");
            GLES30.glEnableVertexAttribArray(aPosLoc);
            GLES30.glVertexAttribPointer(aPosLoc, 2, GLES30.GL_FLOAT, false, 0, quadBuf);

            // Bind ETC2 texture to unit 0
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0]);
            int uTexLoc = GLES30.glGetUniformLocation(program, "uTexture");
            GLES30.glUniform1i(uTexLoc, 0);

            // ===== 5. Render =====
            GLES30.glViewport(0, 0, width, height);
            GLES30.glClearColor(0f, 0f, 0f, 0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);

            // ===== 6. Read pixels =====
            ByteBuffer pixels = ByteBuffer.allocateDirect(width * height * 4);
            pixels.order(ByteOrder.nativeOrder());
            GLES30.glReadPixels(0, 0, width, height, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, pixels);

            // ===== 7. Convert to Bitmap (flip Y) =====
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            int[] row = new int[width];

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int idx = ((height - 1 - y) * width + x) * 4;
                    int r = pixels.get(idx) & 0xFF;
                    int g = pixels.get(idx + 1) & 0xFF;
                    int b = pixels.get(idx + 2) & 0xFF;
                    int a = pixels.get(idx + 3) & 0xFF;
                    row[x] = (a << 24) | (r << 16) | (g << 8) | b;
                }
                bitmap.setPixels(row, 0, width, 0, y, width, 1);
            }

            return bitmap;

        } catch (Exception e) {
            Log.e(TAG, "Decode failed: " + e.getMessage(), e);
            return null;
        } finally {
            // Cleanup
            try {
                if (fbos[0] != 0) GLES30.glDeleteFramebuffers(1, fbos, 0);
                if (textures[0] != 0) GLES30.glDeleteTextures(1, textures, 0);
                if (program != 0) GLES30.glDeleteProgram(program);
                if (display != null) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                    if (surface != null) EGL14.eglDestroySurface(display, surface);
                    if (context != null) EGL14.eglDestroyContext(display, context);
                    EGL14.eglTerminate(display);
                }
            } catch (Exception ignored) {}
        }
    }
}