package com.nocluetools.pro;

import android.graphics.Bitmap;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES30;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Etc2Decoder {

    private static final String TAG = "Etc2Decoder";
    private static final int GL_COMPRESSED_RGB8_ETC2      = 0x9274;
    private static final int GL_COMPRESSED_RGBA8_ETC2_EAC = 0x9278;

    public static String lastError = "";
    public static Bitmap decode(byte[] data, int width, int height, boolean hasAlpha) {
        if (data == null || data.length == 0) { Log.e(TAG, "null/empty data"); return null; }
        if (width <= 0 || height <= 0)        { Log.e(TAG, "bad dims " + width + "x" + height); return null; }

        int blocksX = (width + 3) / 4, blocksY = (height + 3) / 4;
        int expectedLen = blocksX * blocksY * (hasAlpha ? 16 : 8);
        if (data.length < expectedLen) {
            Log.e(TAG, "data too small: got " + data.length + " need " + expectedLen
                    + " (" + width + "x" + height + " alpha=" + hasAlpha + ")");
            return null;
        }

        EGLDisplay display = null;
        EGLSurface surface = null;
        EGLContext context = null;
        int[] textures = new int[1], fbos = new int[1];
        int program = 0, vShader = 0, fShader = 0;

        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] version = new int[2];
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) {
                Log.e(TAG, "eglInitialize failed"); return null;
            }

            // ✅ Fixed: only ONE renderable_type, ES3 (ETC2 is ES3 core)
            int[] configAttribs = {
                    EGL14.EGL_RENDERABLE_TYPE, 0x0040, // EGL_OPENGL_ES3_BIT_KHR
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_NONE
            };
            EGLConfig[] configs = new EGLConfig[1];
            int[] numConfigs = new int[1];
            if (!EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0)
                    || numConfigs[0] == 0) {
                Log.e(TAG, "no ES3 config"); return null;
            }

            int[] surfaceAttribs = {
                    EGL14.EGL_WIDTH, width, EGL14.EGL_HEIGHT, height, EGL14.EGL_NONE
            };
            surface = EGL14.eglCreatePbufferSurface(display, configs[0], surfaceAttribs, 0);
            if (surface == null || surface == EGL14.EGL_NO_SURFACE) {
                Log.e(TAG, "pbuffer failed"); return null;
            }

            int[] contextAttribs = { EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE };
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0);
            if (context == null || context == EGL14.EGL_NO_CONTEXT) {
                Log.e(TAG, "ES3 context failed"); return null;
            }
            if (!EGL14.eglMakeCurrent(display, surface, surface, context)) {
                Log.e(TAG, "eglMakeCurrent failed"); return null;
            }

            GLES30.glGenTextures(1, textures, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            ByteBuffer dataBuffer = ByteBuffer.allocateDirect(data.length);
            dataBuffer.order(ByteOrder.nativeOrder());
            dataBuffer.put(data);
            dataBuffer.position(0);

            int glFormat = hasAlpha ? GL_COMPRESSED_RGBA8_ETC2_EAC : GL_COMPRESSED_RGB8_ETC2;

            while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* clear */ }

            GLES30.glCompressedTexImage2D(GLES30.GL_TEXTURE_2D, 0, glFormat,
                    width, height, 0, data.length, dataBuffer);

            int err = GLES30.glGetError();
            if (err != GLES30.GL_NO_ERROR) {
                Log.e(TAG, "glCompressedTexImage2D err=0x" + Integer.toHexString(err)
                        + " fmt=0x" + Integer.toHexString(glFormat)
                        + " w=" + width + " h=" + height + " len=" + data.length
                        + " alpha=" + hasAlpha);
                return null;
            }

            GLES30.glGenFramebuffers(1, fbos, 0);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbos[0]);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                    GLES30.GL_TEXTURE_2D, textures[0], 0);
            int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
            if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
                Log.e(TAG, "FBO incomplete 0x" + Integer.toHexString(status)); return null;
            }

            // ✅ Fixed: proper ES3 shaders, no bogus extension
            String vertexSrc =
                    "#version 300 es\n" +
                    "in vec2 aPos;\n" +
                    "out vec2 vTexCoord;\n" +
                    "void main() {\n" +
                    "    gl_Position = vec4(aPos, 0.0, 1.0);\n" +
                    "    vTexCoord = vec2((aPos.x + 1.0) * 0.5, (aPos.y + 1.0) * 0.5);\n" +
                    "}\n";

            String fragmentSrc =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "uniform sampler2D uTexture;\n" +
                    "in vec2 vTexCoord;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    fragColor = texture(uTexture, vTexCoord);\n" +
                    "}\n";

            vShader = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER);
            GLES30.glShaderSource(vShader, vertexSrc);
            GLES30.glCompileShader(vShader);
            if (!checkShader(vShader, "vertex")) return null;

            fShader = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER);
            GLES30.glShaderSource(fShader, fragmentSrc);
            GLES30.glCompileShader(fShader);
            if (!checkShader(fShader, "fragment")) return null;

            program = GLES30.glCreateProgram();
            GLES30.glAttachShader(program, vShader);
            GLES30.glAttachShader(program, fShader);
            GLES30.glLinkProgram(program);
            int[] linked = new int[1];
            GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linked, 0);
            if (linked[0] == 0) {
                Log.e(TAG, "link failed: " + GLES30.glGetProgramInfoLog(program));
                return null;
            }
            GLES30.glUseProgram(program);

            float[] quad = { -1f,-1f,  1f,-1f,  -1f,1f,  1f,1f };
            FloatBuffer quadBuf = ByteBuffer.allocateDirect(quad.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            quadBuf.put(quad);
            quadBuf.position(0);

            int aPosLoc = GLES30.glGetAttribLocation(program, "aPos");
            GLES30.glEnableVertexAttribArray(aPosLoc);
            GLES30.glVertexAttribPointer(aPosLoc, 2, GLES30.GL_FLOAT, false, 0, quadBuf);

            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0]);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uTexture"), 0);

            GLES30.glViewport(0, 0, width, height);
            GLES30.glClearColor(0f, 0f, 0f, 0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);

            ByteBuffer pixels = ByteBuffer.allocateDirect(width * height * 4);
            pixels.order(ByteOrder.nativeOrder());
            GLES30.glReadPixels(0, 0, width, height, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, pixels);
            pixels.position(0);

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            int[] row = new int[width];
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int idx = ((height - 1 - y) * width + x) * 4;
                    int r = pixels.get(idx) & 0xFF;
                    int g = pixels.get(idx + 1) & 0xFF;
                    int b = pixels.get(idx + 2) & 0xFF;
                    int a = pixels.get(idx + 3) & 0xFF;
                    row[x] = (a << 24) | (r << 16) | (g << 8) | b;
                }
                bitmap.setPixels(row, 0, width, 0, y, width, 1);
            }
            return bitmap;

        } catch (Exception e) {
            Log.e(TAG, "decode failed: " + e, e);
            return null;
        } finally {
            try {
                if (fbos[0] != 0) GLES30.glDeleteFramebuffers(1, fbos, 0);
                if (textures[0] != 0) GLES30.glDeleteTextures(1, textures, 0);
                if (program != 0) GLES30.glDeleteProgram(program);
                if (vShader != 0) GLES30.glDeleteShader(vShader);
                if (fShader != 0) GLES30.glDeleteShader(fShader);
                if (display != null) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                    if (surface != null) EGL14.eglDestroySurface(display, surface);
                    if (context != null) EGL14.eglDestroyContext(display, context);
                    EGL14.eglTerminate(display);
                }
            } catch (Exception ignored) {}
        }
    }

    private static boolean checkShader(int shader, String label) {
        int[] ok = new int[1];
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, label + " shader failed: " + GLES30.glGetShaderInfoLog(shader));
            return false;
        }
        return true;
    }
}