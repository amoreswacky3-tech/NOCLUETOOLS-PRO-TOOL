package com.nocluetools.pro;

import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * Writes modifications back to an IFF file.
 * Mode A (default): offset-based byte patches, same-size only.
 */
public final class IffRewriter {

    private static final String TAG = "IffRewriter";

    public static final class Patch {
        public final long offset;
        public final byte[] data;
        public Patch(long offset, byte[] data) {
            this.offset = offset;
            this.data   = data;
        }
    }

    /**
     * Copies src IFF to dst, applying byte-range patches.
     * Each patch overwrites [offset .. offset+data.length).
     * Total file size unchanged.
     */
    public static void saveWithPatches(File src, File dst, List<Patch> patches)
            throws IOException {

        if (patches == null) patches = new ArrayList<>();

        long srcLen = src.length();
        for (Patch p : patches) {
            if (p.offset < 0 || p.offset + p.data.length > srcLen) {
                throw new IOException("Patch out of range: offset=" + p.offset
                        + " len=" + p.data.length + " fileLen=" + srcLen);
            }
        }

        try (RandomAccessFile in = new RandomAccessFile(src, "r");
             FileOutputStream out = new FileOutputStream(dst)) {

            byte[] buf = new byte[1 << 16];
            long written = 0;
            int patchIdx = 0;

            patches.sort((a, b) -> Long.compare(a.offset, b.offset));

            while (written < srcLen) {
                long nextPatchStart = (patchIdx < patches.size())
                        ? patches.get(patchIdx).offset
                        : Long.MAX_VALUE;

                if (written == nextPatchStart) {
                    Patch p = patches.get(patchIdx);
                    out.write(p.data);
                    written += p.data.length;
                    patchIdx++;
                } else {
                    long chunk = Math.min(buf.length, srcLen - written);
                    if (nextPatchStart > written) {
                        chunk = Math.min(chunk, nextPatchStart - written);
                    }
                    int r = in.read(buf, 0, (int) chunk);
                    if (r < 0) break;
                    out.write(buf, 0, r);
                    written += r;
                }
            }
        }
        Log.d(TAG, "Wrote IFF: " + dst.getAbsolutePath()
                + " (" + dst.length() + " bytes, " + patches.size() + " patches)");
    }

    /** Convenience: write raw bytes as a new IFF. */
    public static void writeRaw(File dst, byte[] data) throws IOException {
        try (FileOutputStream out = new FileOutputStream(dst)) {
            out.write(data);
        }
        Log.d(TAG, "Wrote IFF (raw): " + dst.getAbsolutePath()
                + " (" + data.length + " bytes)");
    }

    private IffRewriter() { }
}