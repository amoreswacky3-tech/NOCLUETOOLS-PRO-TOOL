package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnExportIff;
    private Button btnAudio;
    private ProgressBar progressBar;
    private ArrayAdapter<String> listAdapter;
    private final List<Integer> fileIndices = new ArrayList<>();

    private android.app.AlertDialog textureDialog;
    private android.app.AlertDialog audioDialog;
    private android.app.AlertDialog fileListDialog;
    private android.media.MediaPlayer mediaPlayer;
    private ImageView popupImage;
    private TextView popupTitle, popupInfo, popupFormat;
    private ListView popupFileList;
    private File currentIffFile;
    private int currentTextureIndex = 0;
    private int totalTextures = 0;
    private JSONArray currentTextureList;

    private boolean isAuthorized = false;
    private int selectedIffIndex = 0;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;
    private static final int EXPORT_PNG_REQUEST = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnExportIff = findViewById(R.id.btnExportIff);
        btnAudio = findViewById(R.id.btnAudio);
        progressBar = findViewById(R.id.progressBar);

        tvOutput.setText("");
        updateUIState("PROCESSING");

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri == null) {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                    return;
                }
                openAudioScanner();
            }
        });

        btnExportIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri != null) {
                    askUserWhereToSave();
                } else {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("● Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            btnAudio.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("● Hello Master! Ready.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnExportIff.setEnabled(true);
            btnAudio.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("● This app is cloned or modded.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            btnAudio.setEnabled(false);
            tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }
    
private void showProgress() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setIndeterminate(true);
        }
    });
}

private void updateProgressBar(int percent) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(percent);
        }
    });
}

private void hideProgress() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setVisibility(View.GONE);
        }
    });
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && data != null) {
        final Uri uri = data.getData();
        if (requestCode == REQUEST_OBB) {
            obbUri = uri;
            tvStatus.setText("● OBB selected. Backing up...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            processObbBackupAndInspect();
        } else if (requestCode == REQUEST_IFF) {
            iffUri = uri;
            tvStatus.setText("● IFF selected. Copying...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        showProgress();
                        File copied = copyUriToInternalStorage(iffUri, "standalone.iff", true);
                        hideProgress();
                        final File f = copied;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                openTexturePopup(f);
                            }
                        });
                    } catch (Exception e) {
                        hideProgress();
                        final String error = e.getMessage();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Error: " + error);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                }
            }).start();
        } else if (requestCode == CREATE_FILE_REQUEST) {
            exportIffToFile(uri);
        } else if (requestCode == EXPORT_PNG_REQUEST) {
            savePopupPng(uri);
        }
    }
}

private void processObbBackupAndInspect() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Backup complete. Loading file list...");
                        tvStatus.setTextColor(Color.parseColor("#FF9800"));
                    }
                });

                Python py = Python.getInstance();
                PyObject pyModule = py.getModule("iff_viewer");
                PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                final String obbSummary = result.toString();

                PyObject listResult = pyModule.callAttr("get_file_list_from_java", obbFile.getAbsolutePath());
                final String listJson = listResult.toString();
                hideProgress();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvOutput.setText(obbSummary);
                        showFileListDialog(listJson);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void showFileListDialog(String jsonString) {
    try {
        if (jsonString.startsWith("ERROR:")) {
            tvStatus.setText("● " + jsonString);
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            return;
        }

        final JSONArray arr = new JSONArray(jsonString);
        final ArrayList<Integer> indices = new ArrayList<>();
        final ArrayList<String> labels = new ArrayList<>();

        int knownCount = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            int index = obj.getInt("index");
            String name = obj.getString("name");
            String type = obj.getString("type");
            boolean editable = obj.getBoolean("editable");
            String prefix = editable ? "▶ " : "  ";
            labels.add(prefix + "[" + index + "] " + name + "  (" + type + ")");
            indices.add(index);
            if (!name.matches("^[0-9a-f]{8}$")) knownCount++;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextColor(Color.parseColor("#DDDDDD"));
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_file_list, null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.fileListTitle);
        title.setText("FILES IN OBB (" + arr.length() + ")");

        popupFileList = view.findViewById(R.id.fileList);
        popupFileList.setAdapter(adapter);

        popupFileList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedIffIndex = indices.get(position);
                if (fileListDialog != null && fileListDialog.isShowing()) {
                    fileListDialog.dismiss();
                }
                autoPreviewFromObb();
            }
        });

        view.findViewById(R.id.fileListClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fileListDialog.dismiss();
            }
        });

        fileListDialog = builder.create();
        fileListDialog.show();

        android.view.Window window = fileListDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }

        tvStatus.setText("● Loaded " + arr.length() + " files (" + knownCount + " named)");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        tvStatus.setText("● List error: " + e.getMessage());
        tvStatus.setTextColor(Color.parseColor("#FF0000"));
    }
}

private void autoPreviewFromObb() {
    tvStatus.setText("● Loading texture " + selectedIffIndex + "...");
    tvStatus.setTextColor(Color.parseColor("#FF9800"));
    showProgress();

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File tempIff = new File(getCacheDir(), "preview_source.iff");

                Python py = Python.getInstance();
                PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");
                PyObject exportResult = obbModule.callAttr("export_iff_from_java",
                        obbFile.getAbsolutePath(), selectedIffIndex, tempIff.getAbsolutePath());

                hideProgress();

                if (!exportResult.toString().startsWith("Success")) {
                    final String err = exportResult.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● " + err);
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                    return;
                }

                final File f = tempIff;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        openTexturePopup(f);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Preview Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void openTexturePopup(File iffFile) {
    if (textureDialog != null && textureDialog.isShowing()) {
        textureDialog.dismiss();
    }

    try {
        Python py = Python.getInstance();
        PyObject viewerModule = py.getModule("iff_viewer");
        PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
        String listJson = result.toString();

        if (listJson.startsWith("ERROR")) {
            Toast.makeText(this, listJson, Toast.LENGTH_LONG).show();
            return;
        }

        currentTextureList = new JSONArray(listJson);
        if (currentTextureList.length() == 0) {
            Toast.makeText(this, "No textures in this IFF", Toast.LENGTH_LONG).show();
            return;
        }

        currentIffFile = iffFile;
        currentTextureIndex = 0;
        totalTextures = currentTextureList.length();

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_viewer, null);
        builder.setView(view);

        popupTitle = view.findViewById(R.id.popupTitle);
        popupInfo = view.findViewById(R.id.popupInfo);
        popupImage = view.findViewById(R.id.popupImage);
        popupFormat = view.findViewById(R.id.popupFormat);

        Button btnPrev = view.findViewById(R.id.popupPrev);
        Button btnNext = view.findViewById(R.id.popupNext);
        Button btnClose = view.findViewById(R.id.popupClose);
        Button btnExport = view.findViewById(R.id.popupExport);
        Button btnReplace = view.findViewById(R.id.popupReplace);

        popupTitle.setText(iffFile.getName());

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex > 0) {
                    currentTextureIndex--;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex < totalTextures - 1) {
                    currentTextureIndex++;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureDialog.dismiss();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPopupTexture();
            }
        });

        btnReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_LONG).show();
            }
        });

        textureDialog = builder.create();
        textureDialog.show();

        android.view.Window window = textureDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }

        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Popup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadCurrentPopupTexture() {
    popupInfo.setText("Texture " + (currentTextureIndex + 1) + " of " + totalTextures);
    popupFormat.setText("Loading...");
    popupFormat.setTextColor(Color.parseColor("#FF9800"));
    popupImage.setImageBitmap(null);

    final String pngName = "popup_" + System.currentTimeMillis() + ".png";

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File pngFile = new File(getCacheDir(), pngName);
                if (pngFile.exists()) pngFile.delete();

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("decode_texture_by_index_from_java",
                        currentIffFile.getAbsolutePath(), currentTextureIndex, pngFile.getAbsolutePath());
                String status = result.toString();

                final Bitmap bmp = status.startsWith("Success") ? BitmapFactory.decodeFile(pngFile.getAbsolutePath()) : null;
                final String finalStatus = status;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bmp != null) {
                            popupImage.setImageBitmap(bmp);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#00FF00"));
                        } else {
                            popupImage.setImageBitmap(null);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#FF0000"));
                        }
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        popupFormat.setText("Error: " + e.getMessage());
                        popupFormat.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

    private void exportCurrentPopupTexture() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE,
                currentIffFile.getName().replace(".iff", "") + "_tex" + currentTextureIndex + ".png");
        startActivityForResult(intent, EXPORT_PNG_REQUEST);
    }

    private void savePopupPng(Uri saveUri) {
        try {
            File cacheDir = getCacheDir();
            File[] files = cacheDir.listFiles();
            File pngFile = null;
            if (files != null) {
                long newest = 0;
                for (File f : files) {
                    if (f.getName().startsWith("popup_") && f.getName().endsWith(".png")) {
                        if (f.lastModified() > newest) {
                            newest = f.lastModified();
                            pngFile = f;
                        }
                    }
                }
            }
            if (pngFile == null || !pngFile.exists()) {
                Toast.makeText(this, "No texture loaded", Toast.LENGTH_SHORT).show();
                return;
            }
            InputStream is = new FileInputStream(pngFile);
            OutputStream os = getContentResolver().openOutputStream(saveUri);
            if (os != null) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
            }
            is.close();
            Toast.makeText(this, "Exported to PNG", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("● Exporting IFF index " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempOutput.getAbsolutePath());

                    String resultString = result.toString();

                    if (resultString.startsWith("Success")) {
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();
                        hideProgress();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Export complete!");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        hideProgress();
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void openAudioScanner() {
        tvStatus.setText("● Scanning OBB for audio...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    Python py = Python.getInstance();
                    PyObject viewerModule = py.getModule("iff_viewer");
                    PyObject result = viewerModule.callAttr("list_audio_from_java", obbFile.getAbsolutePath());
                    final String jsonList = result.toString();

                    hideProgress();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAudioListDialog(jsonList);
                        }
                    });
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Audio scan error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void showAudioListDialog(String jsonList) {
        try {
            if (jsonList.startsWith("ERROR")) {
                Toast.makeText(this, jsonList, Toast.LENGTH_LONG).show();
                return;
            }

            JSONArray arr = new JSONArray(jsonList);
            if (arr.length() == 0) {
                Toast.makeText(this, "No audio files in this OBB", Toast.LENGTH_LONG).show();
                return;
            }

            final ArrayList<Integer> audioIndices = new ArrayList<>();
            final ArrayList<String> audioNames = new ArrayList<>();

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                int index = obj.getInt("index");
                String name = obj.getString("name");
                audioIndices.add(index);
                audioNames.add("[" + index + "] " + name);
            }

            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            View view = getLayoutInflater().inflate(R.layout.dialog_audio_list, null);
            builder.setView(view);

            TextView audioTitle = view.findViewById(R.id.audioTitle);
            audioTitle.setText("AUDIO FILES (" + arr.length() + ")");

            ListView audioList = view.findViewById(R.id.audioList);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, audioNames) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View v = super.getView(position, convertView, parent);
                    TextView t = v.findViewById(android.R.id.text1);
                    t.setTextColor(Color.parseColor("#DDDDDD"));
                    t.setTextSize(11f);
                    t.setPadding(20, 20, 20, 20);
                    return v;
                }
            };
            audioList.setAdapter(adapter);

            audioList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    playAudioFromObb(audioIndices.get(position), audioNames.get(position));
                }
            });

            view.findViewById(R.id.audioClose).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mediaPlayer != null) {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        mediaPlayer = null;
                    }
                    audioDialog.dismiss();
                }
            });

            audioDialog = builder.create();
            audioDialog.show();
            tvStatus.setText("● Found " + arr.length() + " audio files");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
        } catch (Exception e) {
            Toast.makeText(this, "Audio dialog error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void playAudioFromObb(final int index, final String displayName) {
        tvStatus.setText("● Loading " + displayName);
        tvStatus.setTextColor(Color.parseColor("#FF9800"));

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File oggFile = new File(getCacheDir(), "playback_" + index + ".ogg");

                    Python py = Python.getInstance();
                    PyObject viewerModule = py.getModule("iff_viewer");
                    PyObject result = viewerModule.callAttr("extract_audio_from_java",
                            obbFile.getAbsolutePath(), index, oggFile.getAbsolutePath());
                    String status = result.toString();

                    if (!status.startsWith("Success")) {
                        final String err = status;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                        return;
                    }

                    if (mediaPlayer != null) {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                    }
                    mediaPlayer = new android.media.MediaPlayer();
                    mediaPlayer.setDataSource(oggFile.getAbsolutePath());
                    mediaPlayer.prepare();
                    mediaPlayer.start();

                    final int duration = mediaPlayer.getDuration() / 1000;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● ▶ Playing " + displayName + " (" + duration + "s)");
                            tvStatus.setTextColor(Color.parseColor("#00FF00"));
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Play error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1500);
                    boolean serverSaysAuthorized = true;
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("SUCCESS"); }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("LOCKED"); }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { updateUIState("LOCKED"); }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);

        InputStream inputStream = getContentResolver().openInputStream(uri);

        long totalSize = 0;
        try {
            android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (sizeIndex != -1) totalSize = cursor.getLong(sizeIndex);
                cursor.close();
            }
        } catch (Exception ignored) {}

        if (isBackup && file.exists() && totalSize > 0 && file.length() == totalSize) {
            return file;
        }

        if (file.exists()) file.delete();

        showProgress();
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[65536];
        long copied = 0;
        int length;
        int lastPercent = -1;

        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
            copied += length;
            if (totalSize > 0) {
                int percent = (int) ((copied * 100) / totalSize);
                if (percent != lastPercent && percent % 2 == 0) {
                    lastPercent = percent;
                    updateProgressBar(percent);
                }
            }
        }
        inputStream.close();
        outputStream.close();

        if (totalSize > 0 && file.length() != totalSize) {
            file.delete();
            throw new Exception("Copy incomplete: got " + file.length() + " of " + totalSize + " bytes");
        }

        return file;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}