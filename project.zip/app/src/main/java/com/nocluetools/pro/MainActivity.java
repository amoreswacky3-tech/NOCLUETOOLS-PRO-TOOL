package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnRunParser;
    private boolean isAuthorized = false;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnRunParser = findViewById(R.id.btnRunParser);

        tvOutput.setText(""); // Removes the placeholder text
        updateUIState("PROCESSING");

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnRunParser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri == null || iffUri == null) {
                    Toast.makeText(MainActivity.this, "Please select both files first!", Toast.LENGTH_LONG).show();
                    return;
                }
                runPythonParser();
            }
        });
        
        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnRunParser.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("Hello Master! Ready to parse.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnRunParser.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("This app is cloned or modded. Please download from the origin of this APK.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnRunParser.setEnabled(false);
            tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.\n\nThis application has been locked due to a signature mismatch or unauthorized modification.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (requestCode == REQUEST_OBB) {
                obbUri = uri;
                tvStatus.setText("OBB selected. Backing up (this may take a while)...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                processObbBackupAndInspect();
            } else if (requestCode == REQUEST_IFF) {
                iffUri = uri;
                tvStatus.setText("IFF selected. Copying...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                // Copy in background thread
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            copyUriToInternalStorage(iffUri, "input.iff", true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    checkReadyToRun();
                                }
                            });
                        } catch (Exception e) {
                            final String error = e.getMessage();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    tvStatus.setText("Error copying IFF: " + error);
                                    tvStatus.setTextColor(Color.parseColor("#FF0000"));
                                }
                            });
                        }
                    }
                }).start();
            }
        }
    }

    private void processObbBackupAndInspect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // 1. Copy the OBB (This takes time)
                    File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                    
                    // 2. Update the UI to show we are now parsing
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Backup complete. Inspecting OBB...");
                            tvStatus.setTextColor(Color.parseColor("#FF9800"));
                        }
                    });

                    // 3. Call Python
                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                    final String obbSummary = result.toString(); 

                    // 4. Update UI with the result
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(obbSummary);
                            checkReadyToRun();
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Error backing up OBB: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void checkReadyToRun() {
        if (obbUri != null && iffUri != null) {
            tvStatus.setText("Files ready. Checking server authorization...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            performServerCheck();
        }
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000); 
                    boolean serverSaysAuthorized = true; 
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateUIState("SUCCESS");
                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateUIState("LOCKED");
                            }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateUIState("LOCKED");
                        }
                    });
                }
            }
        }).start();
    }

    private void runPythonParser() {
        tvOutput.setText("Processing... Please wait.");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File iffFile = new File(getFilesDir() + "/backups/input.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("run_tool", obbFile.getAbsolutePath(), iffFile.getAbsolutePath());
                    
                    final String output = result.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(output);
                            tvStatus.setText("Parsing Complete!");
                            tvStatus.setTextColor(Color.parseColor("#00FF00"));
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText("Error: " + e.getMessage());
                            tvStatus.setText("Parsing Failed.");
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir, fileName);
        if (isBackup && file.exists()) {
            return file; 
        }
        InputStream inputStream = getContentResolver().openInputStream(uri);
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[4096];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.close();
        return file;
    }
}