package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvFooter;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private ProgressBar progressBar;
    private android.app.AlertDialog binAudioDialog;
    private ListView popupBinList;
    private TextView binNowPlaying;
    private Button binPlayBtn;
    private Button binStopBtn;
    private Button binExportBtn;
    private ArrayAdapter<String> binAdapter;
    private android.widget.TextView popupMeta;
    private android.widget.TextView popupPayload;
    private final ArrayList<Integer> binTrackOffsets = new ArrayList<>();
    private final java.util.List<IffEntry> allEntries = new java.util.ArrayList<>();
    private final java.util.List<IffEntry> visibleEntries = new java.util.ArrayList<>();

    public static class IffEntry {
    public int index;
    public String title, sub, chip;
    public boolean editable;
    public IffEntry(int i, String n, String s, String c, boolean e) {
        index = i; title = n; sub = s; chip = c; editable = e;
    }
}
    private final ArrayList<Integer> binTrackSizes = new ArrayList<>();
    private int currentBinIndex = -1;
    private String currentBinName = "";
    private int currentBinTrackIdx = -1;
    private Button popupImportBtn;
    private static final int IMPORT_PNG_REQUEST = 8;
    private final java.util.HashMap<Integer, java.util.HashMap<Integer, String>> pendingEdits = new java.util.HashMap<>();
    private boolean currentIffFromObb = false;
    private static final int BIN_EXPORT_REQUEST = 7;
    private ArrayAdapter<String> listAdapter;
    private final List<Integer> fileIndices = new ArrayList<>();

    private android.app.AlertDialog textureDialog;
    private android.app.AlertDialog audioDialog;
    private final java.util.List<IffEntry> fileListEntries = new java.util.ArrayList<>();
    private android.app.AlertDialog fileListDialog;
    private android.widget.EditText binSearch;
    private android.app.AlertDialog objDialog;
    private ImageView objImage;
    private TextView objTitle;
    private TextView objInfo;
    private TextView objStatus;
    private File currentObjIff;
    private int currentMeshIndex = 0;
    private int totalMeshes = 0;
    private int meshYaw = 28;
    private int meshPitch = 12;
    private static final int SAVE_OBJ_REQUEST = 30;

    private android.media.MediaPlayer mediaPlayer;
    private ImageView popupImage;
    private TextView popupTitle, popupInfo, popupFormat;
    private ListView popupFileList;
    private Button fileListExtractBtn;
    private final ArrayList<Integer> selectedFileIndices = new ArrayList<>();
    private boolean fileSelectionMode = false;
    private int BATCH_FOLDER_REQUEST = 6;
    private ListView popupTextureList;
    private ListView embeddedTextureList;
    private android.app.AlertDialog textureListDialog;
    private android.app.AlertDialog loadingSpinner;
    private android.widget.EditText fileListSearch;
    private IffRowAdapter fileListAdapter;
    private final ArrayList<Integer> fileListIndices = new ArrayList<>();
    private File currentIffFile;
    private int currentTextureIndex = 0;
    private int totalTextures = 0;
    private JSONArray currentTextureList;

    private android.widget.EditText audioSearch;
    private android.widget.SeekBar audioSeek;
    private android.widget.Button audioPlayPause;
    private android.widget.Button audioStop;
    private android.widget.Button audioExtract;
    private android.widget.Button audioReplace;
    private TextView audioNowPlaying;
    private ArrayAdapter<String> audioAdapter;
    private final ArrayList<Integer> audioIndices = new ArrayList<>();
    private final ArrayList<String> audioNames = new ArrayList<>();
    private final ArrayList<String> audioLabels = new ArrayList<>();
    private final android.os.Handler seekHandler = new android.os.Handler();
    private Runnable seekRunnable;
    private boolean isPlaying = false;
    private String currentAudioName = "";
    private int currentAudioIndex = -1;
    private java.io.File currentObbFile = null;
    private final java.util.Map<String, java.io.File> pendingReplacements = new java.util.HashMap<>();
    private java.io.File pendingIffFile = null;
    private final java.util.List<IffRewriter.Patch> pendingPatches
        = new java.util.ArrayList<>();
    
    private boolean isAuthorized = false;
    private int selectedIffIndex = 0;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;
    private static final int EXPORT_PNG_REQUEST = 4;
    private static final int EXPORT_AUDIO_REQUEST = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        progressBar = findViewById(R.id.progressBar);
        
        tvOutput.setText("");
        updateUIState("PROCESSING");

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });
            
       View.OnClickListener comingSoon = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String name = ((Button) v).getText().toString();
               Toast.makeText(MainActivity.this, name + " — coming in V3", Toast.LENGTH_SHORT).show();
    }
};

                findViewById(R.id.cardRosterEditor).setOnClickListener(v ->
    startActivity(new Intent(MainActivity.this, RosterEditorActivity.class)));
                findViewById(R.id.btnHeadHair).setOnClickListener(comingSoon);
                findViewById(R.id.btnObjEditor).setOnClickListener(v -> {
    if (currentIffFile != null && currentIffFile.exists()) {
        openObjEditor(currentIffFile);
    } else {
        Toast.makeText(this, "Open an IFF first (from OBB list or OPEN IFF button)", Toast.LENGTH_SHORT).show();
    }
});
                findViewById(R.id.btnUvEditor).setOnClickListener(comingSoon);
                findViewById(R.id.btnTools).setOnClickListener(comingSoon);
                findViewById(R.id.btnConvert2K14).setOnClickListener(comingSoon);
            
        performServerCheck();
    }

    private void updateUIState(String state) {
    if (state.equals("PROCESSING")) {
        tvStatus.setText("● Checking authorization... Please wait.");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        if (tvFooter != null) {
            tvFooter.setText("● VERIFYING APP SIGNATURE...");
            tvFooter.setTextColor(Color.parseColor("#FF9800"));
        }
        btnSelectObb.setEnabled(false);
        btnSelectIff.setEnabled(false);
    } else if (state.equals("SUCCESS")) {
        tvStatus.setText("● VERIFIED  ·  OPEN AN OBB OR IFF TO BEGIN");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
        if (tvFooter != null) {
            tvFooter.setText("● VERIFIED  •  OPEN AN OBB OR IFF TO BEGIN");
            tvFooter.setTextColor(Color.parseColor("#4CAF50"));
        }
        btnSelectObb.setEnabled(true);
        btnSelectIff.setEnabled(true);
    } else if (state.equals("LOCKED")) {
        tvStatus.setText("● Unauthorized copy detected.");
        tvStatus.setTextColor(Color.parseColor("#FF0000"));
        if (tvFooter != null) {
            tvFooter.setText("● LOCKED  •  MODIFIED OR TAMPERED APK");
            tvFooter.setTextColor(Color.parseColor("#FF0000"));
        }
        btnSelectObb.setEnabled(false);
        btnSelectIff.setEnabled(false);
        tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.\n\nThis APK has been modified, tampered with, or is an unauthorized clone.\n\nPlease delete this copy and download the official version.");
        tvOutput.setTextColor(Color.parseColor("#FF0000"));
    }
}

private void showLockedDialog() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            try {
                android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(MainActivity.this);
                b.setTitle("🔒  ACCESS LOCKED");
                b.setMessage(
                        "UNAUTHORIZED COPY DETECTED\n\n" +
                        "This APK has been modified, tampered with, or is an unauthorized clone.\n\n" +
                        "Please delete this copy and download the official version from NOCLUE2K.\n\n" +
                        "What to do:\n" +
                        "• Uninstall this APK\n" +
                        "• Get the official build\n" +
                        "• Contact @NOCLUE2K if you believe this is a mistake");
                b.setCancelable(false);
                b.setPositiveButton("CLOSE APP", (d, w) -> {
                    finishAffinity();
                    System.exit(0);
                });
                b.setNegativeButton("Copy details", (d, w) -> {
                    android.content.ClipboardManager cm =
                        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("lock",
                            "UNAUTHORIZED COPY DETECTED — APK modified/tampered. Download official version."));
                    android.widget.Toast.makeText(MainActivity.this, "Copied", android.widget.Toast.LENGTH_SHORT).show();
                    showLockedDialog();
                });
                android.app.AlertDialog dlg = b.create();
                dlg.show();
            } catch (Exception e) {
                android.util.Log.e("MainActivity", "showLockedDialog failed", e);
            }
        }
    });
}

private void showBannedDialog(final boolean realBan) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            try {
                android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(MainActivity.this);
                b.setTitle(realBan ? "⛔  ACCOUNT BANNED" : "⛔  TEST BAN");
                b.setMessage(
                        (realBan ? "ACCESS DENIED\n\n" : "TEST BAN PREVIEW\n\n") +
                        "Your access to NOCLUETOOLS PRO has been suspended.\n\n" +
                        "Reason: Violation of terms of service.\n\n" +
                        "What to do:\n" +
                        "• Uninstall the app\n" +
                        "• Do NOT attempt to bypass this ban\n" +
                        "• Contact @NOCLUE2K to appeal\n\n" +
                        "Ban evasion will result in a permanent block." +
                        (realBan ? "" : "\n\n(TEST MODE — app will keep running)"));
                b.setCancelable(false);

                if (realBan) {
                    b.setPositiveButton("CLOSE APP", (d, w) -> {
                        finishAffinity();
                        System.exit(0);
                    });
                } else {
                    b.setPositiveButton("DISMISS", (d, w) -> {
                        android.widget.Toast.makeText(MainActivity.this,
                                "Test ban dismissed — app continues",
                                android.widget.Toast.LENGTH_SHORT).show();
                    });
                }

                android.app.AlertDialog dlg = b.create();
                dlg.show();
            } catch (Exception e) {
                android.util.Log.e("MainActivity", "showBannedDialog failed", e);
            }
        }
    });
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && data != null) {
        final Uri uri = data.getData();
        if (requestCode == REQUEST_OBB) {
            obbUri = uri;
            tvStatus.setText("● OBB selected. Backing up...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            processObbBackupAndInspect();
        } else if (requestCode == REQUEST_IFF) {
            iffUri = uri;
            tvStatus.setText("● IFF selected. Copying...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        showProgress();
                        File copied = copyUriToInternalStorage(iffUri, "standalone.iff", true);
                        pendingIffFile = copied;
                        hideProgress();
                        final File f = copied;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                openTexturePopup(f);
                            }
                        });
                    } catch (Exception e) {
                        hideProgress();
                        final String error = e.getMessage();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Error: " + error);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                }
            }).start();
        } else if (requestCode == CREATE_FILE_REQUEST) {
            exportIffToFile(uri);
        } else if (requestCode == EXPORT_PNG_REQUEST) {
            savePopupPng(uri);
            } else if (requestCode == BATCH_FOLDER_REQUEST) {
    if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        extractBatchToFolder(data.getData());
            }
            } else if (requestCode == BIN_EXPORT_REQUEST) {
            saveBinTrack(uri);
        } else if (requestCode == IMPORT_PNG_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                performImportFromUri(data.getData());
            }
        } else if (requestCode == SAVE_OBJ_REQUEST
                && resultCode == RESULT_OK && data != null && data.getData() != null) {
            saveObjToFile(data.getData());
            return;
        }
    }
}

private void processObbBackupAndInspect() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                showProgress();
                File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                currentObbFile = obbFile;    // ← ADD THIS LINE
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Backup complete. Loading file list...");
                        tvStatus.setTextColor(Color.parseColor("#FF9800"));
                    }
                });

                Python py = Python.getInstance();
                PyObject pyModule = py.getModule("iff_viewer");
                PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                final String obbSummary = result.toString();

                PyObject listResult = pyModule.callAttr("get_file_list_from_java", obbFile.getAbsolutePath());
                final String listJson = listResult.toString();
                hideProgress();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvOutput.setText(obbSummary);
                        showFileListDialog(listJson);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void showFileListDialog(String jsonString) {
    try {
        if (jsonString.startsWith("ERROR:")) {
            tvStatus.setText("● " + jsonString);
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            return;
        }

        final JSONArray arr = new JSONArray(jsonString);

        allEntries.clear();
        visibleEntries.clear();
        fileListIndices.clear();

        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            int index = obj.getInt("index");
            String name = obj.getString("name");
            String type = obj.getString("type");
            boolean editable = obj.optBoolean("editable", false);
            long size = obj.optLong("size", 0);

            String sub = formatSize(size) + "  ·  #" + index;
            String chip = (type == null || type.isEmpty())
                    ? fileTypeFromName(name) : type.toUpperCase();

            allEntries.add(new IffEntry(index, name, sub, chip, editable));
            fileListIndices.add(index);
        }
        visibleEntries.addAll(allEntries);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_file_list, null);
        builder.setView(view);

        final TextView title = view.findViewById(R.id.fileListTitle);
        title.setText("FILES IN OBB (" + arr.length() + ")");

        fileListSearch = view.findViewById(R.id.fileListSearch);
        popupFileList = view.findViewById(R.id.fileList);

        fileListAdapter = new IffRowAdapter(visibleEntries);
        popupFileList.setAdapter(fileListAdapter);

        fileListExtractBtn = view.findViewById(R.id.fileListExtract);

        Button fileListAudioBtn = view.findViewById(R.id.fileListAudio);
        fileListAudioBtn.setOnClickListener(v -> openAudioScanner());

        Button fileListSaveObbBtn = view.findViewById(R.id.fileListSaveObb);
        fileListSaveObbBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentObbFile == null) {
                    Toast.makeText(MainActivity.this, "No OBB open", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (pendingReplacements.isEmpty()) {
                    Toast.makeText(MainActivity.this, "No mods to save yet", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    java.io.File outDir = new java.io.File(
                            android.os.Environment.getExternalStoragePublicDirectory(
                                    android.os.Environment.DIRECTORY_DOWNLOADS), "NOCLUETOOLS");
                    outDir.mkdirs();
                    java.io.File outFile = new java.io.File(outDir,
                            "Modified_" + System.currentTimeMillis() + ".obb");

                    ObbRepacker.saveAsNew(currentObbFile, pendingReplacements, outFile);
                    pendingReplacements.clear();
                    Toast.makeText(MainActivity.this,
                            "Saved: " + outFile.getName(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    android.util.Log.e("MainActivity", "save obb failed", e);
                    Toast.makeText(MainActivity.this,
                            "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        // Reset selection
        selectedFileIndices.clear();
        fileSelectionMode = false;
        updateExtractButton();

        // SEARCH
        fileListSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                String q = s.toString().toLowerCase().trim();
                visibleEntries.clear();
                for (IffEntry e : allEntries) {
                    if (q.isEmpty()
                            || e.title.toLowerCase().contains(q)
                            || e.chip.toLowerCase().contains(q)
                            || e.sub.toLowerCase().contains(q)) {
                        visibleEntries.add(e);
                    }
                }
                if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
                title.setText("FILES (" + visibleEntries.size() + " of " + arr.length() + ")");
            }
        });

        // SINGLE TAP
        popupFileList.setOnItemClickListener((parent, v, position, id) -> {
            if (position < 0 || position >= visibleEntries.size()) return;
            IffEntry tapped = visibleEntries.get(position);
            int actualIndex = tapped.index;

            if (fileSelectionMode) {
                if (selectedFileIndices.contains(actualIndex)) {
                    selectedFileIndices.remove((Integer) actualIndex);
                    if (selectedFileIndices.isEmpty()) fileSelectionMode = false;
                } else {
                    selectedFileIndices.add(actualIndex);
                }
                if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
                updateExtractButton();
            } else {
                selectedIffIndex = tapped.index;
                autoPreviewFromObb();
            }
        });

        // LONG PRESS
        popupFileList.setOnItemLongClickListener((parent, v, position, id) -> {
            if (position < 0 || position >= visibleEntries.size()) return false;
            IffEntry tapped = visibleEntries.get(position);
            fileSelectionMode = true;
            if (!selectedFileIndices.contains(tapped.index)) {
                selectedFileIndices.add(tapped.index);
            }
            if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
            updateExtractButton();
            return true;
        });

        // EXTRACT BUTTON
        fileListExtractBtn.setOnClickListener(v -> {
            if (selectedFileIndices.size() == 0) return;
            if (selectedFileIndices.size() == 1) {
                selectedIffIndex = selectedFileIndices.get(0);
                askUserWhereToSave();
            } else {
                askForBatchFolder();
            }
        });

        // CLOSE BUTTON
        view.findViewById(R.id.fileListClose).setOnClickListener(v -> {
            if (fileSelectionMode && !selectedFileIndices.isEmpty()) {
                selectedFileIndices.clear();
                fileSelectionMode = false;
                if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
                updateExtractButton();
            } else {
                fileListDialog.dismiss();
            }
        });

        fileListDialog = builder.create();
        fileListDialog.show();

        android.view.Window window = fileListDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
            window.setGravity(android.view.Gravity.FILL);
        }

        tvStatus.setText("● Loaded " + arr.length() + " files");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        tvStatus.setText("● List error: " + e.getMessage());
        tvStatus.setTextColor(Color.parseColor("#FF0000"));
    }
}

private class IffRowAdapter extends android.widget.ArrayAdapter<IffEntry> {
    IffRowAdapter(java.util.List<IffEntry> data) {
        super(MainActivity.this, 0, data);
    }

    @Override
    public View getView(int position, View cv, ViewGroup parent) {
        if (cv == null) {
            cv = getLayoutInflater().inflate(R.layout.item_iff_row, parent, false);
        }
        IffEntry e = getItem(position);
        if (e == null) return cv;

        TextView title = cv.findViewById(R.id.rowTitle);
        TextView sub   = cv.findViewById(R.id.rowSub);
        TextView chip  = cv.findViewById(R.id.rowChip);

        title.setText(e.title);
        sub.setText(e.sub);
        chip.setText(e.chip);

        if (selectedFileIndices.contains(e.index)) {
            title.setTextColor(0xFF4FC3F7);
            cv.setBackgroundColor(0xFF1A3A5A);
        } else {
            title.setTextColor(0xFFFFFFFF);
            cv.setBackgroundColor(0xFF0D0D0D);
        }

        String t = e.chip == null ? "" : e.chip.toUpperCase();
        if (t.contains("IFF")) {
            chip.setTextColor(0xFF4FC3F7);
        } else if (t.contains("AUDIO") || t.contains("OGG") || t.contains("BIN")) {
            chip.setTextColor(0xFF4CAF50);
        } else if (t.contains("CFD")) {
            chip.setTextColor(0xFFFF9800);
        } else if (t.contains("ROS")) {
            chip.setTextColor(0xFFB388FF);
        } else {
            chip.setTextColor(0xFFDDDDDD);
        }
        return cv;
    }
}

private void updateExtractButton() {
    if (fileListExtractBtn == null) return;
    int count = selectedFileIndices.size();
    if (count == 0) {
        fileListExtractBtn.setVisibility(View.GONE);
    } else {
        fileListExtractBtn.setVisibility(View.VISIBLE);
        if (count == 1) {
            fileListExtractBtn.setText("⬇  EXTRACT IFF");
        } else {
            fileListExtractBtn.setText("⬇  EXTRACT BATCH (" + count + ")");
        }
    }
}

    private void autoPreviewFromObb() {
    tvStatus.setText("● Loading texture " + selectedIffIndex + "...");
    tvStatus.setTextColor(Color.parseColor("#FF9800"));
    showProgress();

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File tempIff = new File(getCacheDir(), "preview_source.iff");

                Python py = Python.getInstance();
                PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");
                PyObject exportResult = obbModule.callAttr("export_iff_from_java",
                        obbFile.getAbsolutePath(), selectedIffIndex, tempIff.getAbsolutePath());

                if (!exportResult.toString().startsWith("Success")) {
                    hideProgress();
                    final String err = exportResult.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● " + err);
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                    return;
                }

                // Get texture list JSON while still on background thread
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject listResult = viewerModule.callAttr("list_textures_from_java", tempIff.getAbsolutePath());
                final String listJson = listResult.toString();
                final File f = tempIff;

                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        currentIffFile = f;
                        buildTextureViewer(listJson, f);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Preview Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void openTexturePopup(File iffFile) {
    if (textureDialog != null && textureDialog.isShowing()) {
        textureDialog.dismiss();
    }

    try {
        Python py = Python.getInstance();
        PyObject viewerModule = py.getModule("iff_viewer");
        PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
        String listJson = result.toString();

        if (listJson.startsWith("ERROR")) {
            Toast.makeText(this, listJson, Toast.LENGTH_LONG).show();
            return;
        }

        currentTextureList = new JSONArray(listJson);
        if (currentTextureList.length() == 0) {
            Toast.makeText(this, "No textures in this IFF", Toast.LENGTH_LONG).show();
            return;
        }

        currentIffFile = iffFile;
        currentTextureIndex = 0;
        totalTextures = currentTextureList.length();

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_viewer, null);
        builder.setView(view);

        popupTitle = view.findViewById(R.id.popupTitle);
        popupInfo = view.findViewById(R.id.popupInfo);
        popupImage = view.findViewById(R.id.popupImage);
        popupFormat = view.findViewById(R.id.popupFormat);
        popupMeta = view.findViewById(R.id.popupMeta);
        popupPayload = view.findViewById(R.id.popupPayload);  
        
        Button btnPrev = view.findViewById(R.id.popupPrev);
        Button btnNext = view.findViewById(R.id.popupNext);
        Button btnClose = view.findViewById(R.id.popupClose);
        Button btnExport = view.findViewById(R.id.popupExport);
        Button btnReplace = view.findViewById(R.id.popupReplace);
        popupImportBtn = view.findViewById(R.id.popupImport);
       
        popupTitle.setText(iffFile.getName());

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex > 0) {
                    currentTextureIndex--;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex < totalTextures - 1) {
                    currentTextureIndex++;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureDialog.dismiss();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPopupTexture();
            }
        });

        btnReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_LONG).show();
            }
        });

       popupImportBtn = view.findViewById(R.id.popupImport);

popupImportBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (!currentIffFromObb) {
            Toast.makeText(MainActivity.this, "Import works only for IFFs opened from OBB", Toast.LENGTH_LONG).show();
            return;
        }
        askForImportPng();
    }
});
       
        textureDialog = builder.create();
        textureDialog.show();

        android.view.Window window = textureDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }
        populateEmbeddedList();
        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Popup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadCurrentPopupTexture() {
    if (embeddedTextureList != null) {
        embeddedTextureList.invalidateViews();
    }

    popupInfo.setText("Texture " + (currentTextureIndex + 1) + " of " + totalTextures);
    popupFormat.setText("Loading...");
    popupFormat.setTextColor(Color.parseColor("#FF9800"));
    popupImage.setImageBitmap(null);

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");

                // Check if it's ETC2 (formats 15/16)
                PyObject etc2Result = viewerModule.callAttr("get_etc2_payload_from_java",
                        currentIffFile.getAbsolutePath(), currentTextureIndex);
                String etc2Response = etc2Result.toString();

                if (etc2Response.startsWith("SUCCESS|")) {
                    // Java OpenGL decoder path
                    String[] parts = etc2Response.split("\\|", 6);
                int w = Integer.parseInt(parts[1]);
                int h = Integer.parseInt(parts[2]);
                boolean hasAlpha = parts[3].equals("1");
                long offset = Long.parseLong(parts[4]);
                byte[] data = android.util.Base64.decode(parts[5], android.util.Base64.DEFAULT);

                    final Bitmap bmp = Etc2Decoder.decode(data, w, h, hasAlpha);
                    final String fmtName = "ETC2 " + (hasAlpha ? "RGBA8" : "RGB") + " " + w + "x" + h;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (bmp != null) {
                                popupImage.setImageBitmap(bmp);
                                popupFormat.setText("Success: " + fmtName);
                                popupFormat.setTextColor(Color.parseColor("#00FF00"));
                                popupMeta.setText(fmtName + "  ·  DECODER: AUTO  ·  PAYLOAD OK");
                                popupMeta.setTextColor(Color.parseColor("#4FC3F7"));
                                popupPayload.setText("0x" + Long.toHexString(offset) + "  ·  " + data.length + " bytes");
                                popupPayload.setTextColor(Color.parseColor("#6B7280"));
                            } else {
                                popupImage.setImageBitmap(null);
                                popupFormat.setText("ETC2 decode failed");
                                popupFormat.setTextColor(Color.parseColor("#FF0000"));
                            }
                        }
                    });
                    return;
                }

                // For non-ETC2 formats, use the existing Python path
                File pngFile = new File(getCacheDir(), "popup_" + System.currentTimeMillis() + ".png");
                PyObject result = viewerModule.callAttr("decode_texture_by_index_from_java",
                        currentIffFile.getAbsolutePath(), currentTextureIndex, pngFile.getAbsolutePath());
                String status = result.toString();

                final Bitmap bmp = status.startsWith("Success") ? BitmapFactory.decodeFile(pngFile.getAbsolutePath()) : null;
                final String finalStatus = status;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bmp != null) {
                            popupImage.setImageBitmap(bmp);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#00FF00"));
                        } else {
                            popupImage.setImageBitmap(null);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#FF0000"));
                        }
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        popupFormat.setText("Error: " + e.getMessage());
                        popupFormat.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

    private void exportCurrentPopupTexture() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE,
                currentIffFile.getName().replace(".iff", "") + "_tex" + currentTextureIndex + ".png");
        startActivityForResult(intent, EXPORT_PNG_REQUEST);
    }

    private void savePopupPng(Uri saveUri) {
        try {
            File cacheDir = getCacheDir();
            File[] files = cacheDir.listFiles();
            File pngFile = null;
            if (files != null) {
                long newest = 0;
                for (File f : files) {
                    if (f.getName().startsWith("popup_") && f.getName().endsWith(".png")) {
                        if (f.lastModified() > newest) {
                            newest = f.lastModified();
                            pngFile = f;
                        }
                    }
                }
            }
            if (pngFile == null || !pngFile.exists()) {
                Toast.makeText(this, "No texture loaded", Toast.LENGTH_SHORT).show();
                return;
            }
            InputStream is = new FileInputStream(pngFile);
            OutputStream os = getContentResolver().openOutputStream(saveUri);
            if (os != null) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
            }
            is.close();
            Toast.makeText(this, "Exported to PNG", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("● Exporting IFF index " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempOutput.getAbsolutePath());

                    String resultString = result.toString();

                    if (resultString.startsWith("Success")) {
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();
                        hideProgress();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Export complete!");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        hideProgress();
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void openAudioScanner() {
        tvStatus.setText("● Scanning OBB for audio...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    Python py = Python.getInstance();
                    PyObject viewerModule = py.getModule("iff_viewer");
                    PyObject result = viewerModule.callAttr("list_audio_from_java", obbFile.getAbsolutePath());
                    final String jsonList = result.toString();

                    hideProgress();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAudioListDialog(jsonList);
                        }
                    });
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Audio scan error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void showAudioListDialog(String jsonList) {
    try {
        if (jsonList.startsWith("ERROR")) {
            Toast.makeText(this, jsonList, Toast.LENGTH_LONG).show();
            return;
        }

        JSONArray arr = new JSONArray(jsonList);
        if (arr.length() == 0) {
            Toast.makeText(this, "No audio files in this OBB", Toast.LENGTH_LONG).show();
            return;
        }

        audioIndices.clear();
        audioNames.clear();
        audioLabels.clear();

        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            int index = obj.getInt("index");
            String name = obj.getString("name");
            audioIndices.add(index);
            audioNames.add(name);
            audioLabels.add("♪ [" + index + "] " + name);
        }

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_audio_list, null);
        builder.setView(view);

        TextView audioTitle = view.findViewById(R.id.audioTitle);
        audioTitle.setText("AUDIO FILES (" + arr.length() + ")");

        audioSearch = view.findViewById(R.id.audioSearch);
        audioSeek = view.findViewById(R.id.audioSeek);
        audioPlayPause = view.findViewById(R.id.audioPlayPause);
        audioStop = view.findViewById(R.id.audioStop);
        audioExtract = view.findViewById(R.id.audioExtract);
        audioReplace = view.findViewById(R.id.audioReplace);
        audioNowPlaying = view.findViewById(R.id.audioNowPlaying);

        ListView audioList = view.findViewById(R.id.audioList);

        audioAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, audioLabels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextColor(Color.parseColor("#DDDDDD"));
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };
        audioList.setAdapter(audioAdapter);

        // SEARCH FILTER
        audioSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().toLowerCase();
                audioAdapter.clear();
                for (int i = 0; i < audioLabels.size(); i++) {
                    if (query.isEmpty() || audioNames.get(i).toLowerCase().contains(query)) {
                        audioAdapter.add(audioLabels.get(i));
                    }
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

     audioList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String selected = (String) parent.getItemAtPosition(position);
        int realIdx = audioLabels.indexOf(selected);
        if (realIdx >= 0) {
            int idx = audioIndices.get(realIdx);
            String name = audioNames.get(realIdx);
            if (name.toLowerCase().endsWith(".bin")) {
                openBinAudioDialog(idx, name);
            } else {
                currentAudioIndex = idx;
                currentAudioName = name;
                audioNowPlaying.setText("Selected: " + currentAudioName);
                audioPlayPause.setText("▶ PLAY");
                isPlaying = false;
                stopAudio();
            }
        }
    }
});

        // PLAY / PAUSE
        audioPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentAudioIndex < 0) {
                    Toast.makeText(MainActivity.this, "Tap a file first", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (isPlaying && mediaPlayer != null) {
                    mediaPlayer.pause();
                    isPlaying = false;
                    audioPlayPause.setText("▶ PLAY");
                } else if (mediaPlayer != null && !isPlaying) {
                    mediaPlayer.start();
                    isPlaying = true;
                    audioPlayPause.setText("⏸ PAUSE");
                    startSeekUpdate();
                } else {
                    loadAndPlayAudio(currentAudioIndex, currentAudioName);
                }
            }
        });

        // STOP
        audioStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
                audioNowPlaying.setText("Stopped");
                audioPlayPause.setText("▶ PLAY");
                isPlaying = false;
                audioSeek.setProgress(0);
            }
        });

        // EXTRACT
        audioExtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentAudioIndex < 0) {
                    Toast.makeText(MainActivity.this, "Tap a file first", Toast.LENGTH_SHORT).show();
                    return;
                }
                askWhereToSaveAudio();
            }
        });

        // REPLACE
        audioReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_SHORT).show();
            }
        });

        // CLOSE
        view.findViewById(R.id.audioClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
                audioDialog.dismiss();
            }
        });

        audioDialog = builder.create();
        audioDialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface dialog) {
                stopAudio();
            }
        });
        audioDialog.show();

        android.view.Window window = audioDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }

        tvStatus.setText("● Found " + arr.length() + " audio files");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        Toast.makeText(this, "Audio dialog error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadAndPlayAudio(final int index, final String displayName) {
    audioNowPlaying.setText("Loading " + displayName + "...");
    audioPlayPause.setText("▶ PLAY");

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File oggFile = new File(getCacheDir(), "playback_" + index + ".ogg");

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("extract_audio_from_java",
                        obbFile.getAbsolutePath(), index, oggFile.getAbsolutePath());
                String status = result.toString();

                if (!status.startsWith("Success")) {
                    final String err = status;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            audioNowPlaying.setText("Error: " + err);
                        }
                    });
                    return;
                }

                stopAudio();

                mediaPlayer = new android.media.MediaPlayer();
                mediaPlayer.setDataSource(oggFile.getAbsolutePath());
                mediaPlayer.prepare();
                mediaPlayer.start();

                mediaPlayer.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(android.media.MediaPlayer mp) {
                        isPlaying = false;
                        audioPlayPause.setText("▶ PLAY");
                        audioSeek.setProgress(0);
                    }
                });

                final int duration = mediaPlayer.getDuration() / 1000;
                audioSeek.setMax(mediaPlayer.getDuration());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        isPlaying = true;
                        audioPlayPause.setText("⏸ PAUSE");
                        audioNowPlaying.setText("▶ " + displayName + "  (" + duration + "s)");
                        startSeekUpdate();
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        audioNowPlaying.setText("Play error: " + e.getMessage());
                    }
                });
            }
        }
    }).start();
}

private void startSeekUpdate() {
    if (seekRunnable != null) seekHandler.removeCallbacks(seekRunnable);

    seekRunnable = new Runnable() {
        @Override
        public void run() {
            try {
                if (mediaPlayer != null && isPlaying) {
                    audioSeek.setProgress(mediaPlayer.getCurrentPosition());
                    seekHandler.postDelayed(this, 500);
                }
            } catch (Exception ignored) {}
        }
    };
    seekHandler.post(seekRunnable);

    audioSeek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser && mediaPlayer != null) {
                mediaPlayer.seekTo(progress);
            }
        }

        @Override
        public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

        @Override
        public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
    });
}

private void stopAudio() {
    try {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    } catch (Exception ignored) {}
    if (seekRunnable != null) {
        seekHandler.removeCallbacks(seekRunnable);
        seekRunnable = null;
    }
    isPlaying = false;
}

private void askWhereToSaveAudio() {
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("audio/ogg");
    intent.putExtra(Intent.EXTRA_TITLE, currentAudioName.endsWith(".ogg") ? currentAudioName : currentAudioName + ".ogg");
    startActivityForResult(intent, EXPORT_AUDIO_REQUEST);
}

private void performServerCheck() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                String status = fetchServerStatus();

                if (status.equalsIgnoreCase("banned")) {
    isAuthorized = false;
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            updateUIState("LOCKED");
            showBannedDialog(true);   // ← ADDED
        }
    });
    return;
}

                if (status.equalsIgnoreCase("testbanned")) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            showBannedDialog(false);  // ← TEST MODE — popup only
        }
    });
}

                isAuthorized = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateUIState("SUCCESS");
                    }
                });
            } catch (Exception e) {
                isAuthorized = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateUIState("SUCCESS");
                    }
                });
            }
        }
    }).start();
}

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);

        InputStream inputStream = getContentResolver().openInputStream(uri);

        long totalSize = 0;
        try {
            android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (sizeIndex != -1) totalSize = cursor.getLong(sizeIndex);
                cursor.close();
            }
        } catch (Exception ignored) {}

        if (isBackup && file.exists() && totalSize > 0 && file.length() == totalSize) {
            return file;
        }

        if (file.exists()) file.delete();

        showProgress();
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[65536];
        long copied = 0;
        int length;
        int lastPercent = -1;

        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
            copied += length;
            if (totalSize > 0) {
                int percent = (int) ((copied * 100) / totalSize);
                if (percent != lastPercent && percent % 2 == 0) {
                    lastPercent = percent;
                    updateProgressBar(percent);
                }
            }
        }
        inputStream.close();
        outputStream.close();

        if (totalSize > 0 && file.length() != totalSize) {
            file.delete();
            throw new Exception("Copy incomplete: got " + file.length() + " of " + totalSize + " bytes");
        }

        return file;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

private void showTextureListDialog() {
    try {
        final ArrayList<Integer> texIndices = new ArrayList<>();
        final ArrayList<String> texLabels = new ArrayList<>();

        for (int i = 0; i < currentTextureList.length(); i++) {
            JSONObject obj = currentTextureList.getJSONObject(i);
            int w = obj.optInt("width", 0);
            int h = obj.optInt("height", 0);
            String fmt = obj.optString("format", "?");
            boolean decodable = obj.optBoolean("decodable", false);
            String prefix = (i == currentTextureIndex) ? "▶ " : (decodable ? "  " : "✗ ");
            String editableTag = decodable ? "✓" : "✗";
            texLabels.add(prefix + "[" + i + "]  " + w + "×" + h + "  •  " + fmt + "  " + editableTag);
            texIndices.add(i);
        }

final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, texLabels) {
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = super.getView(position, convertView, parent);
        TextView t = v.findViewById(android.R.id.text1);
        t.setTextColor(Color.parseColor("#DDDDDD"));
        t.setTextSize(11f);
        t.setPadding(20, 20, 20, 20);
        return v;
    }
};;

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_list, null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.texListTitle);
        title.setText("TEXTURES (" + currentTextureList.length() + ")  —  current: " + currentTextureIndex);

        popupTextureList = view.findViewById(R.id.texList);
        popupTextureList.setAdapter(adapter);

        popupTextureList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                currentTextureIndex = texIndices.get(position);
                textureListDialog.dismiss();
                openTexturePopup(currentIffFile);
            }
        });

        view.findViewById(R.id.texListClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureListDialog.dismiss();
            }
        });

        textureListDialog = builder.create();
        textureListDialog.show();

        android.view.Window window = textureListDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
        }
    } catch (Exception e) {
        Toast.makeText(this, "Texture list error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void fetchTextureListAndShow(final File iffFile) {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
                String listJson = result.toString();

                if (listJson.startsWith("ERROR")) {
                    final String err = listJson;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, err, Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                currentTextureList = new JSONArray(listJson);
                if (currentTextureList.length() == 0) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "No textures", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }

                currentIffFile = iffFile;
                currentTextureIndex = 0;
                totalTextures = currentTextureList.length();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showTextureListDialog();
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

  private void openBinAudioDialog(final int binIndex, final String binName) {
    currentBinIndex = binIndex;
    currentBinName = binName;
    currentBinTrackIdx = -1;
    binTrackOffsets.clear();
    binTrackSizes.clear();

    tvStatus.setText("● Loading " + binName + "...");
    tvStatus.setTextColor(Color.parseColor("#FF9800"));
    showProgress();

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("list_bin_tracks_from_java",
                        obbFile.getAbsolutePath(), currentBinIndex);
                final String jsonResult = result.toString();

                hideProgress();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showBinTracksDialog(jsonResult);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,
                            "BIN load error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }).start();
}

private void saveAudioToFile(final Uri saveUri) {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                if (currentBinIndex < 0) {
                    toastOnUi("No bin selected");
                    return;
                }
                if (currentBinTrackIdx < 0) {
                    toastOnUi("Select a track first");
                    return;
                }

                // Match the cache filename playBinTrack() uses
                File oggFile = new File(getCacheDir(),
                        "bin_" + currentBinIndex + "_track" + currentBinTrackIdx + ".ogg");

                // If not cached yet, extract it now via Python
                if (!oggFile.exists()) {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    if (!obbFile.exists()) {
                        toastOnUi("OBB missing — reopen the OBB");
                        return;
                    }

                    Python py = Python.getInstance();
                    PyObject viewerModule = py.getModule("iff_viewer");
                    PyObject result = viewerModule.callAttr("extract_bin_track_from_java",
                            obbFile.getAbsolutePath(),
                            currentBinIndex,
                            binTrackOffsets.get(currentBinTrackIdx),
                            binTrackSizes.get(currentBinTrackIdx),
                            oggFile.getAbsolutePath());

                    String status = result.toString();
                    if (status.startsWith("Error") || status.startsWith("Fail")) {
                        toastOnUi("Extract failed: " + status);
                        return;
                    }
                }

                if (!oggFile.exists() || oggFile.length() == 0) {
                    toastOnUi("Extraction produced no data");
                    return;
                }

                // Copy to user-chosen URI (SAF)
                InputStream is = new FileInputStream(oggFile);
                OutputStream os = getContentResolver().openOutputStream(saveUri);
                if (os == null) {
                    is.close();
                    toastOnUi("Cannot open save destination");
                    return;
                }
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
                is.close();

                toastOnUi("Audio extracted ✓");

            } catch (Exception e) {
                android.util.Log.e("MainActivity", "saveAudioToFile failed", e);
                toastOnUi("Extract error: " + e.getMessage());
            }
        }
    }).start();
}

private void toastOnUi(final String msg) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
}

private void showBinTracksDialog(String jsonResult) {
    try {
        if (jsonResult.startsWith("ERROR")) {
            Toast.makeText(this, jsonResult, Toast.LENGTH_LONG).show();
            return;
        }

        JSONObject root = new JSONObject(jsonResult);
        JSONArray tracks = root.getJSONArray("tracks");

        if (tracks.length() == 0) {
            Toast.makeText(this, "No OGG tracks found in " + currentBinName, Toast.LENGTH_LONG).show();
            return;
        }

        final ArrayList<String> labels = new ArrayList<>();

        for (int i = 0; i < tracks.length(); i++) {
            JSONObject t = tracks.getJSONObject(i);
            int off = t.getInt("offset");
            int size = t.getInt("size");
            binTrackOffsets.add(off);
            binTrackSizes.add(size);
            double kb = size / 1024.0;
            labels.add("♪  Track " + (i + 1) + "  (" + String.format("%.1f", kb) + " KB)");
        }

        binAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                if (position == currentBinTrackIdx) {
                    t.setTextColor(Color.parseColor("#4FC3F7"));
                    t.setBackgroundColor(Color.parseColor("#1A3A5A"));
                } else {
                    t.setTextColor(Color.parseColor("#DDDDDD"));
                    t.setBackgroundColor(Color.TRANSPARENT);
                }
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_bin_audio, null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.binTitle);
        title.setText(currentBinName + "  —  " + tracks.length() + " tracks");

        popupBinList = view.findViewById(R.id.binList);
        popupBinList.setAdapter(binAdapter);

        binNowPlaying = view.findViewById(R.id.binNowPlaying);
        binNowPlaying.setText("Tap a track to select");
        binPlayBtn = view.findViewById(R.id.binPlay);
        binStopBtn = view.findViewById(R.id.binStop);
        binExportBtn = view.findViewById(R.id.binExport);
        Button binReplaceBtn = view.findViewById(R.id.binReplace);

        popupBinList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                currentBinTrackIdx = position;
                binNowPlaying.setText("Selected: Track " + (position + 1));
                binAdapter.notifyDataSetChanged();
            }
        });

        binPlayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBinTrackIdx < 0) {
                    Toast.makeText(MainActivity.this, "Select a track first", Toast.LENGTH_SHORT).show();
                    return;
                }
                playBinTrack(currentBinTrackIdx);
            }
        });

        binStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                binNowPlaying.setText("Stopped");
            }
        });

        binExportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBinTrackIdx < 0) {
                    Toast.makeText(MainActivity.this, "Select a track first", Toast.LENGTH_SHORT).show();
                    return;
                }
                askWhereToSaveBinTrack();
            }
        });

        binReplaceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_LONG).show();
            }
        });

view.findViewById(R.id.binClose).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        try {
            if (mediaPlayer != null) {
                try { mediaPlayer.stop(); } catch (Exception ignored) {}
                try { mediaPlayer.release(); } catch (Exception ignored) {}
                mediaPlayer = null;
            }
        } catch (Exception ignored) {}
        if (binAudioDialog != null && binAudioDialog.isShowing()) {
            binAudioDialog.dismiss();
        }
    }
});

        binAudioDialog = builder.create();
        binAudioDialog.show();

        android.view.Window window = binAudioDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
            window.setGravity(android.view.Gravity.FILL);
        }

        tvStatus.setText("● Found " + tracks.length() + " tracks");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        Toast.makeText(this, "BIN dialog error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void playBinTrack(final int trackIdx) {
    binNowPlaying.setText("Loading Track " + (trackIdx + 1) + "...");

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File oggFile = new File(getCacheDir(), "bin_" + currentBinIndex + "_track_" + trackIdx + ".ogg");

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("extract_bin_track_from_java",
                        obbFile.getAbsolutePath(),
                        currentBinIndex,
                        binTrackOffsets.get(trackIdx),
                        binTrackSizes.get(trackIdx),
                        oggFile.getAbsolutePath());

                String status = result.toString();
                if (!status.startsWith("Success")) {
                    final String err = status;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            binNowPlaying.setText("Error: " + err);
                        }
                    });
                    return;
                }

                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                }
                mediaPlayer = new android.media.MediaPlayer();
                mediaPlayer.setDataSource(oggFile.getAbsolutePath());
                mediaPlayer.prepare();
                mediaPlayer.start();

                final int duration = mediaPlayer.getDuration() / 1000;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        binNowPlaying.setText("▶ Track " + (trackIdx + 1) + "  (" + duration + "s)");
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        binNowPlaying.setText("Play error: " + e.getMessage());
                    }
                });
            }
        }
    }).start();
}

private void askWhereToSaveBinTrack() {
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("audio/ogg");
    intent.putExtra(Intent.EXTRA_TITLE,
            currentBinName.replace(".bin", "") + "_track" + (currentBinTrackIdx + 1) + ".ogg");
    startActivityForResult(intent, BIN_EXPORT_REQUEST);
}

private void saveBinTrack(Uri saveUri) {
    try {
        File oggFile = new File(getCacheDir(),
                "bin_" + currentBinIndex + "_track_" + currentBinTrackIdx + ".ogg");

        if (!oggFile.exists()) {
            File obbFile = new File(getFilesDir() + "/backups/input.obb");
            Python py = Python.getInstance();
            PyObject viewerModule = py.getModule("iff_viewer");
            viewerModule.callAttr("extract_bin_track_from_java",
                    obbFile.getAbsolutePath(),
                    currentBinIndex,
                    binTrackOffsets.get(currentBinTrackIdx),
                    binTrackSizes.get(currentBinTrackIdx),
                    oggFile.getAbsolutePath());
        }

        InputStream is = new FileInputStream(oggFile);
        OutputStream os = getContentResolver().openOutputStream(saveUri);
        if (os != null) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
        }
        is.close();
        Toast.makeText(this, "Track saved", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
        Toast.makeText(this, "Save error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

    private void showProgress() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (progressBar != null) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setIndeterminate(true);
                }
            }
        });
    }

    private void hideProgress() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }

private void askForBatchFolder() {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivityForResult(intent, BATCH_FOLDER_REQUEST);
}

private void extractBatchToFolder(Uri treeUri) {
    if (selectedFileIndices.size() == 0) return;

    final ArrayList<Integer> toExtract = new ArrayList<>(selectedFileIndices);

    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            tvStatus.setText("● Extracting " + toExtract.size() + " files...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            showProgress();
        }
    });

    new Thread(new Runnable() {
        @Override
        public void run() {
            File obbFile = new File(getFilesDir() + "/backups/input.obb");
            Python py = Python.getInstance();
            PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");

            int success = 0;
            int fail = 0;

            for (int i = 0; i < toExtract.size(); i++) {
                int idx = toExtract.get(i);
                try {
                    // Find the filename from allLabels (may be different)
                    String filename = "extracted_" + idx + ".iff";

                    // Extract to temp
                    File tempFile = new File(getCacheDir(), "batch_" + idx + ".iff");
                    PyObject result = obbModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), idx, tempFile.getAbsolutePath());

                    if (result.toString().startsWith("Success")) {
                        // Create destination file in the SAF folder
                        String displayName = "extracted_" + idx + ".iff";
                        // Try to get proper name from CSV - use the label we stored
                        // For now, use index-based name
                        android.net.Uri docUri = android.provider.DocumentsContract.createDocument(
                                getContentResolver(),
                                android.provider.DocumentsContract.buildDocumentUriUsingTree(
                                        treeUri,
                                        android.provider.DocumentsContract.getTreeDocumentId(treeUri)),
                                "application/octet-stream",
                                displayName);

                        if (docUri != null) {
                            java.io.InputStream is = new java.io.FileInputStream(tempFile);
                            java.io.OutputStream os = getContentResolver().openOutputStream(docUri);
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) {
                                os.write(buffer, 0, len);
                            }
                            os.close();
                            is.close();
                            success++;
                        } else {
                            fail++;
                        }
                        tempFile.delete();
                    } else {
                        fail++;
                    }
                } catch (Exception e) {
                    fail++;
                }
            }

            final int s = success;
            final int f = fail;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    hideProgress();
                    tvStatus.setText("● Batch extract: " + s + " success, " + f + " failed");
                    tvStatus.setTextColor(Color.parseColor("#00FF00"));
                    Toast.makeText(MainActivity.this,
                        "Extracted " + s + " of " + (s + f) + " files",
                        Toast.LENGTH_LONG).show();

                    selectedFileIndices.clear();
                    fileSelectionMode = false;
                    if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
                    updateExtractButton();
                    if (fileListDialog != null && fileListDialog.isShowing()) {
                        fileListDialog.dismiss();
                    }
                }
            });
        }
    }).start();
}

private void askForImportPng() {
    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
    intent.setType("image/*");
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(intent, IMPORT_PNG_REQUEST);
}

private void performImportFromUri(Uri pngUri) {
    try {
        JSONObject texInfo = currentTextureList.getJSONObject(currentTextureIndex);
        int expectedW = texInfo.getInt("width");
        int expectedH = texInfo.getInt("height");
        int formatId = texInfo.getInt("format_id");
        boolean decodable = texInfo.optBoolean("decodable", false);

        if (!decodable) {
            Toast.makeText(this, "This texture format is not editable (streamed layout)", Toast.LENGTH_LONG).show();
            return;
        }

        if (formatId != 2 && formatId != 4 && formatId != 17) {
            Toast.makeText(this,
                "Format " + formatId + " not supported for editing (only RGB565, RGBA4444, RGBA8888)",
                Toast.LENGTH_LONG).show();
            return;
        }

        // Decode bounds only (no memory load)
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        InputStream is = getContentResolver().openInputStream(pngUri);
        BitmapFactory.decodeStream(is, null, opts);
        is.close();

        int pngW = opts.outWidth;
        int pngH = opts.outHeight;

        if (pngW != expectedW || pngH != expectedH) {
            Toast.makeText(this,
                "Size mismatch — expected " + expectedW + "x" + expectedH + ", got " + pngW + "x" + pngH,
                Toast.LENGTH_LONG).show();
            return;
        }

        // Save PNG to app-private storage
        File pngDir = new File(getFilesDir(), "pending_pngs");
        if (!pngDir.exists()) pngDir.mkdirs();
        File pngFile = new File(pngDir, "edit_" + selectedIffIndex + "_" + currentTextureIndex + ".png");

        InputStream in = getContentResolver().openInputStream(pngUri);
        FileOutputStream out = new FileOutputStream(pngFile);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();

        // Track the pending edit
        if (!pendingEdits.containsKey(selectedIffIndex)) {
            pendingEdits.put(selectedIffIndex, new java.util.HashMap<Integer, String>());
        }
        pendingEdits.get(selectedIffIndex).put(currentTextureIndex, pngFile.getAbsolutePath());

        Toast.makeText(this, "Texture queued for replacement ✅", Toast.LENGTH_SHORT).show();
        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Import error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void buildTextureViewer(String listJson, File iffFile) {
    try {
        if (listJson.startsWith("ERROR")) {
            Toast.makeText(this, listJson, Toast.LENGTH_LONG).show();
            return;
        }

        currentTextureList = new JSONArray(listJson);
        if (currentTextureList.length() == 0) {
            Toast.makeText(this, "No textures in this IFF", Toast.LENGTH_LONG).show();
            return;
        }

        currentIffFile = iffFile;
        currentTextureIndex = 0;
        totalTextures = currentTextureList.length();

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_viewer, null);
        builder.setView(view);

        popupTitle = view.findViewById(R.id.popupTitle);
        popupInfo = view.findViewById(R.id.popupInfo);
        popupImage = view.findViewById(R.id.popupImage);
        popupFormat = view.findViewById(R.id.popupFormat);

        Button btnPrev = view.findViewById(R.id.popupPrev);
        Button btnNext = view.findViewById(R.id.popupNext);
        Button btnClose = view.findViewById(R.id.popupClose);
        Button btnExport = view.findViewById(R.id.popupExport);
        Button btnReplace = view.findViewById(R.id.popupReplace);
        popupImportBtn = view.findViewById(R.id.popupImport);

        embeddedTextureList = view.findViewById(R.id.embeddedTextureList);
        populateEmbeddedList();

        popupTitle.setText(iffFile.getName());

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex > 0) {
                    currentTextureIndex--;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex < totalTextures - 1) {
                    currentTextureIndex++;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureDialog.dismiss();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPopupTexture();
            }
        });

        btnReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_LONG).show();
            }
        });

        popupImportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!currentIffFromObb) {
                    Toast.makeText(MainActivity.this, "Import works only for IFFs opened from OBB", Toast.LENGTH_LONG).show();
                    return;
                }
                askForImportPng();
            }
        });

        textureDialog = builder.create();
        textureDialog.show();

        android.view.Window window = textureDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
            window.setGravity(android.view.Gravity.FILL);
        }

        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Popup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void populateEmbeddedList() {
    if (embeddedTextureList == null) return;

    final ArrayList<String> labels = new ArrayList<>();
    final ArrayList<Integer> indices = new ArrayList<>();

   int total = (currentTextureList == null) ? 0 : currentTextureList.length();

// TEMP DEBUG
if (popupFormat != null) {
    popupFormat.setText("DEBUG: total=" + total + " labels=" + labels.size());
    popupFormat.setTextColor(0xFFFF00FF);
    popupFormat.setTextSize(9f);
}

    for (int i = 0; i < total; i++) {
        try {
            JSONObject obj = currentTextureList.getJSONObject(i);
            int w = obj.optInt("width", obj.optInt("w", 0));
            int h = obj.optInt("height", obj.optInt("h", 0));
            String fmt = obj.optString("format", obj.optString("fmt", "?"));
            boolean decodable = obj.optBoolean("decodable", false);

            String prefix = (i == currentTextureIndex) ? "► " : (decodable ? "  " : "x ");
            labels.add(prefix + "[" + i + "] " + w + "x" + h + " - " + fmt);
            indices.add(i);
        } catch (Exception e) {
            android.util.Log.e("MainActivity", "tex entry " + i + " failed", e);
            labels.add("[" + i + "] <parse error>");
            indices.add(i);
        }
    }

    android.util.Log.d("MainActivity", "populateEmbeddedList: built " + labels.size() + " labels");

    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = super.getView(position, convertView, parent);
            TextView t = v.findViewById(android.R.id.text1);
            int realIdx = indices.get(position);
            if (realIdx == currentTextureIndex) {
                t.setTextColor(Color.parseColor("#4FC3F7"));
                t.setBackgroundColor(Color.parseColor("#1A3A5A"));
            } else {
                t.setTextColor(Color.parseColor("#DDDDDD"));
                t.setBackgroundColor(Color.TRANSPARENT);
            }
            t.setTextSize(11f);
            t.setPadding(20, 15, 20, 15);
            return v;
        }
    };

    embeddedTextureList.setAdapter(adapter);
    embeddedTextureList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            currentTextureIndex = indices.get(position);
            embeddedTextureList.invalidateViews();
            loadCurrentPopupTexture();
        }
    });
}

private void showLoadingSpinner(String message) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            try {
                if (loadingSpinner != null && loadingSpinner.isShowing()) {
                    loadingSpinner.dismiss();
                }

                android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(MainActivity.this);
                android.widget.LinearLayout ll = new android.widget.LinearLayout(MainActivity.this);
                ll.setOrientation(android.widget.LinearLayout.VERTICAL);
                ll.setGravity(android.view.Gravity.CENTER);
                ll.setPadding(80, 80, 80, 80);

                ProgressBar pb = new ProgressBar(MainActivity.this);
                ll.addView(pb);

                TextView tv = new TextView(MainActivity.this);
                tv.setText(message);
                tv.setTextColor(Color.parseColor("#FFFFFF"));
                tv.setTextSize(12f);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setPadding(0, 30, 0, 0);
                ll.addView(tv);

                b.setView(ll);
                b.setCancelable(false);

                loadingSpinner = b.create();
                loadingSpinner.show();

                android.view.Window w = loadingSpinner.getWindow();
                if (w != null) {
                    w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                        Color.parseColor("#1E1E1E")));
                }
            } catch (Exception e) {}
        }
    });
}

private void hideLoadingSpinner() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            try {
                if (loadingSpinner != null && loadingSpinner.isShowing()) {
                    loadingSpinner.dismiss();
                }
            } catch (Exception e) {}
        }
    });
}

private String getAppSignatureHash() {
    try {
        android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(
                getPackageName(),
                android.content.pm.PackageManager.GET_SIGNATURES);
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA");
        md.update(pi.signatures[0].toByteArray());
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format("%02X", b));
        return sb.toString();
    } catch (Exception e) {
        return "";
    }
}

private boolean isSignatureValid() {
    String OFFICIAL = "PASTE_YOUR_SHA_HERE";  // ← will replace in Part B

    // If not configured yet, allow (safety net)
    if (OFFICIAL.equals("PASTE_YOUR_SHA_HERE")) {
        return true;
    }

    String actual = getAppSignatureHash();
    if (actual.isEmpty()) {
        return true;  // Can't read, allow
    }
    return actual.equalsIgnoreCase(OFFICIAL);
}

private String fetchServerStatus() {
    String url = "https://gist.githubusercontent.com/amoreswacky3-tech/c0cb79bfe3a856fdb8c1e064204294a9/raw/gistfile1.txt?t=" + System.currentTimeMillis();

    try {
        java.net.URL u = new java.net.URL(url);
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        conn.setRequestProperty("Cache-Control", "no-cache");
        conn.setRequestProperty("Pragma", "no-cache");

        int code = conn.getResponseCode();
        if (code != 200) {
            return "active";
        }

        java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        JSONObject obj = new JSONObject(sb.toString());
        return obj.optString("status", "active");
    } catch (Exception e) {
        return "active";
    }
}

private void updateProgressBar(int percent) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            if (progressBar != null) {
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setIndeterminate(false);
                progressBar.setProgress(percent);
            }
        }
    });
}

private void extractCurrentAudio() {
    if (currentBinIndex < 0) {
        Toast.makeText(this, "No bin selected", Toast.LENGTH_SHORT).show();
        return;
    }
    final int trackIdx = currentBinTrackIdx;   // use whatever holds the selected track index
    if (trackIdx < 0) {
        Toast.makeText(this, "Select a track first", Toast.LENGTH_SHORT).show();
        return;
    }

    binNowPlaying.setText("Extracting Track " + (trackIdx + 1) + "...");

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File tmpOgg = new File(getCacheDir(),
                        "extract_bin_" + currentBinIndex + "_track_" + trackIdx + ".ogg");

                // Same Python call as playBinTrack — writes .ogg to tmpOgg
                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("extract_bin_track_from_java",
                        obbFile.getAbsolutePath(),
                        currentBinIndex,
                        binTrackOffsets.get(trackIdx),
                        binTrackSizes.get(trackIdx),
                        tmpOgg.getAbsolutePath());

                String status = result.toString();
                if (status.startsWith("Error") || status.startsWith("Fail")) {
                    final String err = status;
                    runOnUiThread(() -> binNowPlaying.setText("Extract error: " + err));
                    return;
                }

                // Copy to Downloads/NOCLUETOOLS/Audio/
                File outDir = new File(
                        android.os.Environment.getExternalStoragePublicDirectory(
                                android.os.Environment.DIRECTORY_DOWNLOADS),
                        "NOCLUETOOLS/Audio");
                outDir.mkdirs();

                // Name: use real audio name if available, else binName + track number
                String outName;
                if (currentAudioName != null && !currentAudioName.isEmpty()) {
                    outName = currentAudioName;
                } else {
                    String binBase = (currentBinName == null || currentBinName.isEmpty())
                            ? "bin" + currentBinIndex
                            : currentBinName.replace(".bin", "");
                    outName = binBase + "_track" + (trackIdx + 1) + ".ogg";
                }
                // Ensure .ogg extension
                if (!outName.toLowerCase().endsWith(".ogg")) outName += ".ogg";

                File outFile = new File(outDir, outName);
                try (java.io.FileInputStream in = new java.io.FileInputStream(tmpOgg);
                     java.io.FileOutputStream out = new java.io.FileOutputStream(outFile)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                tmpOgg.delete();

                final String finalName = outFile.getName();
                final long finalSize = outFile.length();
                runOnUiThread(() -> {
                    binNowPlaying.setText("✓ Extracted: " + finalName
                            + "  (" + (finalSize / 1024) + " KB)");
                    Toast.makeText(MainActivity.this,
                            "Saved to Downloads/NOCLUETOOLS/Audio/" + finalName,
                            Toast.LENGTH_LONG).show();
                });

            } catch (Exception e) {
                android.util.Log.e("MainActivity", "extract failed", e);
                final String err = e.getMessage();
                runOnUiThread(() -> binNowPlaying.setText("Extract failed: " + err));
            }
        }
    }).start();
}

private void openObjEditor(File iffFile) {
    currentObjIff = iffFile;
    currentMeshIndex = 0;
    meshYaw = 28;
    meshPitch = 12;

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                final String json = mod.callAttr("list_meshes_from_java",
                        currentObjIff.getAbsolutePath()).toString();

                runOnUiThread(() -> {
                    if (json == null || json.startsWith("ERROR")) {
                        Toast.makeText(MainActivity.this, json, Toast.LENGTH_LONG).show();
                        return;
                    }
                    try {
                        org.json.JSONArray arr = new org.json.JSONArray(json);
                        if (arr.length() == 0) {
                            Toast.makeText(MainActivity.this,
                                    "No meshes found in this IFF", Toast.LENGTH_LONG).show();
                            return;
                        }
                        totalMeshes = arr.length();
                        showObjDialog();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this,
                                "Mesh list parse error: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Mesh load failed: " + err, Toast.LENGTH_LONG).show());
            }
        }
    }).start();
}

private void showObjDialog() {
    android.app.AlertDialog.Builder builder =
            new android.app.AlertDialog.Builder(this);
    View view = getLayoutInflater().inflate(R.layout.dialog_obj_viewer, null);
    builder.setView(view);

    objTitle   = view.findViewById(R.id.objTitle);
    objInfo    = view.findViewById(R.id.objInfo);
    objImage   = view.findViewById(R.id.objImage);
    objStatus  = view.findViewById(R.id.objStatus);

    Button prev   = view.findViewById(R.id.objPrev);
    Button next   = view.findViewById(R.id.objNext);
    Button rotL   = view.findViewById(R.id.objRotL);
    Button rotR   = view.findViewById(R.id.objRotR);
    Button export = view.findViewById(R.id.objExport);
    Button close  = view.findViewById(R.id.objClose);

    objTitle.setText(currentObjIff.getName());

    prev.setOnClickListener(v -> {
        if (currentMeshIndex > 0) { currentMeshIndex--; loadMeshPreview(); }
    });
    next.setOnClickListener(v -> {
        if (currentMeshIndex < totalMeshes - 1) { currentMeshIndex++; loadMeshPreview(); }
    });
    rotL.setOnClickListener(v -> { meshYaw -= 15; loadMeshPreview(); });
    rotR.setOnClickListener(v -> { meshYaw += 15; loadMeshPreview(); });
    export.setOnClickListener(v -> askSaveObj());
    close.setOnClickListener(v -> objDialog.dismiss());

    objDialog = builder.create();
    objDialog.show();

    android.view.Window w = objDialog.getWindow();
    if (w != null) {
        w.setLayout(android.view.WindowManager.LayoutParams.MATCH_PARENT,
                    android.view.WindowManager.LayoutParams.MATCH_PARENT);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1A1A1A));
    }

    loadMeshPreview();
}

private void loadMeshPreview() {
    objInfo.setText("Mesh " + (currentMeshIndex + 1) + " of " + totalMeshes
            + "   ·   yaw=" + meshYaw + "°  pitch=" + meshPitch + "°");
    objStatus.setText("Loading...");
    objStatus.setTextColor(0xFFFF9800);

    final int idx = currentMeshIndex;
    final int yaw = meshYaw;
    final int pitch = meshPitch;
    final File iff = currentObjIff;

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File tmpPng = new File(getCacheDir(), "mesh_" + idx + ".png");
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                final String result = mod.callAttr("preview_mesh_from_java",
                        iff.getAbsolutePath(),
                        idx,
                        tmpPng.getAbsolutePath(),
                        yaw,
                        pitch).toString();

                if (!result.startsWith("Success")) {
                    runOnUiThread(() -> {
                        objImage.setImageBitmap(null);
                        objStatus.setText(result);
                        objStatus.setTextColor(0xFFFF0000);
                    });
                    return;
                }

                final android.graphics.Bitmap bmp =
                        android.graphics.BitmapFactory.decodeFile(tmpPng.getAbsolutePath());
                runOnUiThread(() -> {
                    objImage.setImageBitmap(bmp);
                    objStatus.setText("✓ " + result);
                    objStatus.setTextColor(0xFF00FF00);
                });
            } catch (Exception e) {
                final String err = e.getMessage();
                runOnUiThread(() -> {
                    objStatus.setText("Error: " + err);
                    objStatus.setTextColor(0xFFFF0000);
                });
            }
        }
    }).start();
}

private void askSaveObj() {
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("application/octet-stream");
    String base = currentObjIff.getName().replace(".iff", "");
    intent.putExtra(Intent.EXTRA_TITLE, base + "_mesh" + currentMeshIndex + ".obj");
    startActivityForResult(intent, SAVE_OBJ_REQUEST);
}

private void saveObjToFile(Uri saveUri) {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File tmpObj = new File(getCacheDir(), "export_mesh.obj");
                Python py = Python.getInstance();
                PyObject mod = py.getModule("iff_viewer");
                final String result = mod.callAttr("export_mesh_from_java",
                        currentObjIff.getAbsolutePath(),
                        currentMeshIndex,
                        tmpObj.getAbsolutePath()).toString();

                if (!result.startsWith("Success")) {
                    toastOnUi(result);
                    return;
                }

                try (java.io.InputStream in = new java.io.FileInputStream(tmpObj);
                     java.io.OutputStream out = getContentResolver().openOutputStream(saveUri)) {
                    if (out == null) { toastOnUi("Cannot open save URI"); return; }
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                toastOnUi("Exported OBJ ✓");
            } catch (Exception e) {
                toastOnUi("Export failed: " + e.getMessage());
            }
        }
    }).start();
}

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private static String fileTypeFromName(String name) {
        if (name == null) return "?";
        String n = name.toLowerCase();
        if (n.endsWith(".iff")) return "IFF";
        if (n.endsWith(".cdf")) return "CFD";
        if (n.endsWith(".bin")) return "AUDIO";
        if (n.endsWith(".ogg")) return "OGG";
        if (n.endsWith(".ros")) return "ROS";
        if (n.endsWith(".iff2")) return "IFF2";
        return "FILE";
    }
} 