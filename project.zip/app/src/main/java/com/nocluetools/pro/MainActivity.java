package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnExportIff;
    private ListView listFiles;
    private ProgressBar progressBar;
    private ArrayAdapter<String> listAdapter;
    private final List<Integer> fileIndices = new ArrayList<>();

    private boolean isAuthorized = false;
    private int selectedIffIndex = 0;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnExportIff = findViewById(R.id.btnExportIff);
        listFiles = findViewById(R.id.listFiles);
        progressBar = findViewById(R.id.progressBar);

        tvOutput.setText("");
        updateUIState("PROCESSING");

        listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text = (TextView) view.findViewById(android.R.id.text1);
                text.setTextColor(Color.parseColor("#DDDDDD"));
                text.setTextSize(11f);
                text.setPadding(20, 20, 20, 20);
                return view;
            }
        };
        listFiles.setAdapter(listAdapter);
        listFiles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedIffIndex = fileIndices.get(position);
                autoPreviewFromObb();
            }
        });

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnExportIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri != null) {
                    askUserWhereToSave();
                } else {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("● Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("● Hello Master! Ready.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnExportIff.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("● This app is cloned or modded. Please download from the origin of this APK.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            tvOutput.setText("UNAUTHORIZED COPY DETECTED.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }
    private void showProgress() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setIndeterminate(true);
        }
    });
}

private void updateProgressBar(int percent) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(percent);
        }
    });
}

private void hideProgress() {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setVisibility(View.GONE);
        }
    });
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && data != null) {
        Uri uri = data.getData();
        if (requestCode == REQUEST_OBB) {
            obbUri = uri;
            tvStatus.setText("● OBB selected. Backing up...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            processObbBackupAndInspect();
        } else if (requestCode == REQUEST_IFF) {
            iffUri = uri;
            tvStatus.setText("● IFF selected. Copying...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        showProgress();
                        File copied = copyUriToInternalStorage(iffUri, "standalone.iff", true);
                        hideProgress();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                autoPreviewStandalone(copied);
                            }
                        });
                    } catch (Exception e) {
                        hideProgress();
                        final String error = e.getMessage();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Error copying IFF: " + error);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                }
            }).start();
        } else if (requestCode == CREATE_FILE_REQUEST) {
            exportIffToFile(uri);
        }
    }
}

private void autoPreviewFromObb() {
    tvStatus.setText("● Loading texture " + selectedIffIndex + "...");
    tvStatus.setTextColor(Color.parseColor("#FF9800"));
    showProgress();

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File tempIff = new File(getCacheDir(), "preview_source.iff");
                File pngFile = new File(getCacheDir(), "texture_preview.png");

                Python py = Python.getInstance();
                PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");
                PyObject exportResult = obbModule.callAttr("export_iff_from_java",
                        obbFile.getAbsolutePath(), selectedIffIndex, tempIff.getAbsolutePath());

                if (!exportResult.toString().startsWith("Success")) {
                    hideProgress();
                    final String err = exportResult.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● " + err);
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                    return;
                }

                openTexturePopup(tempIff);
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Preview Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void autoPreviewStandalone(File iffFile) {
    openTexturePopup(iffFile);
}

    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("● Exporting IFF index " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempOutput.getAbsolutePath());

                    String resultString = result.toString();

                    if (resultString.startsWith("Success")) {
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();
                        hideProgress();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Export complete!");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        hideProgress();
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void processObbBackupAndInspect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Backup complete. Loading file list...");
                            tvStatus.setTextColor(Color.parseColor("#FF9800"));
                        }
                    });

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                    final String obbSummary = result.toString();

                    PyObject listResult = pyModule.callAttr("get_file_list_from_java", obbFile.getAbsolutePath());
                    final String listJson = listResult.toString();
                    hideProgress();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(obbSummary);
                            populateFileList(listJson);
                        }
                    });
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void populateFileList(String jsonString) {
        try {
            listAdapter.clear();
            fileIndices.clear();

            if (jsonString.startsWith("ERROR:")) {
                tvStatus.setText("● " + jsonString);
                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                return;
            }

            JSONArray arr = new JSONArray(jsonString);
            int knownCount = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                int index = obj.getInt("index");
                String name = obj.getString("name");
                String type = obj.getString("type");
                boolean editable = obj.getBoolean("editable");

                String prefix = editable ? "▶ " : "  ";
                String label = prefix + "[" + index + "] " + name + "  (" + type + ")";
                listAdapter.add(label);
                fileIndices.add(index);

                if (!name.matches("^[0-9a-f]{8}$")) knownCount++;
            }

            tvStatus.setText("● Loaded " + arr.length() + " files (" + knownCount + " named)");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
        } catch (Exception e) {
            tvStatus.setText("● List error: " + e.getMessage());
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
        }
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                    boolean serverSaysAuthorized = true;
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("SUCCESS"); }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("LOCKED"); }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { updateUIState("LOCKED"); }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);
        if (isBackup && file.exists()) return file;

        InputStream inputStream = getContentResolver().openInputStream(uri);

        long totalSize = 0;
        try {
            android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (sizeIndex != -1) totalSize = cursor.getLong(sizeIndex);
                cursor.close();
            }
        } catch (Exception ignored) {}

        showProgress();
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[65536];
        long copied = 0;
        int length;
        int lastPercent = -1;

        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
            copied += length;
            if (totalSize > 0) {
                int percent = (int) ((copied * 100) / totalSize);
                if (percent != lastPercent && percent % 2 == 0) {
                    lastPercent = percent;
                    updateProgressBar(percent);
                }
            }
        }
        inputStream.close();
        outputStream.close();
        return file;
    }
}


// ==================== POPUP VIEWER ====================
private void openTexturePopup(File iffFile) {
    try {
        Python py = Python.getInstance();
        PyObject viewerModule = py.getModule("iff_viewer");
        PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
        String listJson = result.toString();

        if (listJson.startsWith("ERROR")) {
            Toast.makeText(this, listJson, Toast.LENGTH_LONG).show();
            return;
        }

        currentTextureList = new JSONArray(listJson);
        if (currentTextureList.length() == 0) {
            Toast.makeText(this, "No textures in this IFF", Toast.LENGTH_LONG).show();
            return;
        }

        currentIffFile = iffFile;
        currentTextureIndex = 0;
        totalTextures = currentTextureList.length();

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_viewer, null);
        builder.setView(view);

        popupTitle = view.findViewById(R.id.popupTitle);
        popupInfo = view.findViewById(R.id.popupInfo);
        popupImage = view.findViewById(R.id.popupImage);
        popupFormat = view.findViewById(R.id.popupFormat);

        Button btnPrev = view.findViewById(R.id.popupPrev);
        Button btnNext = view.findViewById(R.id.popupNext);
        Button btnClose = view.findViewById(R.id.popupClose);
        Button btnExport = view.findViewById(R.id.popupExport);
        Button btnReplace = view.findViewById(R.id.popupReplace);

        popupTitle.setText(iffFile.getName());

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex > 0) {
                    currentTextureIndex--;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex < totalTextures - 1) {
                    currentTextureIndex++;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureDialog.dismiss();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPopupTexture();
            }
        });

        btnReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,
                    "Replace coming in V2 with encoder support",
                    Toast.LENGTH_LONG).show();
            }
        });

        textureDialog = builder.create();
        textureDialog.show();
        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Popup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadCurrentPopupTexture() {
    popupInfo.setText("Texture " + (currentTextureIndex + 1) + " of " + totalTextures);
    popupFormat.setText("Loading...");
    popupFormat.setTextColor(Color.parseColor("#FF9800"));

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File pngFile = new File(getCacheDir(), "popup_preview.png");
                if (pngFile.exists()) pngFile.delete();

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("decode_texture_by_index_from_java",
                        currentIffFile.getAbsolutePath(), currentTextureIndex, pngFile.getAbsolutePath());
                String status = result.toString();

                final Bitmap bmp = status.startsWith("Success") ? BitmapFactory.decodeFile(pngFile.getAbsolutePath()) : null;
                final String finalStatus = status;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bmp != null) {
                            popupImage.setImageBitmap(bmp);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#00FF00"));
                        } else {
                            popupImage.setImageBitmap(null);
                            popupFormat.setText(finalStatus);
                            popupFormat.setTextColor(Color.parseColor("#FF0000"));
                        }
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        popupFormat.setText("Error: " + e.getMessage());
                        popupFormat.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void exportCurrentPopupTexture() {
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("image/png");
    intent.putExtra(Intent.EXTRA_TITLE,
            currentIffFile.getName().replace(".iff", "") + "_tex" + currentTextureIndex + ".png");
    startActivityForResult(intent, EXPORT_PNG_REQUEST);
}

private void savePopupPng(Uri saveUri) {
    try {
        File pngFile = new File(getCacheDir(), "popup_preview.png");
        if (!pngFile.exists()) {
            Toast.makeText(this, "No texture loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        InputStream is = new FileInputStream(pngFile);
        OutputStream os = getContentResolver().openOutputStream(saveUri);
        if (os != null) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
        }
        is.close();
        Toast.makeText(this, "Exported to PNG", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
        Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}