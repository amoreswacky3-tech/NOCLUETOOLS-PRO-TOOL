package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnExportIff;
    private Button btnAudio;
    private ProgressBar progressBar;
    private ArrayAdapter<String> listAdapter;
    private final List<Integer> fileIndices = new ArrayList<>();

    private android.app.AlertDialog textureDialog;
    private android.app.AlertDialog audioDialog;
    private android.app.AlertDialog fileListDialog;
    private android.app.AlertDialog binAudioDialog;
    private ListView popupBinList;
    private android.widget.EditText binSearch;
    private ArrayAdapter<String> binAdapter;
    private final ArrayList<Integer> binTrackOffsets = new ArrayList<>();
    private final ArrayList<Integer> binTrackSizes = new ArrayList<>();
   private int currentBinIndex = -1;
    private android.media.MediaPlayer mediaPlayer;
    private ImageView popupImage;
    private TextView popupTitle, popupInfo, popupFormat;
    private ListView popupFileList;
    private Button fileListExtractBtn;
    private final ArrayList<Integer> selectedFileIndices = new ArrayList<>();
    private boolean fileSelectionMode = false;
    private int BATCH_FOLDER_REQUEST = 6;
    private ListView popupTextureList;
    private android.app.AlertDialog textureListDialog;
    private android.widget.EditText fileListSearch;
    private ArrayAdapter<String> fileListAdapter;
    private final ArrayList<Integer> fileListIndices = new ArrayList<>();
    private File currentIffFile;
    private int currentTextureIndex = 0;
    private int totalTextures = 0;
    private JSONArray currentTextureList;

    private android.widget.EditText audioSearch;
    private android.widget.SeekBar audioSeek;
    private android.widget.Button audioPlayPause;
    private android.widget.Button audioStop;
    private android.widget.Button audioExtract;
    private android.widget.Button audioReplace;
    private TextView audioNowPlaying;
    private ArrayAdapter<String> audioAdapter;
    private final ArrayList<Integer> audioIndices = new ArrayList<>();
    private final ArrayList<String> audioNames = new ArrayList<>();
    private final ArrayList<String> audioLabels = new ArrayList<>();
    private final android.os.Handler seekHandler = new android.os.Handler();
    private Runnable seekRunnable;
    private boolean isPlaying = false;
    private String currentAudioName = "";
    private int currentAudioIndex = -1;

    private boolean isAuthorized = false;
    private int selectedIffIndex = 0;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;
    private static final int EXPORT_PNG_REQUEST = 4;
    private static final int EXPORT_AUDIO_REQUEST = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnExportIff = findViewById(R.id.btnExportIff);
        btnAudio = findViewById(R.id.btnAudio);
        progressBar = findViewById(R.id.progressBar);
        
        tvOutput.setText("");
        updateUIState("PROCESSING");

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri == null) {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                    return;
                }
                openAudioScanner();
            }
        });

        btnExportIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri != null) {
                    askUserWhereToSave();
                } else {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("● Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            btnAudio.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("● Hello Master! Ready.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnExportIff.setEnabled(true);
            btnAudio.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("● This app is cloned or modded.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            btnAudio.setEnabled(false);
            tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }
    private void updateProgressBar(int percent) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(percent);
        }
    });
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && data != null) {
        final Uri uri = data.getData();
        if (requestCode == REQUEST_OBB) {
            obbUri = uri;
            tvStatus.setText("● OBB selected. Backing up...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            processObbBackupAndInspect();
        } else if (requestCode == REQUEST_IFF) {
            iffUri = uri;
            tvStatus.setText("● IFF selected. Copying...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        showProgress();
                        File copied = copyUriToInternalStorage(iffUri, "standalone.iff", true);
                        hideProgress();
                        final File f = copied;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                openTexturePopup(f);
                            }
                        });
                    } catch (Exception e) {
                        hideProgress();
                        final String error = e.getMessage();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Error: " + error);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                }
            }).start();
        } else if (requestCode == CREATE_FILE_REQUEST) {
            exportIffToFile(uri);
        } else if (requestCode == EXPORT_PNG_REQUEST) {
            savePopupPng(uri);
            } else if (requestCode == BATCH_FOLDER_REQUEST) {
    if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        extractBatchToFolder(data.getData());
    }
        }
    }

private void processObbBackupAndInspect() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                showProgress();
                File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Backup complete. Loading file list...");
                        tvStatus.setTextColor(Color.parseColor("#FF9800"));
                    }
                });

                Python py = Python.getInstance();
                PyObject pyModule = py.getModule("iff_viewer");
                PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                final String obbSummary = result.toString();

                PyObject listResult = pyModule.callAttr("get_file_list_from_java", obbFile.getAbsolutePath());
                final String listJson = listResult.toString();
                hideProgress();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvOutput.setText(obbSummary);
                        showFileListDialog(listJson);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void showFileListDialog(String jsonString) {
    try {
        if (jsonString.startsWith("ERROR:")) {
            tvStatus.setText("● " + jsonString);
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            return;
        }

        final JSONArray arr = new JSONArray(jsonString);
        final ArrayList<String> allLabels = new ArrayList<>();
        fileListIndices.clear();

        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            int index = obj.getInt("index");
            String name = obj.getString("name");
            String type = obj.getString("type");
            boolean editable = obj.getBoolean("editable");
            String prefix = editable ? "▶ " : "  ";
            allLabels.add(prefix + "[" + index + "] " + name + "  (" + type + ")");
            fileListIndices.add(index);
        }

        final ArrayList<String> visibleLabels = new ArrayList<>(allLabels);
        final ArrayList<Integer> visibleRealIdx = new ArrayList<>();
        for (int i = 0; i < allLabels.size(); i++) visibleRealIdx.add(i);

        fileListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, visibleLabels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                // Highlight selected rows
                if (position < visibleRealIdx.size()) {
                    int realIdx = visibleRealIdx.get(position);
                    if (selectedFileIndices.contains(fileListIndices.get(realIdx))) {
                        t.setTextColor(Color.parseColor("#4FC3F7"));
                        t.setBackgroundColor(Color.parseColor("#1A3A5A"));
                    } else {
                        t.setTextColor(Color.parseColor("#DDDDDD"));
                        t.setBackgroundColor(Color.TRANSPARENT);
                    }
                }
                return v;
            }
        };

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_file_list, null);
        builder.setView(view);

        final TextView title = view.findViewById(R.id.fileListTitle);
        title.setText("FILES IN OBB (" + arr.length() + ")");

        fileListSearch = view.findViewById(R.id.fileListSearch);
        popupFileList = view.findViewById(R.id.fileList);
        popupFileList.setAdapter(fileListAdapter);

        fileListExtractBtn = view.findViewById(R.id.fileListExtract);

        // Reset selection
        selectedFileIndices.clear();
        fileSelectionMode = false;
        updateExtractButton();

        // SEARCH
        fileListSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(android.text.Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s.toString().toLowerCase().trim();
                visibleLabels.clear();
                visibleRealIdx.clear();
                for (int i = 0; i < allLabels.size(); i++) {
                    if (q.isEmpty() || allLabels.get(i).toLowerCase().contains(q)) {
                        visibleLabels.add(allLabels.get(i));
                        visibleRealIdx.add(i);
                    }
                }
                fileListAdapter.notifyDataSetChanged();
                title.setText("FILES (" + visibleLabels.size() + " of " + arr.length() + ")");
            }
        });

        // SINGLE TAP
        popupFileList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= visibleRealIdx.size()) return;
                int realIdx = visibleRealIdx.get(position);

                if (fileSelectionMode) {
                    // In selection mode, tap toggles selection
                    int actualIndex = fileListIndices.get(realIdx);
                    if (selectedFileIndices.contains(actualIndex)) {
                        selectedFileIndices.remove((Integer) actualIndex);
                        if (selectedFileIndices.isEmpty()) {
                            fileSelectionMode = false;
                        }
                    } else {
                        selectedFileIndices.add(actualIndex);
                    }
                    fileListAdapter.notifyDataSetChanged();
                    updateExtractButton();
                } else {
                    // Normal mode, preview the file
                    selectedIffIndex = fileListIndices.get(realIdx);
                    autoPreviewFromObb();
                }
            }
        });

        // LONG PRESS
        popupFileList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= visibleRealIdx.size()) return false;
                int realIdx = visibleRealIdx.get(position);
                int actualIndex = fileListIndices.get(realIdx);

                fileSelectionMode = true;
                if (!selectedFileIndices.contains(actualIndex)) {
                    selectedFileIndices.add(actualIndex);
                }
                fileListAdapter.notifyDataSetChanged();
                updateExtractButton();
                return true;
            }
        });

        // EXTRACT BUTTON
        fileListExtractBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedFileIndices.size() == 0) return;
                if (selectedFileIndices.size() == 1) {
                    selectedIffIndex = selectedFileIndices.get(0);
                    askUserWhereToSave();
                } else {
                    askForBatchFolder();
                }
            }
        });

        // CLOSE BUTTON
        view.findViewById(R.id.fileListClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fileSelectionMode && !selectedFileIndices.isEmpty()) {
                    // First tap clears selection
                    selectedFileIndices.clear();
                    fileSelectionMode = false;
                    fileListAdapter.notifyDataSetChanged();
                    updateExtractButton();
                } else {
                    fileListDialog.dismiss();
                }
            }
        });

        fileListDialog = builder.create();
        fileListDialog.show();

        android.view.Window window = fileListDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
            window.setGravity(android.view.Gravity.FILL);
        }

        tvStatus.setText("● Loaded " + arr.length() + " files");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        tvStatus.setText("● List error: " + e.getMessage());
        tvStatus.setTextColor(Color.parseColor("#FF0000"));
    }
}

private void updateExtractButton() {
    if (fileListExtractBtn == null) return;
    int count = selectedFileIndices.size();
    if (count == 0) {
        fileListExtractBtn.setVisibility(View.GONE);
    } else {
        fileListExtractBtn.setVisibility(View.VISIBLE);
        if (count == 1) {
            fileListExtractBtn.setText("⬇  EXTRACT IFF");
        } else {
            fileListExtractBtn.setText("⬇  EXTRACT BATCH (" + count + ")");
        }
    }
}



    private void autoPreviewFromObb() {
    tvStatus.setText("● Loading texture " + selectedIffIndex + "...");
    tvStatus.setTextColor(Color.parseColor("#FF9800"));
    showProgress();

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File tempIff = new File(getCacheDir(), "preview_source.iff");

                Python py = Python.getInstance();
                PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");
                PyObject exportResult = obbModule.callAttr("export_iff_from_java",
                        obbFile.getAbsolutePath(), selectedIffIndex, tempIff.getAbsolutePath());

                hideProgress();

                if (!exportResult.toString().startsWith("Success")) {
                    final String err = exportResult.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● " + err);
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                    return;
                }

                final File f = tempIff;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        fetchTextureListAndShow(f);
                    }
                });
            } catch (final Exception e) {
                hideProgress();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● Preview Error: " + e.getMessage());
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

private void openTexturePopup(File iffFile) {
    if (textureDialog != null && textureDialog.isShowing()) {
        textureDialog.dismiss();
    }

    try {
        Python py = Python.getInstance();
        PyObject viewerModule = py.getModule("iff_viewer");
        PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
        String listJson = result.toString();

        if (listJson.startsWith("ERROR")) {
            Toast.makeText(this, listJson, Toast.LENGTH_LONG).show();
            return;
        }

        currentTextureList = new JSONArray(listJson);
        if (currentTextureList.length() == 0) {
            Toast.makeText(this, "No textures in this IFF", Toast.LENGTH_LONG).show();
            return;
        }

        currentIffFile = iffFile;
        currentTextureIndex = 0;
        totalTextures = currentTextureList.length();

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_viewer, null);
        builder.setView(view);

        popupTitle = view.findViewById(R.id.popupTitle);
        popupInfo = view.findViewById(R.id.popupInfo);
        popupImage = view.findViewById(R.id.popupImage);
        popupFormat = view.findViewById(R.id.popupFormat);

        Button btnPrev = view.findViewById(R.id.popupPrev);
        Button btnNext = view.findViewById(R.id.popupNext);
        Button btnClose = view.findViewById(R.id.popupClose);
        Button btnExport = view.findViewById(R.id.popupExport);
        Button btnReplace = view.findViewById(R.id.popupReplace);
       
        popupTitle.setText(iffFile.getName());

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex > 0) {
                    currentTextureIndex--;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextureIndex < totalTextures - 1) {
                    currentTextureIndex++;
                    loadCurrentPopupTexture();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureDialog.dismiss();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPopupTexture();
            }
        });

        btnReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_LONG).show();
            }
        });
       
        textureDialog = builder.create();
        textureDialog.show();

        android.view.Window window = textureDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }

        loadCurrentPopupTexture();
    } catch (Exception e) {
        Toast.makeText(this, "Popup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadCurrentPopupTexture() {
    popupInfo.setText("Texture " + (currentTextureIndex + 1) + " of " + totalTextures);
    popupFormat.setText("Loading...");
    popupFormat.setTextColor(Color.parseColor("#FF9800"));
    popupImage.setImageBitmap(null);

    final String pngName = "popup_" + System.currentTimeMillis() + ".png";

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File pngFile = new File(getCacheDir(), pngName);
                if (pngFile.exists()) pngFile.delete();

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("decode_texture_by_index_from_java",
                        currentIffFile.getAbsolutePath(), currentTextureIndex, pngFile.getAbsolutePath());
                String status = result.toString();

                final Bitmap bmp = status.startsWith("Success") ? BitmapFactory.decodeFile(pngFile.getAbsolutePath()) : null;
                final String finalStatus = status;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bmp == null && totalTextures > 1
        && currentTextureIndex < totalTextures - 1) {
    currentTextureIndex++;
    loadCurrentPopupTexture();
    return;
}

if (bmp != null) {
    popupImage.setImageBitmap(bmp);
    popupFormat.setText(finalStatus);
    popupFormat.setTextColor(Color.parseColor("#00FF00"));
} else {
    popupImage.setImageBitmap(null);
    popupFormat.setText(finalStatus);
    popupFormat.setTextColor(Color.parseColor("#FF0000"));
       }
    }
});
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        popupFormat.setText("Error: " + e.getMessage());
                        popupFormat.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        }
    }).start();
}

    private void exportCurrentPopupTexture() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE,
                currentIffFile.getName().replace(".iff", "") + "_tex" + currentTextureIndex + ".png");
        startActivityForResult(intent, EXPORT_PNG_REQUEST);
    }

    private void savePopupPng(Uri saveUri) {
        try {
            File cacheDir = getCacheDir();
            File[] files = cacheDir.listFiles();
            File pngFile = null;
            if (files != null) {
                long newest = 0;
                for (File f : files) {
                    if (f.getName().startsWith("popup_") && f.getName().endsWith(".png")) {
                        if (f.lastModified() > newest) {
                            newest = f.lastModified();
                            pngFile = f;
                        }
                    }
                }
            }
            if (pngFile == null || !pngFile.exists()) {
                Toast.makeText(this, "No texture loaded", Toast.LENGTH_SHORT).show();
                return;
            }
            InputStream is = new FileInputStream(pngFile);
            OutputStream os = getContentResolver().openOutputStream(saveUri);
            if (os != null) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
            }
            is.close();
            Toast.makeText(this, "Exported to PNG", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("● Exporting IFF index " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempOutput.getAbsolutePath());

                    String resultString = result.toString();

                    if (resultString.startsWith("Success")) {
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();
                        hideProgress();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Export complete!");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        hideProgress();
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void openAudioScanner() {
        tvStatus.setText("● Scanning OBB for audio...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    Python py = Python.getInstance();
                    PyObject viewerModule = py.getModule("iff_viewer");
                    PyObject result = viewerModule.callAttr("list_audio_from_java", obbFile.getAbsolutePath());
                    final String jsonList = result.toString();

                    hideProgress();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAudioListDialog(jsonList);
                        }
                    });
                } catch (final Exception e) {
                    hideProgress();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Audio scan error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void showAudioListDialog(String jsonList) {
    try {
        if (jsonList.startsWith("ERROR")) {
            Toast.makeText(this, jsonList, Toast.LENGTH_LONG).show();
            return;
        }

        JSONArray arr = new JSONArray(jsonList);
        if (arr.length() == 0) {
            Toast.makeText(this, "No audio files in this OBB", Toast.LENGTH_LONG).show();
            return;
        }

        audioIndices.clear();
        audioNames.clear();
        audioLabels.clear();

        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            int index = obj.getInt("index");
            String name = obj.getString("name");
            audioIndices.add(index);
            audioNames.add(name);
            audioLabels.add("♪ [" + index + "] " + name);
        }

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_audio_list, null);
        builder.setView(view);

        TextView audioTitle = view.findViewById(R.id.audioTitle);
        audioTitle.setText("AUDIO FILES (" + arr.length() + ")");

        audioSearch = view.findViewById(R.id.audioSearch);
        audioSeek = view.findViewById(R.id.audioSeek);
        audioPlayPause = view.findViewById(R.id.audioPlayPause);
        audioStop = view.findViewById(R.id.audioStop);
        audioExtract = view.findViewById(R.id.audioExtract);
        audioReplace = view.findViewById(R.id.audioReplace);
        audioNowPlaying = view.findViewById(R.id.audioNowPlaying);

        ListView audioList = view.findViewById(R.id.audioList);

        audioAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, audioLabels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextColor(Color.parseColor("#DDDDDD"));
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };
        audioList.setAdapter(audioAdapter);

        // SEARCH FILTER
        audioSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().toLowerCase();
                audioAdapter.clear();
                for (int i = 0; i < audioLabels.size(); i++) {
                    if (query.isEmpty() || audioNames.get(i).toLowerCase().contains(query)) {
                        audioAdapter.add(audioLabels.get(i));
                    }
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

     audioList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String selected = (String) parent.getItemAtPosition(position);
        int realIdx = audioLabels.indexOf(selected);
        if (realIdx >= 0) {
            int idx = audioIndices.get(realIdx);
            String name = audioNames.get(realIdx);
            if (name.toLowerCase().endsWith(".bin")) {
                openBinAudioDialog(idx, name);
            } else {
                currentAudioIndex = idx;
                currentAudioName = name;
                audioNowPlaying.setText("Selected: " + currentAudioName);
                audioPlayPause.setText("▶ PLAY");
                isPlaying = false;
                stopAudio();
            }
        }
    }
});

        // PLAY / PAUSE
        audioPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentAudioIndex < 0) {
                    Toast.makeText(MainActivity.this, "Tap a file first", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (isPlaying && mediaPlayer != null) {
                    mediaPlayer.pause();
                    isPlaying = false;
                    audioPlayPause.setText("▶ PLAY");
                } else if (mediaPlayer != null && !isPlaying) {
                    mediaPlayer.start();
                    isPlaying = true;
                    audioPlayPause.setText("⏸ PAUSE");
                    startSeekUpdate();
                } else {
                    loadAndPlayAudio(currentAudioIndex, currentAudioName);
                }
            }
        });

        // STOP
        audioStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
                audioNowPlaying.setText("Stopped");
                audioPlayPause.setText("▶ PLAY");
                isPlaying = false;
                audioSeek.setProgress(0);
            }
        });

        // EXTRACT
        audioExtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentAudioIndex < 0) {
                    Toast.makeText(MainActivity.this, "Tap a file first", Toast.LENGTH_SHORT).show();
                    return;
                }
                askWhereToSaveAudio();
            }
        });

        // REPLACE
        audioReplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Replace coming in V2", Toast.LENGTH_SHORT).show();
            }
        });

        // CLOSE
        view.findViewById(R.id.audioClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
                audioDialog.dismiss();
            }
        });

        audioDialog = builder.create();
        audioDialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface dialog) {
                stopAudio();
            }
        });
        audioDialog.show();

        android.view.Window window = audioDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
        }

        tvStatus.setText("● Found " + arr.length() + " audio files");
        tvStatus.setTextColor(Color.parseColor("#00FF00"));
    } catch (Exception e) {
        Toast.makeText(this, "Audio dialog error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void loadAndPlayAudio(final int index, final String displayName) {
    audioNowPlaying.setText("Loading " + displayName + "...");
    audioPlayPause.setText("▶ PLAY");

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                File obbFile = new File(getFilesDir() + "/backups/input.obb");
                File oggFile = new File(getCacheDir(), "playback_" + index + ".ogg");

                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("extract_audio_from_java",
                        obbFile.getAbsolutePath(), index, oggFile.getAbsolutePath());
                String status = result.toString();

                if (!status.startsWith("Success")) {
                    final String err = status;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            audioNowPlaying.setText("Error: " + err);
                        }
                    });
                    return;
                }

                stopAudio();

                mediaPlayer = new android.media.MediaPlayer();
                mediaPlayer.setDataSource(oggFile.getAbsolutePath());
                mediaPlayer.prepare();
                mediaPlayer.start();

                mediaPlayer.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(android.media.MediaPlayer mp) {
                        isPlaying = false;
                        audioPlayPause.setText("▶ PLAY");
                        audioSeek.setProgress(0);
                    }
                });

                final int duration = mediaPlayer.getDuration() / 1000;
                audioSeek.setMax(mediaPlayer.getDuration());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        isPlaying = true;
                        audioPlayPause.setText("⏸ PAUSE");
                        audioNowPlaying.setText("▶ " + displayName + "  (" + duration + "s)");
                        startSeekUpdate();
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        audioNowPlaying.setText("Play error: " + e.getMessage());
                    }
                });
            }
        }
    }).start();
}

private void startSeekUpdate() {
    if (seekRunnable != null) seekHandler.removeCallbacks(seekRunnable);

    seekRunnable = new Runnable() {
        @Override
        public void run() {
            try {
                if (mediaPlayer != null && isPlaying) {
                    audioSeek.setProgress(mediaPlayer.getCurrentPosition());
                    seekHandler.postDelayed(this, 500);
                }
            } catch (Exception ignored) {}
        }
    };
    seekHandler.post(seekRunnable);

    audioSeek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser && mediaPlayer != null) {
                mediaPlayer.seekTo(progress);
            }
        }

        @Override
        public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

        @Override
        public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
    });
}

private void stopAudio() {
    try {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    } catch (Exception ignored) {}
    if (seekRunnable != null) {
        seekHandler.removeCallbacks(seekRunnable);
        seekRunnable = null;
    }
    isPlaying = false;
}

private void askWhereToSaveAudio() {
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("audio/ogg");
    intent.putExtra(Intent.EXTRA_TITLE, currentAudioName.endsWith(".ogg") ? currentAudioName : currentAudioName + ".ogg");
    startActivityForResult(intent, EXPORT_AUDIO_REQUEST);
}

private void saveAudioToFile(Uri saveUri) {
    try {
        File oggFile = new File(getCacheDir(), "playback_" + currentAudioIndex + ".ogg");
        if (!oggFile.exists()) {
            Toast.makeText(this, "Audio not loaded", Toast.LENGTH_SHORT).show();
            return;
        }
        InputStream is = new FileInputStream(oggFile);
        OutputStream os = getContentResolver().openOutputStream(saveUri);
        if (os != null) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
        }
        is.close();
        Toast.makeText(this, "Audio extracted", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
        Toast.makeText(this, "Extract error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1500);
                    boolean serverSaysAuthorized = true;
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("SUCCESS"); }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("LOCKED"); }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { updateUIState("LOCKED"); }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);

        InputStream inputStream = getContentResolver().openInputStream(uri);

        long totalSize = 0;
        try {
            android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (sizeIndex != -1) totalSize = cursor.getLong(sizeIndex);
                cursor.close();
            }
        } catch (Exception ignored) {}

        if (isBackup && file.exists() && totalSize > 0 && file.length() == totalSize) {
            return file;
        }

        if (file.exists()) file.delete();

        showProgress();
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[65536];
        long copied = 0;
        int length;
        int lastPercent = -1;

        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
            copied += length;
            if (totalSize > 0) {
                int percent = (int) ((copied * 100) / totalSize);
                if (percent != lastPercent && percent % 2 == 0) {
                    lastPercent = percent;
                    updateProgressBar(percent);
                }
            }
        }
        inputStream.close();
        outputStream.close();

        if (totalSize > 0 && file.length() != totalSize) {
            file.delete();
            throw new Exception("Copy incomplete: got " + file.length() + " of " + totalSize + " bytes");
        }

        return file;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

private void showTextureListDialog() {
    try {
        final ArrayList<Integer> texIndices = new ArrayList<>();
        final ArrayList<String> texLabels = new ArrayList<>();

        for (int i = 0; i < currentTextureList.length(); i++) {
            JSONObject obj = currentTextureList.getJSONObject(i);
            int w = obj.optInt("width", 0);
            int h = obj.optInt("height", 0);
            String fmt = obj.optString("format", "?");
            boolean decodable = obj.optBoolean("decodable", false);
            String prefix = (i == currentTextureIndex) ? "▶ " : (decodable ? "  " : "✗ ");
            String editableTag = decodable ? "✓" : "✗";
            texLabels.add(prefix + "[" + i + "]  " + w + "×" + h + "  •  " + fmt + "  " + editableTag);
            texIndices.add(i);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, texLabels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t = v.findViewById(android.R.id.text1);
                t.setTextColor(Color.parseColor("#DDDDDD"));
                t.setTextSize(11f);
                t.setPadding(20, 20, 20, 20);
                return v;
            }
        };

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_texture_list, null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.texListTitle);
        title.setText("TEXTURES (" + currentTextureList.length() + ")  —  current: " + currentTextureIndex);

        popupTextureList = view.findViewById(R.id.texList);
        popupTextureList.setAdapter(adapter);

        popupTextureList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                currentTextureIndex = texIndices.get(position);
                textureListDialog.dismiss();
                openTexturePopup(currentIffFile);
            }
        });

        view.findViewById(R.id.texListClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textureListDialog.dismiss();
            }
        });

        textureListDialog = builder.create();
        textureListDialog.show();

        android.view.Window window = textureListDialog.getWindow();
        if (window != null) {
            window.setLayout(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                Color.parseColor("#1A1A1A")));
        }
    } catch (Exception e) {
        Toast.makeText(this, "Texture list error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
}

private void fetchTextureListAndShow(final File iffFile) {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                Python py = Python.getInstance();
                PyObject viewerModule = py.getModule("iff_viewer");
                PyObject result = viewerModule.callAttr("list_textures_from_java", iffFile.getAbsolutePath());
                String listJson = result.toString();

                if (listJson.startsWith("ERROR")) {
                    final String err = listJson;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, err, Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                currentTextureList = new JSONArray(listJson);
                if (currentTextureList.length() == 0) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "No textures", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }

                currentIffFile = iffFile;
                currentTextureIndex = 0;
                totalTextures = currentTextureList.length();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showTextureListDialog();
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void openBinAudioDialog(final int binIndex, final String binName) {
        Toast.makeText(this, "BIN audio: " + binName + " (parsing coming soon)", Toast.LENGTH_LONG).show();
    }

    private void showProgress() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (progressBar != null) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setIndeterminate(true);
                }
            }
        });
    }

    private void hideProgress() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }

private void askForBatchFolder() {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivityForResult(intent, BATCH_FOLDER_REQUEST);
}

private void extractBatchToFolder(Uri treeUri) {
    if (selectedFileIndices.size() == 0) return;

    final ArrayList<Integer> toExtract = new ArrayList<>(selectedFileIndices);

    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            tvStatus.setText("● Extracting " + toExtract.size() + " files...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            showProgress();
        }
    });

    new Thread(new Runnable() {
        @Override
        public void run() {
            File obbFile = new File(getFilesDir() + "/backups/input.obb");
            Python py = Python.getInstance();
            PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");

            int success = 0;
            int fail = 0;

            for (int i = 0; i < toExtract.size(); i++) {
                int idx = toExtract.get(i);
                try {
                    // Find the filename from allLabels (may be different)
                    String filename = "extracted_" + idx + ".iff";

                    // Extract to temp
                    File tempFile = new File(getCacheDir(), "batch_" + idx + ".iff");
                    PyObject result = obbModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), idx, tempFile.getAbsolutePath());

                    if (result.toString().startsWith("Success")) {
                        // Create destination file in the SAF folder
                        String displayName = "extracted_" + idx + ".iff";
                        // Try to get proper name from CSV - use the label we stored
                        // For now, use index-based name
                        android.net.Uri docUri = android.provider.DocumentsContract.createDocument(
                                getContentResolver(),
                                android.provider.DocumentsContract.buildDocumentUriUsingTree(
                                        treeUri,
                                        android.provider.DocumentsContract.getTreeDocumentId(treeUri)),
                                "application/octet-stream",
                                displayName);

                        if (docUri != null) {
                            java.io.InputStream is = new java.io.FileInputStream(tempFile);
                            java.io.OutputStream os = getContentResolver().openOutputStream(docUri);
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) {
                                os.write(buffer, 0, len);
                            }
                            os.close();
                            is.close();
                            success++;
                        } else {
                            fail++;
                        }
                        tempFile.delete();
                    } else {
                        fail++;
                    }
                } catch (Exception e) {
                    fail++;
                }
            }

            final int s = success;
            final int f = fail;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    hideProgress();
                    tvStatus.setText("● Batch extract: " + s + " success, " + f + " failed");
                    tvStatus.setTextColor(Color.parseColor("#00FF00"));
                    Toast.makeText(MainActivity.this,
                        "Extracted " + s + " of " + (s + f) + " files",
                        Toast.LENGTH_LONG).show();

                    selectedFileIndices.clear();
                    fileSelectionMode = false;
                    if (fileListAdapter != null) fileListAdapter.notifyDataSetChanged();
                    updateExtractButton();
                    if (fileListDialog != null && fileListDialog.isShowing()) {
                        fileListDialog.dismiss();
                    }
                }
            });
        }
    }).start();
}

}
