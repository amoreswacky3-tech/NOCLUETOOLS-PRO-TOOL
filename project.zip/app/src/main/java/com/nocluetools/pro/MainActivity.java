package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnRunParser;
    private Button btnExportIff;
    private boolean isAuthorized = false;

    // Hardcoded to 0 for now. In V2, you will let the user pick from a list.
    private int selectedIffIndex = 0; 

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnRunParser = findViewById(R.id.btnRunParser);
        btnExportIff = findViewById(R.id.btnExportIff);

        tvOutput.setText(""); // Removes the placeholder text
        updateUIState("PROCESSING");

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnRunParser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri == null || iffUri == null) {
                    Toast.makeText(MainActivity.this, "Please select both files first!", Toast.LENGTH_LONG).show();
                    return;
                }
                runPythonParser();
            }
        });

        // NEW: Export Button Listener
        btnExportIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri != null) {
                    askUserWhereToSave();
                } else {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnRunParser.setEnabled(false);
            btnExportIff.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("Hello Master! Ready to parse.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnRunParser.setEnabled(true);
            btnExportIff.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("This app is cloned or modded. Please download from the origin of this APK.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnRunParser.setEnabled(false);
            btnExportIff.setEnabled(false);
            tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.\n\nThis application has been locked due to a signature mismatch or unauthorized modification.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (requestCode == REQUEST_OBB) {
                obbUri = uri;
                tvStatus.setText("OBB selected. Backing up (this may take a while)...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                processObbBackupAndInspect();
            } else if (requestCode == REQUEST_IFF) {
                iffUri = uri;
                tvStatus.setText("IFF selected. Copying...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            copyUriToInternalStorage(iffUri, "input.iff", true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    checkReadyToRun();
                                }
                            });
                        } catch (Exception e) {
                            final String error = e.getMessage();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    tvStatus.setText("Error copying IFF: " + error);
                                    tvStatus.setTextColor(Color.parseColor("#FF0000"));
                                }
                            });
                        }
                    }
                }).start();
            } else if (requestCode == CREATE_FILE_REQUEST) {
                // NEW: User picked where to save the exported IFF
                exportIffToFile(uri);
            }
        }
    }

    // NEW: Ask user where to save the exported file
    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    // NEW: Export the IFF using the Python bridge function
    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("Exporting IFF (Index: " + selectedIffIndex + ")...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");
                    
                    // Call the Python bridge function we added to nba2k20_obb.py
                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java", 
                                                        obbFile.getAbsolutePath(),
                                                        selectedIffIndex, 
                                                        tempOutput.getAbsolutePath());
                    
                    String resultString = result.toString();
                    
                    if (resultString.startsWith("Success")) {
                        // Copy the temp file to the user's chosen location
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();
                        
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("Export complete! Check your files.");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText(err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void processObbBackupAndInspect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Backup complete. Inspecting OBB...");
                            tvStatus.setTextColor(Color.parseColor("#FF9800"));
                        }
                    });

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                    final String obbSummary = result.toString(); 

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(obbSummary);
                            checkReadyToRun();
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("Error backing up OBB: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void checkReadyToRun() {
        if (obbUri != null && iffUri != null) {
            tvStatus.setText("Files ready. Checking server authorization...");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            performServerCheck();
        }
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000); 
                    boolean serverSaysAuthorized = true; 
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateUIState("SUCCESS");
                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateUIState("LOCKED");
                            }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateUIState("LOCKED");
                        }
                    });
                }
            }
        }).start();
    }

    private void runPythonParser() {
        tvOutput.setText("Processing... Please wait.");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File iffFile = new File(getFilesDir() + "/backups/input.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("run_tool", obbFile.getAbsolutePath(), iffFile.getAbsolutePath());
                    
                    final String output = result.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(output);
                            tvStatus.setText("Parsing Complete!");
                            tvStatus.setTextColor(Color.parseColor("#00FF00"));
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText("Error: " + e.getMessage());
                            tvStatus.setText("Parsing Failed.");
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir, fileName);
        if (isBackup && file.exists()) {
            return file; 
        }
        InputStream inputStream = getContentResolver().openInputStream(uri);
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[4096];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.close();
        return file;
    }
}