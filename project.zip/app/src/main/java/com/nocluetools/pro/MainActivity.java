package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Uri obbUri = null;
    private Uri iffUri = null;
    private TextView tvOutput;
    private TextView tvStatus;
    private Button btnSelectObb;
    private Button btnSelectIff;
    private Button btnExportIff;
    private ListView listFiles;
    private ImageView imgPreview;
    private ArrayAdapter<String> listAdapter;
    private final List<Integer> fileIndices = new ArrayList<>();

    private boolean isAuthorized = false;
    private int selectedIffIndex = 0;
    private boolean obbLoaded = false;

    private static final int REQUEST_OBB = 1;
    private static final int REQUEST_IFF = 2;
    private static final int CREATE_FILE_REQUEST = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        tvStatus = findViewById(R.id.tvStatus);
        btnSelectObb = findViewById(R.id.btnSelectObb);
        btnSelectIff = findViewById(R.id.btnSelectIff);
        btnExportIff = findViewById(R.id.btnExportIff);
        listFiles = findViewById(R.id.listFiles);
        imgPreview = findViewById(R.id.imgPreview);

        tvOutput.setText("");
        updateUIState("PROCESSING");

        listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text = (TextView) view.findViewById(android.R.id.text1);
                text.setTextColor(Color.parseColor("#DDDDDD"));
                text.setTextSize(11f);
                text.setPadding(20, 20, 20, 20);
                return view;
            }
        };
        listFiles.setAdapter(listAdapter);

        // AUTO-PREVIEW when user taps a file in the list
        listFiles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedIffIndex = fileIndices.get(position);
                autoPreviewFromObb();
            }
        });

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        btnSelectObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_OBB);
            }
        });

        btnSelectIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IFF);
            }
        });

        btnExportIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obbUri != null) {
                    askUserWhereToSave();
                } else {
                    Toast.makeText(MainActivity.this, "Please select an OBB first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        performServerCheck();
    }

    private void updateUIState(String state) {
        if (state.equals("PROCESSING")) {
            tvStatus.setText("● Checking authorization... Please wait.");
            tvStatus.setTextColor(Color.parseColor("#FF9800"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
        } else if (state.equals("SUCCESS")) {
            tvStatus.setText("● Hello Master! Ready.");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
            btnSelectObb.setEnabled(true);
            btnSelectIff.setEnabled(true);
            btnExportIff.setEnabled(true);
        } else if (state.equals("LOCKED")) {
            tvStatus.setText("● This app is cloned or modded. Please download from the origin of this APK.");
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
            btnSelectObb.setEnabled(false);
            btnSelectIff.setEnabled(false);
            btnExportIff.setEnabled(false);
            tvOutput.setText("❌ UNAUTHORIZED COPY DETECTED.");
            tvOutput.setTextColor(Color.parseColor("#FF0000"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (requestCode == REQUEST_OBB) {
                obbUri = uri;
                tvStatus.setText("● OBB selected. Backing up...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                processObbBackupAndInspect();
            } else if (requestCode == REQUEST_IFF) {
                iffUri = uri;
                tvStatus.setText("● IFF selected. Copying and previewing...");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            File copied = copyUriToInternalStorage(iffUri, "standalone.iff", true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // AUTO-PREVIEW the standalone IFF immediately
                                    autoPreviewStandalone(copied);
                                }
                            });
                        } catch (Exception e) {
                            final String error = e.getMessage();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    tvStatus.setText("● Error copying IFF: " + error);
                                    tvStatus.setTextColor(Color.parseColor("#FF0000"));
                                }
                            });
                        }
                    }
                }).start();
            } else if (requestCode == CREATE_FILE_REQUEST) {
                exportIffToFile(uri);
            }
        }
    }

    // ============= AUTO PREVIEW FROM OBB =============
    private void autoPreviewFromObb() {
        tvStatus.setText("● Loading texture " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempIff = new File(getCacheDir(), "preview_source.iff");
                    File pngFile = new File(getCacheDir(), "texture_preview.png");

                    Python py = Python.getInstance();
                    PyObject obbModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject exportResult = obbModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempIff.getAbsolutePath());

                    if (!exportResult.toString().startsWith("Success")) {
                        final String err = exportResult.toString();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                        return;
                    }

                    renderPreview(tempIff, pngFile);
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Preview Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    // ============= AUTO PREVIEW STANDALONE IFF =============
    private void autoPreviewStandalone(File iffFile) {
        tvStatus.setText("● Loading texture from standalone IFF...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));

        new Thread(new Runnable() {
            @Override
            public void run() {
                File pngFile = new File(getCacheDir(), "texture_preview.png");
                renderPreview(iffFile, pngFile);
            }
        }).start();
    }

    // ============= SHARED RENDER LOGIC =============
    private void renderPreview(File iffFile, File pngFile) {
        try {
            Python py = Python.getInstance();
            PyObject viewerModule = py.getModule("iff_viewer");
            PyObject previewResult = viewerModule.callAttr("preview_texture_from_java",
                    iffFile.getAbsolutePath(), pngFile.getAbsolutePath());

            String previewStatus = previewResult.toString();
            if (previewStatus.startsWith("Success")) {
                final Bitmap bitmap = BitmapFactory.decodeFile(pngFile.getAbsolutePath());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bitmap != null) {
                            imgPreview.setImageBitmap(bitmap);
                            tvStatus.setText("● " + previewStatus);
                            tvStatus.setTextColor(Color.parseColor("#00FF00"));
                        } else {
                            tvStatus.setText("● PNG decode failed");
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    }
                });
            } else {
                final String err = previewStatus;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("● " + err);
                        tvStatus.setTextColor(Color.parseColor("#FF0000"));
                    }
                });
            }
        } catch (final Exception e) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvStatus.setText("● Preview Error: " + e.getMessage());
                    tvStatus.setTextColor(Color.parseColor("#FF0000"));
                }
            });
        }
    }

    private void askUserWhereToSave() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "extracted_" + selectedIffIndex + ".iff");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void exportIffToFile(Uri saveUri) {
        tvStatus.setText("● Exporting IFF index " + selectedIffIndex + "...");
        tvStatus.setTextColor(Color.parseColor("#FF9800"));

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = new File(getFilesDir() + "/backups/input.obb");
                    File tempOutput = new File(getCacheDir(), "temp_extracted.iff");

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("obb_tools.nba2k20_obb");
                    PyObject result = pyModule.callAttr("export_iff_from_java",
                            obbFile.getAbsolutePath(), selectedIffIndex, tempOutput.getAbsolutePath());

                    String resultString = result.toString();

                    if (resultString.startsWith("Success")) {
                        InputStream is = new FileInputStream(tempOutput);
                        OutputStream os = getContentResolver().openOutputStream(saveUri);
                        if (os != null) {
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = is.read(buffer)) > 0) { os.write(buffer, 0, len); }
                            os.close();
                        }
                        is.close();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● Export complete!");
                                tvStatus.setTextColor(Color.parseColor("#00FF00"));
                            }
                        });
                    } else {
                        final String err = resultString;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvStatus.setText("● " + err);
                                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                            }
                        });
                    }
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Export Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void processObbBackupAndInspect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File obbFile = copyUriToInternalStorage(obbUri, "input.obb", true);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Backup complete. Loading file list...");
                            tvStatus.setTextColor(Color.parseColor("#FF9800"));
                        }
                    });

                    Python py = Python.getInstance();
                    PyObject pyModule = py.getModule("iff_viewer");
                    PyObject result = pyModule.callAttr("inspect_obb", obbFile.getAbsolutePath());
                    final String obbSummary = result.toString();

                    PyObject listResult = pyModule.callAttr("get_file_list_from_java", obbFile.getAbsolutePath());
                    final String listJson = listResult.toString();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvOutput.setText(obbSummary);
                            populateFileList(listJson);
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvStatus.setText("● Error: " + e.getMessage());
                            tvStatus.setTextColor(Color.parseColor("#FF0000"));
                        }
                    });
                }
            }
        }).start();
    }

    private void populateFileList(String jsonString) {
        try {
            listAdapter.clear();
            fileIndices.clear();

            if (jsonString.startsWith("ERROR:")) {
                tvStatus.setText("● " + jsonString);
                tvStatus.setTextColor(Color.parseColor("#FF0000"));
                return;
            }

            JSONArray arr = new JSONArray(jsonString);
            int knownCount = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                int index = obj.getInt("index");
                String name = obj.getString("name");
                String type = obj.getString("type");
                boolean editable = obj.getBoolean("editable");

                String prefix = editable ? "▶ " : "  ";
                String label = prefix + "[" + index + "] " + name + "  (" + type + ")";
                listAdapter.add(label);
                fileIndices.add(index);

                if (!name.matches("^[0-9a-f]{8}$")) knownCount++;
            }

            tvStatus.setText("● Loaded " + arr.length() + " files (" + knownCount + " named)");
            tvStatus.setTextColor(Color.parseColor("#00FF00"));
        } catch (Exception e) {
            tvStatus.setText("● List error: " + e.getMessage());
            tvStatus.setTextColor(Color.parseColor("#FF0000"));
        }
    }

    private void performServerCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                    boolean serverSaysAuthorized = true;
                    if (serverSaysAuthorized) {
                        isAuthorized = true;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("SUCCESS"); }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { updateUIState("LOCKED"); }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { updateUIState("LOCKED"); }
                    });
                }
            }
        }).start();
    }

    private File copyUriToInternalStorage(Uri uri, String fileName, boolean isBackup) throws Exception {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);
        if (isBackup && file.exists()) return file;
        InputStream inputStream = getContentResolver().openInputStream(uri);
        FileOutputStream outputStream = new FileOutputStream(file);
        byte[] buffer = new byte[4096];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.close();
        return file;
      }
   }