package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends AppCompatActivity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private TextView tvStatusBar, tvTeamName, tvTeamSectionValue, tvHint;
    private ListView listViewRecords;
    private EditText etSearchPlayer;

    private File activeDatabaseFile;
    private final List<PlayerRow> allPlayers = new ArrayList<>();
    private final List<PlayerRow> filteredPlayers = new ArrayList<>();
    private PlayerAdapter adapter;
    private int selectedPlayerId = -1;

    private String playerTable  = "Player";
    private String colId        = "id";
    private String colFirst     = "firstname";
    private String colLast      = "lastname";
    private String colJersey    = "jersey";
    private String colOvr       = null;
    private String colCf        = null;
    private String lastSchemaDump = "";

    private static class PlayerRow {
        int id; String name; int jersey; String ovr; String cf;
        PlayerRow(int i, String n, int j, String o, String c) {
            id = i; name = n; jersey = j; ovr = o; cf = c;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_editor);

        tvStatusBar         = findViewById(R.id.tvStatusBar);
        tvTeamName          = findViewById(R.id.tvTeamName);
        tvTeamSectionValue  = findViewById(R.id.tvTeamSectionValue);
        tvHint              = findViewById(R.id.tvHint);
        listViewRecords     = findViewById(R.id.listViewRecords);
        etSearchPlayer      = findViewById(R.id.etSearchPlayer);

        Button btnOpen            = findViewById(R.id.btnOpen);
        Button btnSave            = findViewById(R.id.btnSave);
        Button btnTeamDatabase    = findViewById(R.id.btnTeamDatabase);
        Button btnFreeAgent       = findViewById(R.id.btnFreeAgentManager);
        Button btnRotation        = findViewById(R.id.btnRotationSettings);
        Button btnValidator       = findViewById(R.id.btnRosterValidator);
        View   dropdownTeam       = findViewById(R.id.dropdownTeam);
        View   dropdownTeamSect   = findViewById(R.id.dropdownTeamSection);

        adapter = new PlayerAdapter();
        listViewRecords.setAdapter(adapter);

        // Taps come in wave 2 — placeholder toasts for now
        View.OnClickListener comingSoon = v -> {
            String label = v instanceof Button ? ((Button) v).getText().toString() : "Section";
            Toast.makeText(this, label + " — coming in next build", Toast.LENGTH_SHORT).show();
        };

        btnOpen.setOnClickListener(v -> pickRosterFile());
        btnSave.setOnClickListener(v -> saveAsNew());
        btnTeamDatabase.setOnClickListener(comingSoon);
        btnFreeAgent.setOnClickListener(comingSoon);
        btnRotation.setOnClickListener(comingSoon);
        btnValidator.setOnClickListener(comingSoon);
        dropdownTeam.setOnClickListener(comingSoon);
        dropdownTeamSect.setOnClickListener(comingSoon);

        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < filteredPlayers.size()) {
                selectedPlayerId = filteredPlayers.get(position).id;
                tvStatusBar.setText("Selected: " + filteredPlayers.get(position).name);
            }
        });
        listViewRecords.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < filteredPlayers.size()) {
                PlayerRow p = filteredPlayers.get(position);
                Toast.makeText(this, "Long-press edit: " + p.name + " (wave 2)",
                        Toast.LENGTH_SHORT).show();
            }
            return true;
        });

        etSearchPlayer.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { applyFilter(s.toString()); }
        });
    }

    // ------------------------------------------------------------------
    // File picker
    // ------------------------------------------------------------------
    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            loadRosterDatabase(data.getData());
        }
    }

    // ------------------------------------------------------------------
    // Load
    // ------------------------------------------------------------------
    private void loadRosterDatabase(Uri uri) {
        SQLiteDatabase db = null;
        try {
            File dst = new File(getCacheDir(), "editable_roster.ros");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new Exception("cannot open URI");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            activeDatabaseFile = dst;

            db = SQLiteDatabase.openDatabase(dst.getAbsolutePath(), null, SQLiteDatabase.OPEN_READWRITE);
            detectSchema(db);

            allPlayers.clear();
            String sql = "SELECT " + colId + ", " + colFirst + ", " + colLast
                    + (colJersey != null ? ", " + colJersey : "")
                    + (colOvr != null ? ", " + colOvr : "")
                    + (colCf != null ? ", " + colCf : "")
                    + " FROM " + playerTable
                    + " ORDER BY " + colId;

            try (Cursor c = db.rawQuery(sql, null)) {
                while (c.moveToNext()) {
                    int idx = 0;
                    int id = c.getInt(idx++);
                    String f = c.getString(idx++); if (f == null) f = "";
                    String l = c.getString(idx++); if (l == null) l = "";
                    int jersey = 0;
                    if (colJersey != null && !c.isNull(idx)) jersey = c.getInt(idx);
                    if (colJersey != null) idx++;
                    String ovr = "—";
                    if (colOvr != null && !c.isNull(idx)) ovr = String.valueOf(c.getInt(idx));
                    if (colOvr != null) idx++;
                    String cf = "—";
                    if (colCf != null && !c.isNull(idx)) cf = String.valueOf(c.getInt(idx));
                    if (colCf != null) idx++;
                    allPlayers.add(new PlayerRow(id, (f + " " + l).trim(), jersey, ovr, cf));
                }
            }

            applyFilter(etSearchPlayer.getText().toString());
            tvHint.setText("Loaded " + allPlayers.size() + " players · table=" + playerTable);
            tvStatusBar.setText("Ready");
        } catch (Exception e) {
            Log.e(TAG, "load failed", e);
            tvStatusBar.setText("Error: " + e.getMessage());
            toast("Error: " + e.getMessage());
        } finally {
            if (db != null) db.close();
        }
    }

    private void applyFilter(String q) {
        String query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        filteredPlayers.clear();
        if (query.isEmpty()) {
            filteredPlayers.addAll(allPlayers);
        } else {
            for (PlayerRow p : allPlayers) {
                if (p.name.toLowerCase(Locale.ROOT).contains(query)
                        || String.valueOf(p.id).contains(query)
                        || String.valueOf(p.jersey).contains(query)) {
                    filteredPlayers.add(p);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    // ------------------------------------------------------------------
    // Schema detection (silent for now — we only use it to pick columns)
    // ------------------------------------------------------------------
    private void detectSchema(SQLiteDatabase db) {
        List<String> tables = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)) {
            while (c.moveToNext()) tables.add(c.getString(0));
        }
        StringBuilder dump = new StringBuilder();
        for (String t : tables) {
            try (Cursor c = db.rawQuery("PRAGMA table_info(`" + t + "`)", null)) {
                StringBuilder sb = new StringBuilder();
                while (c.moveToNext()) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(c.getString(1)).append("(").append(c.getString(2)).append(")");
                }
                dump.append(t).append(" -> [").append(sb).append("]\n");
            }
        }
        String best = null;
        for (String t : tables) if (t.equalsIgnoreCase("Player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.equalsIgnoreCase("players")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("roster")) { best = t; break; }
        if (best != null) playerTable = best;

        try (Cursor c = db.rawQuery("PRAGMA table_info(`" + playerTable + "`)", null)) {
            List<String> names = new ArrayList<>();
            while (c.moveToNext()) names.add(c.getString(1));
            colId     = findCol(names, "id", "playerid", "player_id", "pid", "rowid");
            colFirst  = findCol(names, "firstname", "first_name", "fname", "givenname");
            colLast   = findCol(names, "lastname", "last_name", "lname", "surname", "familyname");
            colJersey = findCol(names, "jersey", "jerseynum", "jerseynumber", "number");
            colOvr    = findCol(names, "overall", "ovr", "rating", "playeroverall");
            colCf     = findCol(names, "cfid", "cyberfaceid", "cf", "faceid", "portraitid");
        }
        if (colId == null) colId = "id";
        if (colFirst == null) colFirst = "firstname";
        if (colLast == null) colLast = "lastname";
        lastSchemaDump = dump.toString();
        Log.d(TAG, "schema:\n" + dump);
    }

    private static String findCol(List<String> names, String... aliases) {
        for (String a : aliases)
            for (String n : names)
                if (a.equalsIgnoreCase(n)) return n;
        return null;
    }

    // ------------------------------------------------------------------
    // Save (unchanged behavior — writes to Downloads/NBA2K20Editor)
    // ------------------------------------------------------------------
    private void saveAsNew() {
        File src = activeDatabaseFile;
        if (src == null || !src.exists()) { toast("Open a .ros first."); return; }
        try {
            File target = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "NBA2K20Editor");
            if (!target.exists()) target.mkdirs();
            File out = new File(target, "Modded_Roster_" + System.currentTimeMillis() + ".ros");
            copy(src, out);

            byte[] hash = md5(out);
            File usr = new File(target, "myprofile.usr");
            if (usr.exists() && usr.length() >= 0x34) {
                try (RandomAccessFile raf = new RandomAccessFile(usr, "rw")) {
                    raf.seek(0x30);
                    raf.write(hash, 0, 4);
                }
            }
            toast("Saved: " + out.getName());
        } catch (Exception e) {
            toast("Save failed: " + e.getMessage());
        }
    }

    private static void copy(File s, File d) throws Exception {
        try (InputStream in = new FileInputStream(s);
             FileOutputStream out = new FileOutputStream(d)) {
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        }
    }

    private static byte[] md5(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) md.update(b, 0, n);
        }
        return md.digest();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------
    // Adapter
    // ------------------------------------------------------------------
    private class PlayerAdapter extends ArrayAdapter<PlayerRow> {
        PlayerAdapter() { super(RosterEditorActivity.this, 0, filteredPlayers); }

        @NonNull @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(RosterEditorActivity.this)
                        .inflate(R.layout.item_player_row, parent, false);
            }
            PlayerRow p = filteredPlayers.get(position);
            ((TextView) convertView.findViewById(R.id.rowName)).setText(p.name);
            ((TextView) convertView.findViewById(R.id.rowJersey)).setText(String.valueOf(p.jersey));
            ((TextView) convertView.findViewById(R.id.rowOvr)).setText(p.ovr);
            ((TextView) convertView.findViewById(R.id.rowCf)).setText(p.cf);
            return convertView;
        }
    }
}