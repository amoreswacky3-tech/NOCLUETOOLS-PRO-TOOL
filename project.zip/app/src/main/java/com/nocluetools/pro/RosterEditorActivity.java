package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RosterEditorActivity extends AppCompatActivity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private TextView tvSectionName, tvStatusBar, tvHint, tvCurrentFile;
    private TextView navHome, navRoster, navTeams, navPlayers, navTools;
    private View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;
    private ListView listViewRecords;
    private EditText etSearchPlayer;

    private File activeDatabaseFile;
    private final List<PlayerRow> allPlayers = new ArrayList<>();
    private final List<PlayerRow> filteredPlayers = new ArrayList<>();
    private PlayerAdapter adapter;
    private int selectedPlayerId = -1;

    private String playerTable = "Player";
    private String colId = "id";
    private String colFirst = "firstname";
    private String colLast = "lastname";
    private String colJersey = "jersey";
    private String colOvr = null;
    private String colCf = null;

    private static class PlayerRow {
        int id;
        String name;
        int jersey;
        String ovr;
        String cf;
        PlayerRow(int i, String n, int j, String o, String c) {
            id = i; name = n; jersey = j; ovr = o; cf = c;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster_editor);

        tvSectionName   = findViewById(R.id.tvSectionName);
        tvStatusBar     = findViewById(R.id.tvStatusBar);
        tvHint          = findViewById(R.id.tvHint);
        tvCurrentFile   = findViewById(R.id.tvCurrentFile);
        listViewRecords = findViewById(R.id.listViewRecords);
        etSearchPlayer  = findViewById(R.id.etSearchPlayer);

        panelHome    = findViewById(R.id.panelHome);
        panelRoster  = findViewById(R.id.panelRoster);
        panelTeams   = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools   = findViewById(R.id.panelTools);

        navHome    = findViewById(R.id.navHome);
        navRoster  = findViewById(R.id.navRoster);
        navTeams   = findViewById(R.id.navTeams);
        navPlayers = findViewById(R.id.navPlayers);
        navTools   = findViewById(R.id.navTools);

        navHome.setOnClickListener(v    -> selectTab(0));
        navRoster.setOnClickListener(v  -> selectTab(1));
        navTeams.setOnClickListener(v   -> selectTab(2));
        navPlayers.setOnClickListener(v -> selectTab(3));
        navTools.setOnClickListener(v   -> selectTab(4));

        findViewById(R.id.btnHomeOpenRoster).setOnClickListener(v  -> selectTab(1));
        findViewById(R.id.btnHomePlayerLab).setOnClickListener(v   -> selectTab(3));
        findViewById(R.id.btnHomeTeamControl).setOnClickListener(v -> selectTab(2));
        findViewById(R.id.btnHomeTools).setOnClickListener(v       -> selectTab(4));

        findViewById(R.id.btnOpen).setOnClickListener(v -> pickRosterFile());
        findViewById(R.id.btnSave).setOnClickListener(v -> saveAsNew());

        View.OnClickListener soon = v -> toast("Coming in next build");
        findViewById(R.id.btnTeamDatabase).setOnClickListener(soon);
        findViewById(R.id.btnFreeAgentManager).setOnClickListener(soon);
        findViewById(R.id.btnRotationSettings).setOnClickListener(soon);
        findViewById(R.id.btnRosterValidator).setOnClickListener(soon);
        findViewById(R.id.dropdownTeamSection).setOnClickListener(soon);

        adapter = new PlayerAdapter();
        listViewRecords.setAdapter(adapter);
        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < filteredPlayers.size()) {
                selectedPlayerId = filteredPlayers.get(position).id;
                tvStatusBar.setText("Selected: " + filteredPlayers.get(position).name);
            }
        });
        listViewRecords.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < filteredPlayers.size()) {
                toast("Long-press edit: " + filteredPlayers.get(position).name + " (wave 2)");
            }
            return true;
        });

        etSearchPlayer.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { applyFilter(s.toString()); }
        });

        selectTab(0);
    }

    private void selectTab(int idx) {
        panelHome.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        panelRoster.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        panelTeams.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        panelPlayers.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        panelTools.setVisibility(idx == 4 ? View.VISIBLE : View.GONE);

        TextView[] navs = { navHome, navRoster, navTeams, navPlayers, navTools };
        String[] names = { "HOME", "ROSTER", "TEAMS", "PLAYERS", "TOOLS" };
        for (int i = 0; i < navs.length; i++) {
            if (i == idx) {
                navs[i].setBackgroundResource(R.drawable.bg_nav_active);
                navs[i].setTextColor(0xFFFFFFFF);
            } else {
                navs[i].setBackgroundResource(R.drawable.bg_nav_inactive);
                navs[i].setTextColor(0xFF6B7280);
            }
        }
        tvSectionName.setText(names[idx]);
    }

    private void pickRosterFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_ROSTER_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            loadRosterDatabase(data.getData());
        }
    }

    private void loadRosterDatabase(Uri uri) {
        SQLiteDatabase db = null;
        try {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }

            File dst = new File(getCacheDir(), "editable_roster.ros");
            if (dst.exists()) dst.delete();

            long copied = 0;
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new Exception("Cannot open picked URI (null stream)");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    copied += n;
                }
            }

            if (!dst.exists() || dst.length() == 0) {
                throw new Exception("Copy produced an empty file. Pick from Downloads, not cloud.");
            }

            try (InputStream probe = new FileInputStream(dst)) {
                byte[] magic = new byte[16];
                int got = probe.read(magic);
                if (got < 16 || !new String(magic, 0, 15).equals("SQLite format 3")) {
                    throw new Exception("Not a SQLite database — header mismatch.");
                }
            }

            activeDatabaseFile = dst;
            tvCurrentFile.setText(uri.getLastPathSegment());
            db = SQLiteDatabase.openDatabase(dst.getAbsolutePath(), null, SQLiteDatabase.OPEN_READWRITE);

            detectSchema(db);

            allPlayers.clear();
            String sql = "SELECT " + colId + ", " + colFirst + ", " + colLast
                    + (colJersey != null ? ", " + colJersey : "")
                    + (colOvr    != null ? ", " + colOvr    : "")
                    + (colCf     != null ? ", " + colCf     : "")
                    + " FROM " + playerTable + " ORDER BY " + colId;

            try (Cursor c = db.rawQuery(sql, null)) {
                while (c.moveToNext()) {
                    int idx = 0;
                    int id = c.getInt(idx++);
                    String f = c.getString(idx++); if (f == null) f = "";
                    String l = c.getString(idx++); if (l == null) l = "";
                    int jersey = 0;
                    if (colJersey != null && !c.isNull(idx)) jersey = c.getInt(idx);
                    if (colJersey != null) idx++;
                    String ovr = "—";
                    if (colOvr != null && !c.isNull(idx)) ovr = String.valueOf(c.getInt(idx));
                    if (colOvr != null) idx++;
                    String cf = "—";
                    if (colCf != null && !c.isNull(idx)) cf = String.valueOf(c.getInt(idx));
                    allPlayers.add(new PlayerRow(id, (f + " " + l).trim(), jersey, ovr, cf));
                }
            }

            applyFilter(etSearchPlayer.getText().toString());
            tvHint.setText("Loaded " + allPlayers.size() + " players · table=" + playerTable);
            tvStatusBar.setText("Ready · " + copied + " bytes");
            selectTab(3);
        } catch (Exception e) {
            Log.e(TAG, "load failed", e);
            tvStatusBar.setText("Error: " + e.getMessage());
            toast("Error: " + e.getMessage());
        } finally {
            if (db != null) db.close();
        }
    }

    private void applyFilter(String q) {
        String query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        filteredPlayers.clear();
        if (query.isEmpty()) {
            filteredPlayers.addAll(allPlayers);
        } else {
            for (PlayerRow p : allPlayers) {
                if (p.name.toLowerCase(Locale.ROOT).contains(query)
                        || String.valueOf(p.id).contains(query)
                        || String.valueOf(p.jersey).contains(query)) {
                    filteredPlayers.add(p);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void detectSchema(SQLiteDatabase db) {
        List<String> tables = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)) {
            while (c.moveToNext()) tables.add(c.getString(0));
        }
        StringBuilder dump = new StringBuilder();
        for (String t : tables) {
            try (Cursor c = db.rawQuery("PRAGMA table_info(`" + t + "`)", null)) {
                StringBuilder sb = new StringBuilder();
                while (c.moveToNext()) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(c.getString(1)).append("(").append(c.getString(2)).append(")");
                }
                dump.append(t).append(" -> [").append(sb).append("]\n");
            }
        }
        Log.d(TAG, "schema:\n" + dump);

        String best = null;
        for (String t : tables) if (t.equalsIgnoreCase("Player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.equalsIgnoreCase("players")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("roster")) { best = t; break; }
        if (best != null) playerTable = best;

        try (Cursor c = db.rawQuery("PRAGMA table_info(`" + playerTable + "`)", null)) {
            List<String> names = new ArrayList<>();
            while (c.moveToNext()) names.add(c.getString(1));
            String id    = findCol(names, "id", "playerid", "player_id", "pid", "rowid");
            String first = findCol(names, "firstname", "first_name", "fname", "givenname");
            String last  = findCol(names, "lastname", "last_name", "lname", "surname", "familyname");
            String jer   = findCol(names, "jersey", "jerseynum", "jerseynumber", "number");
            String ovr   = findCol(names, "overall", "ovr", "rating", "playeroverall");
            String cf    = findCol(names, "cfid", "cyberfaceid", "cf", "faceid", "portraitid");
            if (id != null)    colId     = id;
            if (first != null) colFirst  = first;
            if (last != null)  colLast   = last;
            if (jer != null)   colJersey = jer;
            colOvr = ovr;
            colCf = cf;
        }
    }

    private static String findCol(List<String> names, String... aliases) {
        for (String a : aliases) {
            for (String n : names) {
                if (a.equalsIgnoreCase(n)) return n;
            }
        }
        return null;
    }

    private void saveAsNew() {
        File src = activeDatabaseFile;
        if (src == null || !src.exists()) {
            toast("Open a .ros first.");
            return;
        }
        try {
            File target = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "NBA2K20Editor");
            if (!target.exists()) target.mkdirs();
            File out = new File(target, "Modded_Roster_" + System.currentTimeMillis() + ".ros");
            copy(src, out);
            byte[] hash = md5(out);
            File usr = new File(target, "myprofile.usr");
            if (usr.exists() && usr.length() >= 0x34) {
                try (RandomAccessFile raf = new RandomAccessFile(usr, "rw")) {
                    raf.seek(0x30);
                    raf.write(hash, 0, 4);
                }
            }
            toast("Saved: " + out.getName());
        } catch (Exception e) {
            toast("Save failed: " + e.getMessage());
        }
    }

    private static void copy(File s, File d) throws Exception {
        try (InputStream in = new FileInputStream(s);
             FileOutputStream out = new FileOutputStream(d)) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        }
    }

    private static byte[] md5(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) md.update(b, 0, n);
        }
        return md.digest();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private class PlayerAdapter extends ArrayAdapter<PlayerRow> {
        PlayerAdapter() {
            super(RosterEditorActivity.this, 0, filteredPlayers);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(RosterEditorActivity.this)
                        .inflate(R.layout.item_player_row, parent, false);
            }
            PlayerRow p = filteredPlayers.get(position);
            ((TextView) convertView.findViewById(R.id.rowName)).setText(p.name);
            ((TextView) convertView.findViewById(R.id.rowJersey)).setText(String.valueOf(p.jersey));
            ((TextView) convertView.findViewById(R.id.rowOvr)).setText(p.ovr);
            ((TextView) convertView.findViewById(R.id.rowCf)).setText(p.cf);
            return convertView;
        }
    }
}