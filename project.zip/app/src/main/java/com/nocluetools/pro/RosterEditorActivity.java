package com.nocluetools.pro;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class RosterEditorActivity extends AppCompatActivity {

    private static final String TAG = "RosterEditor";
    private static final int PICK_ROSTER_FILE = 101;

    private TextView tvStatusBar;
    private ListView listViewRecords;
    private EditText etJersey, etDraftYear;

    private File activeDatabaseFile;
    private final List<String> playerDisplayList = new ArrayList<>();
    private final List<Integer> playerIdList = new ArrayList<>();
    private ArrayAdapter<String> listAdapter;
    private int selectedPlayerId = -1;

    private String playerTable  = "Player";
    private String colId        = "id";
    private String colFirst     = "firstname";
    private String colLast      = "lastname";
    private String colJersey    = "jersey";
    private String colDraftYear = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_roster_editor);

        tvStatusBar     = findViewById(R.id.tvStatusBar);
        listViewRecords = findViewById(R.id.listViewRecords);
        etJersey        = findViewById(R.id.etJersey);
        etDraftYear     = findViewById(R.id.etDraftYear);
        Button btnOpen    = findViewById(R.id.btnOpen);
        Button btnSave    = findViewById(R.id.btnSave);
        Button btnRefresh = findViewById(R.id.btnRefresh);
        Button btnClose   = findViewById(R.id.btnClose);

        listAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, playerDisplayList);
        listViewRecords.setAdapter(listAdapter);

        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            if (position < playerIdList.size()) {
                selectedPlayerId = playerIdList.get(position);
                loadPlayerData(selectedPlayerId);
            }
        });

        btnOpen.setOnClickListener(x -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, PICK_ROSTER_FILE);
        });
        btnSave.setOnClickListener(x -> saveAndPatch());
        btnRefresh.setOnClickListener(x -> {
            File f = activeDatabaseFile;
            if (f != null && f.exists()) loadRosterDatabase(Uri.fromFile(f));
            else toast("No active database to refresh.");
        });
        btnClose.setOnClickListener(x -> finish());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ROSTER_FILE && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            loadRosterDatabase(data.getData());
        }
    }

    // ------------------------------------------------------------------
    private void loadRosterDatabase(Uri uri) {
        SQLiteDatabase db = null;
        try {
            File dst = new File(getCacheDir(), "editable_roster.ros");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new Exception("Cannot open URI");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            activeDatabaseFile = dst;

            db = SQLiteDatabase.openDatabase(dst.getAbsolutePath(), null,
                    SQLiteDatabase.OPEN_READWRITE);
            detectSchema(db);

            playerDisplayList.clear();
            playerIdList.clear();

            String sql = "SELECT " + colId + ", " + colFirst + ", " + colLast
                    + " FROM " + playerTable
                    + " WHERE " + colFirst + " IS NOT NULL AND " + colLast + " IS NOT NULL"
                    + " AND TRIM(" + colFirst + ") <> '' AND TRIM(" + colLast + ") <> ''"
                    + " ORDER BY " + colId;

            try (Cursor c = db.rawQuery(sql, null)) {
                while (c.moveToNext()) {
                    int id = c.getInt(0);
                    String f = c.getString(1);
                    String l = c.getString(2);
                    if (f == null) f = "";
                    if (l == null) l = "";
                    playerDisplayList.add(id + "   " + f + " " + l);
                    playerIdList.add(id);
                }
            }
            listAdapter.notifyDataSetChanged();
            tvStatusBar.setText("Loaded " + playerDisplayList.size()
                    + " players (table=" + playerTable + ")");
        } catch (Exception e) {
            Log.e(TAG, "loadRosterDatabase failed", e);
            tvStatusBar.setText("Error parsing database");
            toast("Error: " + e.getMessage());
        } finally {
            if (db != null) db.close();
        }
    }

    private void detectSchema(SQLiteDatabase db) {
        List<String> tables = new ArrayList<>();
        try (Cursor c = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table'", null)) {
            while (c.moveToNext()) {
                String t = c.getString(0);
                tables.add(t);
                Log.d(TAG, "TABLE: " + t);
            }
        }
        for (String t : tables) {
            try (Cursor c = db.rawQuery("PRAGMA table_info(`" + t + "`)", null)) {
                StringBuilder sb = new StringBuilder();
                while (c.moveToNext()) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(c.getString(1));
                }
                Log.d(TAG, "  COLUMNS of " + t + " -> [" + sb + "]");
            }
        }
        String best = null;
        for (String t : tables) if (t.equalsIgnoreCase("Player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.equalsIgnoreCase("players")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("player")) { best = t; break; }
        if (best == null) for (String t : tables) if (t.toLowerCase().contains("roster")) { best = t; break; }
        if (best != null) playerTable = best;
        Log.d(TAG, "Chosen player table: " + playerTable);

        try (Cursor c = db.rawQuery("PRAGMA table_info(`" + playerTable + "`)", null)) {
            List<String> names = new ArrayList<>();
            while (c.moveToNext()) names.add(c.getString(1));
            colId        = findCol(names, "id", "playerid", "player_id", "pid", "rowid", colId);
            colFirst     = findCol(names, "firstname", "first_name", "fname", "givenname", colFirst);
            colLast      = findCol(names, "lastname", "last_name", "lname", "surname", "familyname", colLast);
            colJersey    = findCol(names, "jersey", "jerseynum", "jerseynumber", "number", colJersey);
            colDraftYear = findCol(names, "draftyear", "draft_year", "draftyearid", "draft", null);
        }
        Log.d(TAG, "Column map: id=" + colId + " first=" + colFirst + " last=" + colLast
                + " jersey=" + colJersey + " draft=" + colDraftYear);
    }

    private static String findCol(List<String> names, String... aliases) {
        for (String a : aliases) {
            if (a == null) continue;
            for (String n : names) if (a.equalsIgnoreCase(n)) return n;
        }
        return null;
    }

    private void loadPlayerData(int id) {
        File file = activeDatabaseFile;
        if (file == null) return;
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null,
                    SQLiteDatabase.OPEN_READONLY);
            try (Cursor c = db.rawQuery("SELECT * FROM " + playerTable
                    + " WHERE " + colId + " = ?", new String[]{ String.valueOf(id) })) {
                if (c.moveToFirst()) {
                    int jIdx = c.getColumnIndex(colJersey);
                    etJersey.setText(jIdx != -1 && !c.isNull(jIdx)
                            ? String.valueOf(c.getInt(jIdx)) : "0");
                    int dIdx = colDraftYear != null ? c.getColumnIndex(colDraftYear) : -1;
                    etDraftYear.setText(dIdx != -1 && !c.isNull(dIdx)
                            ? String.valueOf(c.getInt(dIdx)) : "0");
                    tvStatusBar.setText("Player " + id + " loaded");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "loadPlayerData failed", e);
            toast("Read error: " + e.getMessage());
        } finally {
            if (db != null) db.close();
        }
    }

    private boolean applyEdit() {
        if (selectedPlayerId < 0) { toast("Select a player first."); return false; }
        File file = activeDatabaseFile;
        if (file == null) return false;
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null,
                    SQLiteDatabase.OPEN_READWRITE);
            ContentValues cv = new ContentValues();
            int jersey;
            try { jersey = Integer.parseInt(etJersey.getText().toString().trim()); }
            catch (Exception e) { jersey = 0; }
            cv.put(colJersey, jersey);
            if (colDraftYear != null) {
                int dy;
                try { dy = Integer.parseInt(etDraftYear.getText().toString().trim()); }
                catch (Exception e) { dy = 0; }
                cv.put(colDraftYear, dy);
            }
            int rows = db.update(playerTable, cv, colId + " = ?",
                    new String[]{ String.valueOf(selectedPlayerId) });
            Log.d(TAG, "applyEdit: updated " + rows + " row(s) for player " + selectedPlayerId);
            return rows > 0;
        } catch (Exception e) {
            Log.e(TAG, "applyEdit failed", e);
            toast("Apply failed: " + e.getMessage());
            return false;
        } finally {
            if (db != null) db.close();
        }
    }

    private void saveAndPatch() {
        File src = activeDatabaseFile;
        if (src == null || !src.exists()) { toast("Open a .ros file first!"); return; }
        if (selectedPlayerId >= 0) applyEdit();

        try {
            File downloads = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
            File targetDir = new File(downloads, "NBA2K20Editor");
            if (!targetDir.exists()) targetDir.mkdirs();

            File out = new File(targetDir, "Modded_Roster_"
                    + System.currentTimeMillis() + ".ros");
            copyFile(src, out);
            Log.d(TAG, "Saved -> " + out.getAbsolutePath());

            byte[] hash = md5(out);
            Log.d(TAG, "Roster MD5: " + toHex(hash));

            File usr = new File(targetDir, "myprofile.usr");
            if (usr.exists() && usr.length() >= 0x34) {
                try (RandomAccessFile raf = new RandomAccessFile(usr, "rw")) {
                    raf.seek(0x30);
                    raf.write(hash, 0, 4);
                }
                Log.d(TAG, "Patched myprofile.usr @0x30");
            }
            tvStatusBar.setText("Saved to Downloads/NBA2K20Editor");
            toast("Saved: " + out.getName());
        } catch (Exception e) {
            Log.e(TAG, "saveAndPatch failed", e);
            tvStatusBar.setText("Save error");
            toast("Save failed: " + e.getMessage());
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static void copyFile(File src, File dst) throws Exception {
        try (InputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private static byte[] md5(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        return md.digest();
    }

    private static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}