package com.nocluetools.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Dark status bar to match splash
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#0A0A0A"));
            getWindow().setNavigationBarColor(Color.parseColor("#0A0A0A"));
        }

        final TextView status = findViewById(R.id.splashStatus);

        // Start Python in background so it's ready by the time MainActivity loads
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!Python.isStarted()) {
                        Python.start(new AndroidPlatform(SplashActivity.this));
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            status.setText("Python ready.");
                        }
                    });

                    Thread.sleep(800);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            status.setText("Launching...");
                        }
                    });

                    Thread.sleep(400);
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            status.setText("Startup warning: " + e.getMessage());
                        }
                    });
                }

                // Launch MainActivity
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        // Disable back button during splash
    }
}