"""Pure-Python ETC1/ETC2 texture codec (decode + encode).

The decoder is a direct port of the public-domain-style ETC2 decoder from
Ishotihadus/mikunyan (``ext/decoders/native/etc.c``, MIT), which is exactly
what the ``texture2ddecoder`` native module used by the desktop tool wraps.
Keeping this port bit-exact with that reference is what makes exported PNGs
and round-trips consistent between the desktop and Android versions.

Pixel output order is scanline RGBA bytes (one byte per channel), matching
the little-endian ``uint32`` pixel layout produced by the reference decoder.

The encoder produces valid ETC1-style blocks (individual or differential
mode) and EAC alpha blocks, which every ETC2 decoder -- including the game's
GPU -- must decode.  It favours reliability and reasonable quality over
etcpak-grade compression quality; ETC2 is lossy either way.
"""

from __future__ import annotations

WRITE_ORDER = (0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15)
WRITE_ORDER_REV = (15, 11, 7, 3, 14, 10, 6, 2, 13, 9, 5, 1, 12, 8, 4, 0)

MODIFIER = (
    (
        2,
        8,
    ),
    (
        5,
        17,
    ),
    (
        9,
        29,
    ),
    (
        13,
        42,
    ),
    (
        18,
        60,
    ),
    (
        24,
        80,
    ),
    (
        33,
        106,
    ),
    (
        47,
        183,
    ),
)

SUBBLOCK_TABLE = (
    (
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
    ),
    (
        0,
        0,
        1,
        1,
        0,
        0,
        1,
        1,
        0,
        0,
        1,
        1,
        0,
        0,
        1,
        1,
    ),
)

ALPHA_MOD = (
    (
        -3,
        -6,
        -9,
        -15,
        2,
        5,
        8,
        14,
    ),
    (
        -3,
        -7,
        -10,
        -13,
        2,
        6,
        9,
        12,
    ),
    (
        -2,
        -5,
        -8,
        -13,
        1,
        4,
        7,
        12,
    ),
    (
        -2,
        -4,
        -6,
        -13,
        1,
        3,
        5,
        12,
    ),
    (
        -3,
        -6,
        -8,
        -12,
        2,
        5,
        7,
        11,
    ),
    (
        -3,
        -7,
        -9,
        -11,
        2,
        6,
        8,
        10,
    ),
    (
        -4,
        -7,
        -8,
        -11,
        3,
        6,
        7,
        10,
    ),
    (
        -3,
        -5,
        -8,
        -11,
        2,
        4,
        7,
        10,
    ),
    (
        -2,
        -6,
        -8,
        -10,
        1,
        5,
        7,
        9,
    ),
    (
        -2,
        -5,
        -8,
        -10,
        1,
        4,
        7,
        9,
    ),
    (
        -2,
        -4,
        -8,
        -10,
        1,
        3,
        7,
        9,
    ),
    (
        -2,
        -5,
        -7,
        -10,
        1,
        4,
        6,
        9,
    ),
    (
        -3,
        -4,
        -7,
        -10,
        2,
        3,
        6,
        9,
    ),
    (
        -1,
        -2,
        -3,
        -10,
        0,
        1,
        2,
        9,
    ),
    (
        -4,
        -6,
        -8,
        -9,
        3,
        5,
        7,
        8,
    ),
    (
        -3,
        -5,
        -7,
        -9,
        2,
        4,
        6,
        8,
    ),
)

DISTANCE_TABLE = (3, 6, 11, 16, 23, 32, 41, 64)


def _clamp(value: int) -> int:
    return 0 if value < 0 else 255 if value > 255 else value


def _decode_etc2_block(data: bytes, out: bytearray, base: int) -> None:
    """Decode one 64-bit ETC2/ETC1 RGB block into RGBA at ``out[base:base+64]``.

    ``data`` must be exactly 8 bytes.  Scanline pixel ``v`` lives at
    ``out[base + v*4 : base + v*4 + 4]``.
    """
    d0 = data[0]
    d1 = data[1]
    d2 = data[2]
    d3 = data[3]
    d4 = data[4]
    d5 = data[5]
    d6 = data[6]
    d7 = data[7]
    j = d6 << 8 | d7
    k = d4 << 8 | d5
    if d3 & 2:
        r = d0 & 248
        dr = (d0 << 3 & 24) - (d0 << 3 & 32)
        g = d1 & 248
        dg = (d1 << 3 & 24) - (d1 << 3 & 32)
        b = d2 & 248
        db = (d2 << 3 & 24) - (d2 << 3 & 32)
        rp = r + dr
        gp = g + dg
        bp = b + db
        if rp < 0 or rp > 255:
            c0r = d0 << 3 & 192 | d0 << 4 & 48 | d0 >> 1 & 12 | d0 & 3
            c0g = d1 & 240 | d1 >> 4
            c0b = (d1 & 15 | d1 << 4) & 255
            c1r = d2 & 240 | d2 >> 4
            c1g = (d2 & 15 | d2 << 4) & 255
            c1b = d3 & 240 | d3 >> 4
            dist = DISTANCE_TABLE[d3 >> 1 & 6 | d3 & 1]
            set0 = (c0r, c0g, c0b, 255)
            set1 = (_clamp(c1r + dist), _clamp(c1g + dist), _clamp(c1b + dist), 255)
            set2 = (c1r, c1g, c1b, 255)
            set3 = (_clamp(c1r - dist), _clamp(c1g - dist), _clamp(c1b - dist), 255)
            k <<= 1
            for position in range(16):
                index = (k & 2 | j & 1) & 3
                color = (set0, set1, set2, set3)[index]
                target = base + WRITE_ORDER[position] * 4
                out[target] = color[0]
                out[target + 1] = color[1]
                out[target + 2] = color[2]
                out[target + 3] = 255
                j >>= 1
                k >>= 1

        elif gp < 0 or gp > 255:
            c0r = d0 << 1 & 240 | d0 >> 3 & 15
            c0g = d0 << 5 & 224 | d1 & 16
            c0g |= c0g >> 4
            c0b = d1 & 8 | d1 << 1 & 6 | d2 >> 7
            c0b |= c0b << 4
            c1r = d2 << 1 & 240 | d2 >> 3 & 15
            c1g = d2 << 5 & 224 | d3 >> 3 & 16
            c1g |= c1g >> 4
            c1b = d3 << 1 & 240 | d3 >> 3 & 15
            dist = d3 & 4 | d3 << 1 & 2
            if c0r > c1r or (c0r == c1r and (c0g > c1g or (c0g == c1g and c0b >= c1b))):
                dist += 1
            dist = DISTANCE_TABLE[dist]
            set0 = (_clamp(c0r + dist), _clamp(c0g + dist), _clamp(c0b + dist), 255)
            set1 = (_clamp(c0r - dist), _clamp(c0g - dist), _clamp(c0b - dist), 255)
            set2 = (_clamp(c1r + dist), _clamp(c1g + dist), _clamp(c1b + dist), 255)
            set3 = (_clamp(c1r - dist), _clamp(c1g - dist), _clamp(c1b - dist), 255)
            k <<= 1
            for position in range(16):
                index = (k & 2 | j & 1) & 3
                color = (set0, set1, set2, set3)[index]
                target = base + WRITE_ORDER[position] * 4
                out[target] = color[0]
                out[target + 1] = color[1]
                out[target + 2] = color[2]
                out[target + 3] = 255
                j >>= 1
                k >>= 1

        elif bp < 0 or bp > 255:
            c0r = d0 << 1 & 252 | d0 >> 5 & 3
            c0g = d0 << 7 & 128 | d1 & 126 | d0 & 1
            c0b = d1 << 7 & 128 | d2 << 2 & 96 | d2 << 3 & 24 | d3 >> 5 & 4
            c0b |= c0b >> 6
            c1r = d3 << 1 & 248 | d3 << 2 & 4 | d3 >> 5 & 3
            c1g = d4 & 254 | d4 >> 7
            c1b = d4 << 7 & 128 | d5 >> 1 & 124
            c1b |= c1b >> 6
            c2r = d5 << 5 & 224 | d6 >> 3 & 28 | d5 >> 1 & 3
            c2g = d6 << 3 & 248 | d7 >> 5 & 6 | d6 >> 4 & 1
            c2b = (d7 << 2 | d7 >> 4 & 3) & 255
            for y in range(4):
                for x in range(4):
                    target = base + (y * 4 + x) * 4
                    out[target] = _clamp(x * (c1r - c0r) + y * (c2r - c0r) + 4 * c0r + 2 >> 2)
                    out[target + 1] = _clamp(x * (c1g - c0g) + y * (c2g - c0g) + 4 * c0g + 2 >> 2)
                    out[target + 2] = _clamp(x * (c1b - c0b) + y * (c2b - c0b) + 4 * c0b + 2 >> 2)
                    out[target + 3] = 255
        else:
            code0 = d3 >> 5
            code1 = d3 >> 2 & 7
            table = SUBBLOCK_TABLE[d3 & 1]
            c0r = r | r >> 5
            c0g = g | g >> 5
            c0b = b | b >> 5
            c1r = rp | rp >> 5
            c1g = gp | gp >> 5
            c1b = bp | bp >> 5
            for position in range(16):
                s = table[position]
                modifier = MODIFIER[code0 if s == 0 else code1][j & 1]
                if k & 1:
                    modifier = -modifier

                if s == 0:
                    cr, cg, cb = c0r, c0g, c0b
                else:
                    cr, cg, cb = c1r, c1g, c1b
                target = base + WRITE_ORDER[position] * 4
                out[target] = _clamp(cr + modifier)
                out[target + 1] = _clamp(cg + modifier)
                out[target + 2] = _clamp(cb + modifier)
                out[target + 3] = 255
                j >>= 1
                k >>= 1
    else:
        code0 = d3 >> 5
        code1 = d3 >> 2 & 7
        table = SUBBLOCK_TABLE[d3 & 1]
        c0r = d0 & 240 | d0 >> 4
        c1r = (d0 & 15 | d0 << 4) & 255
        c0g = d1 & 240 | d1 >> 4
        c1g = (d1 & 15 | d1 << 4) & 255
        c0b = d2 & 240 | d2 >> 4
        c1b = (d2 & 15 | d2 << 4) & 255
        for position in range(16):
            s = table[position]
            modifier = MODIFIER[code0 if s == 0 else code1][j & 1]
            if k & 1:
                modifier = -modifier

            if s == 0:
                cr, cg, cb = c0r, c0g, c0b
            else:
                cr, cg, cb = c1r, c1g, c1b
            target = base + WRITE_ORDER[position] * 4
            out[target] = _clamp(cr + modifier)
            out[target + 1] = _clamp(cg + modifier)
            out[target + 2] = _clamp(cb + modifier)
            out[target + 3] = 255
            j >>= 1
            k >>= 1


def _decode_alpha_block(data: bytes, out: bytearray, base: int) -> None:
    """Decode one 64-bit EAC alpha block into the alpha bytes of ``out``."""
    if data[1] & 240:
        multiplier = data[1] >> 4
        table = ALPHA_MOD[data[1] & 15]
        payload = int.from_bytes(data, "big")
        for position in range(16):
            alpha = data[0] + multiplier * table[payload & 7]
            payload >>= 3
            out[base + WRITE_ORDER_REV[position] * 4 + 3] = _clamp(alpha)
    else:
        for position in range(16):
            out[base + WRITE_ORDER_REV[position] * 4 + 3] = data[0]


def decode_etc2_rgb(data: bytes, width: int, height: int) -> bytes:
    """Decode ETC2 RGB (format 15) data into RGBA scanline bytes."""
    blocks_x = (width + 3) // 4
    blocks_y = (height + 3) // 4
    out = bytearray(width * height * 4)
    block = bytearray(64)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            _decode_etc2_block(data[position:position + 8], block, 0)
            position += 8
            x = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                source = row * 16
                target = row_base + row * width * 4 + x * 4
                out[target:target + 16] = block[source:source + 16]
    return bytes(out)


def decode_etc2_rgba8(data: bytes, width: int, height: int) -> bytes:
    """Decode ETC2 RGBA8 (format 16) data into RGBA scanline bytes."""
    blocks_x = (width + 3) // 4
    blocks_y = (height + 3) // 4
    out = bytearray(width * height * 4)
    block = bytearray(64)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            rgb_data = data[position + 8:position + 16]
            alpha_data = data[position:position + 8]
            position += 16
            _decode_etc2_block(rgb_data, block, 0)
            _decode_alpha_block(alpha_data, block, 0)
            x = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                source = row * 16
                target = row_base + row * width * 4 + x * 4
                out[target:target + 16] = block[source:source + 16]
    return bytes(out)


def _nearest_modifier(projection: int, positive_a: int, positive_b: int) -> int:
    """Return the modifier value from {+a, +b, -a, -b} closest to projection."""
    if projection >= 0:
        return positive_b if projection >= (positive_a + positive_b) // 2 else positive_a
    return -positive_b if projection <= -(positive_a + positive_b) // 2 else -positive_a


def _index_for_modifier(modifier: int, positive_a: int, positive_b: int) -> int:
    if modifier == positive_a:
        return 0

    if modifier == positive_b:
        return 1
    return 3 if modifier == -positive_b else 2


def _distance_squared(pixel: tuple, base: list, modifier: int) -> int:
    dr = pixel[0] - (base[0] + modifier)
    dg = pixel[1] - (base[1] + modifier)
    db = pixel[2] - (base[2] + modifier)
    return dr * dr + dg * dg + db * db


def _nearest_3d(members: list, base_color: list, table_index: int, pixels: list):
    """Assign 2-bit indices by exact 3D nearest color; returns (indices, error)."""
    [positive_a, positive_b] = MODIFIER[table_index]
    indices = [0] * 16
    error = 0
    for v in members:
        p = pixels[v]
        br = base_color[0]
        bg = base_color[1]
        bb = base_color[2]
        dr = p[0] - br - positive_a
        dg = p[1] - bg - positive_a
        db = p[2] - bb - positive_a
        e0 = dr * dr + dg * dg + db * db
        dr = p[0] - br - positive_b
        dg = p[1] - bg - positive_b
        db = p[2] - bb - positive_b
        e1 = dr * dr + dg * dg + db * db
        dr = p[0] - br + positive_a
        dg = p[1] - bg + positive_a
        db = p[2] - bb + positive_a
        e2 = dr * dr + dg * dg + db * db
        dr = p[0] - br + positive_b
        dg = p[1] - bg + positive_b
        db = p[2] - bb + positive_b
        e3 = dr * dr + dg * dg + db * db
        best_index = 0
        best_error = e0
        if e1 < best_error:
            best_error = e1
            best_index = 1

        if e2 < best_error:
            best_error = e2
            best_index = 2

        if e3 < best_error:
            best_error = e3
            best_index = 3
        indices[v] = best_index
        error += best_error
    return (indices, error)


def _encode_rgb_block(pixels: list, out: bytearray, block_offset: int) -> None:
    """Encode 16 scanline RGB pixels (tuples) as one ETC2 RGB block.

    Tries individual and differential modes with both split orientations.
    For each sub-block it evaluates a small set of modifier tables and then
    refines the quantized base color, keeping the lowest-error encoding.
    """
    sums = [p[0] + p[1] + p[2] for p in pixels]
    best = None
    best_error = None
    for diff in (0, 1):
        for flip in (0, 1):
            subblock = SUBBLOCK_TABLE[flip]
            members = ([], [])
            for position in range(16):
                members[subblock[position]].append(WRITE_ORDER[position])
            if not members[0] or not members[1]:
                continue
            mean = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
            for s in (0, 1):
                for v in members[s]:
                    p = pixels[v]
                    mean[s][0] += p[0]
                    mean[s][1] += p[1]
                    mean[s][2] += p[2]
                count = len(members[s])
                mean[s] = [value / count for value in mean[s]]
            if diff == 0:
                q = [[max(0, min(15, round(value / 16))) for value in mean[0]], [max(0, min(15, round(value / 16))) for value in mean[1]]]
                base = [[value * 17 for value in q[0]], [value * 17 for value in q[1]]]
            else:
                q = [[max(0, min(31, round(value / 8))) for value in mean[0]], [max(0, min(31, round(value / 8))) for value in mean[1]]]
                deltas = [q[1][channel] - q[0][channel] for channel in range(3)]
                if any((delta < -4 or delta > 3 for delta in deltas)):
                    continue
                raw0 = [q[0][channel] << 3 for channel in range(3)]
                raw1 = [raw0[channel] + (deltas[channel] << 3) for channel in range(3)]
                if any((value < 0 or value > 255 for value in raw1)):
                    continue
                base = [[value | value >> 5 for value in raw0], [value | value >> 5 for value in raw1]]
            tables = [0, 0]
            errors = [0, 0]
            indices = [[0] * 16, [0] * 16]
            for s in (0, 1):
                base_color = base[s]
                base_sum = base_color[0] + base_color[1] + base_color[2]
                first = members[s][0]
                min_dev = max_dev = sums[first] - base_sum
                for v in members[s][1:]:
                    deviation = sums[v] - base_sum
                    if deviation < min_dev:
                        min_dev = deviation
                        continue

                    if deviation > max_dev:
                        max_dev = deviation
                    continue
                target = max(2, min(183, (max_dev - min_dev) // 3))
                heuristic = min(range(8), key=lambda index: abs(MODIFIER[index][1] - target))
                candidates = dict.fromkeys((max(0, heuristic - 1), heuristic, min(7, heuristic + 1)))
                best_table = 0
                best_table_error = None
                best_table_indices = [0] * 16
                for table_index in candidates:
                    [positive_a, positive_b] = MODIFIER[table_index]
                    error = 0
                    for v in members[s]:
                        projection = (sums[v] - base_sum) // 3
                        modifier = _nearest_modifier(projection, positive_a, positive_b)
                        indices[s][v] = _index_for_modifier(modifier, positive_a, positive_b)
                        error += _distance_squared(pixels[v], base_color, modifier)
                    if best_table_error is None or error < best_table_error:
                        best_table = table_index
                        best_table_error = error
                        best_table_indices = list(indices[s])
                if diff == 0:
                    [positive_a, positive_b] = MODIFIER[best_table]
                    sums_r = sums_g = sums_b = 0
                    for v in members[s]:
                        modifier = (positive_a, positive_b, -positive_a, -positive_b)[best_table_indices[v]]
                        p = pixels[v]
                        sums_r += p[0] - modifier
                        sums_g += p[1] - modifier
                        sums_b += p[2] - modifier
                    count = len(members[s])
                    refined = (max(0, min(15, round(sums_r / count / 16))), max(0, min(15, round(sums_g / count / 16))), max(0, min(15, round(sums_b / count / 16))))
                    if list(refined) != q[s]:
                        refined_color = [value * 17 for value in refined]
                        refined_sum = refined_color[0] + refined_color[1] + refined_color[2]
                        error = 0
                        for v in members[s]:
                            projection = (sums[v] - refined_sum) // 3
                            modifier = _nearest_modifier(projection, positive_a, positive_b)
                            indices[s][v] = _index_for_modifier(modifier, positive_a, positive_b)
                            error += _distance_squared(pixels[v], refined_color, modifier)
                        if error < best_table_error:
                            q[s] = list(refined)
                            base[s] = refined_color
                            best_table_error = error
                            best_table_indices = list(indices[s])
                tables[s] = best_table
                errors[s] = best_table_error
                indices[s] = best_table_indices
            error = errors[0] + errors[1]
            if best_error is None or error < best_error:
                best_error = error
                best = (diff, flip, q[0], q[1], tables[0], tables[1], indices[0], indices[1])

    if best is None:
        r = pixels[0][0] >> 4
        g = pixels[0][1] >> 4
        b = pixels[0][2] >> 4
        best = (0, 0, [r, g, b], [r, g, b], 0, 0, [0] * 16, [0] * 16)
    diff, flip, q0, q1, table0, table1, indices0, indices1 = best
    if diff == 0:
        base_colors = [[value * 17 for value in q0], [value * 17 for value in q1]]
    else:
        raw0 = [q0[channel] << 3 for channel in range(3)]
        raw1 = [raw0[channel] + (q1[channel] - q0[channel] << 3) for channel in range(3)]
        base_colors = [[value | value >> 5 for value in raw0], [value | value >> 5 for value in raw1]]
    members = ([], [])
    for position in range(16):
        members[SUBBLOCK_TABLE[flip][position]].append(WRITE_ORDER[position])

    indices = [0] * 16
    for s, table_index in ((0, table0), (1, table1)):
        [nearest, _error] = _nearest_3d(members[s], base_colors[s], table_index, pixels)
        for v in members[s]:
            indices[v] = nearest[v]

    if diff == 0:
        byte0 = q0[0] << 4 | q1[0]
        byte1 = q0[1] << 4 | q1[1]
        byte2 = q0[2] << 4 | q1[2]
    else:
        delta_r = q1[0] - q0[0]
        delta_g = q1[1] - q0[1]
        delta_b = q1[2] - q0[2]
        byte0 = q0[0] << 3 | delta_r & 7
        byte1 = q0[1] << 3 | delta_g & 7
        byte2 = q0[2] << 3 | delta_b & 7
    byte3 = table0 << 5 | table1 << 2 | diff << 1 | flip
    j = 0
    k = 0
    for position in range(16):
        v = WRITE_ORDER[position]
        index = indices[v]
        j |= (index & 1) << position
        k |= index >> 1 << position

    out[block_offset:block_offset + 8] = bytes((byte0, byte1, byte2, byte3, k >> 8 & 255, k & 255, j >> 8 & 255, j & 255))


def _encode_alpha_block(alpha_values: list, out: bytearray, block_offset: int) -> None:
    """Encode 16 scanline alpha values as one EAC alpha block (first 8 bytes).

    Tries a few modifier tables and the multiplier that best covers the
    block's alpha span, then assigns per-pixel nearest modifiers.  The
    multiplier field is only 4 bits, so very wide spans saturate (the format
    itself cannot represent them); the smallest-error table wins.
    """
    minimum = min(alpha_values)
    maximum = max(alpha_values)
    if minimum == maximum:
        out[block_offset:block_offset + 8] = bytes((minimum, 0) + (0, 0, 0, 0, 0, 0))
        return
    span = maximum - minimum
    best_error = 1152921504606846976
    best_encoding = None
    for table_index in (15, 14, 1, 0):
        table = ALPHA_MOD[table_index]
        positive_max = max(modifier for modifier in table if modifier > 0)
        multiplier = max(1, min(15, (span + positive_max - 1) // positive_max))
        error = 0
        indices = [0] * 16
        for position in range(16):
            target = alpha_values[WRITE_ORDER[position]]
            best_index = 0
            best_delta = 1073741824
            for index, modifier in enumerate(table):
                value = minimum + multiplier * modifier
                if value < 0:
                    value = 0
                elif value > 255:
                    value = 255
                delta = abs(value - target)
                if delta < best_delta:
                    best_delta = delta
                    best_index = index
                continue
            error += best_delta
            indices[position] = best_index
        if error < best_error:
            best_error = error
            best_encoding = (table_index, multiplier, indices)
        continue
    table_index, multiplier, indices = best_encoding
    payload = 0
    for position in range(16):
        payload |= indices[position] << (15 - position) * 3
    out[block_offset:block_offset + 2] = bytes((minimum, multiplier << 4 | table_index))
    out[block_offset + 2:block_offset + 8] = payload.to_bytes(6, "big")

def encode_etc2_rgb(rgba: bytes, width: int, height: int) -> bytes:
    """Encode RGBA scanline bytes into ETC2 RGB (format 15) data."""
    blocks_x = (width + 3) // 4
    blocks_y = (height + 3) // 4
    out = bytearray(blocks_x * blocks_y * 8)
    pixels = []
    for row in range(4):
        for col in range(4):
            pixels.append((0, 0, 0))

    for by in range(blocks_y):
        for bx in range(blocks_x):
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    pixels[row * 4:row * 4 + 4] = [(0, 0, 0)] * 4
                    continue

                for col in range(4):
                    x = bx * 4 + col
                    if x >= width:
                        pixels[row * 4 + col] = (0, 0, 0)
                        continue
                    offset = (y * width + x) * 4
                    pixels[row * 4 + col] = (rgba[offset], rgba[offset + 1], rgba[offset + 2])
            block_offset = (by * blocks_x + bx) * 8
            _encode_rgb_block(pixels, out, block_offset)
    return bytes(out)


def encode_etc2_rgba8(rgba: bytes, width: int, height: int) -> bytes:
    """Encode RGBA scanline bytes into ETC2 RGBA8 (format 16) data."""
    blocks_x = (width + 3) // 4
    blocks_y = (height + 3) // 4
    out = bytearray(blocks_x * blocks_y * 16)
    pixels = []
    alphas = []
    for row in range(4):
        for col in range(4):
            pixels.append((0, 0, 0))
            alphas.append(0)

    for by in range(blocks_y):
        for bx in range(blocks_x):
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    pixels[row * 4:row * 4 + 4] = [(0, 0, 0)] * 4
                    alphas[row * 4:row * 4 + 4] = [0] * 4
                    continue

                for col in range(4):
                    x = bx * 4 + col
                    if x >= width:
                        pixels[row * 4 + col] = (0, 0, 0)
                        alphas[row * 4 + col] = 0
                        continue
                    offset = (y * width + x) * 4
                    pixels[row * 4 + col] = (rgba[offset], rgba[offset + 1], rgba[offset + 2])
                    alphas[row * 4 + col] = rgba[offset + 3]
            block_offset = (by * blocks_x + bx) * 16
            _encode_alpha_block(alphas, out, block_offset)
            _encode_rgb_block(pixels, out, block_offset + 8)
    return bytes(out)
