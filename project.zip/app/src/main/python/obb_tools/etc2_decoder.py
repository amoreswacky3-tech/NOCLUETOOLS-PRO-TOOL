"""Pure-Python ETC2 RGB / ETC2 RGBA8 decoder for NBA 2K20 mobile textures."""

import struct

# Modifier table for individual/differential modes (indexed by 3-bit selector)
_MODS = (
    (2, 8, -2, -8),
    (5, 17, -5, -17),
    (9, 29, -9, -29),
    (13, 42, -13, -42),
    (17, 56, -17, -56),
    (21, 71, -21, -71),
    (26, 86, -26, -86),
    (32, 102, -32, -102),
)

# Small tables for T and H modes
_T_MODS = (3, 6, 9, 12, 15, 18, 21, 24)


def _clamp(v):
    return 0 if v < 0 else (255 if v > 255 else v)


def _sign3(v):
    return v - 8 if v >= 4 else v


def _expand4(x):
    return x * 17


def _expand5(x):
    return (x << 3) | (x >> 2)


def _expand3_to_5(x):
    return (x << 2) | (x >> 1)


def _write_pixel(out, width, height, x, y, r, g, b, a):
    if 0 <= x < width and 0 <= y < height:
        o = (y * width + x) * 4
        out[o] = r
        out[o + 1] = g
        out[o + 2] = b
        out[o + 3] = a


def _rgb_individual(v):
    r1 = _expand4((v >> 60) & 0xF)
    r2 = _expand4((v >> 56) & 0xF)
    g1 = _expand4((v >> 52) & 0xF)
    g2 = _expand4((v >> 48) & 0xF)
    b1 = _expand4((v >> 44) & 0xF)
    b2 = _expand4((v >> 40) & 0xF)
    return (r1, g1, b1), (r2, g2, b2)


def _rgb_differential(v):
    r1 = (v >> 61) & 0x7
    r2 = max(0, min(7, r1 + _sign3((v >> 58) & 0x7)))
    g1 = (v >> 55) & 0x7
    g2 = max(0, min(7, g1 + _sign3((v >> 52) & 0x7)))
    b1 = (v >> 49) & 0x7
    b2 = max(0, min(7, b1 + _sign3((v >> 46) & 0x7)))
    return (_expand5(r1), _expand5(g1), _expand5(b1)), (_expand5(r2), _expand5(g2), _expand5(b2))
def _apply_etc1_block(out, width, height, bx, by, c1, c2, t1, t2, flip, indices):
    # Determine which two columns/rows use which table based on flip bit
    # ETC1 pixel layout: index bit order is LSB-first for each column
    mods1 = _MODS[t1]
    mods2 = _MODS[t2]

    # Decode 16 pixels
    for py in range(4):
        for px in range(4):
            # Determine which half this pixel belongs to (based on flip bit)
            if flip == 0:
                # Vertical split: columns 0-1 use table1, columns 2-3 use table2
                c = c1 if px < 2 else c2
                mods = mods1 if px < 2 else mods2
                bit_pos = px * 4 + py
            else:
                # Horizontal split: rows 0-1 use table1, rows 2-3 use table2
                c = c1 if py < 2 else c2
                mods = mods1 if py < 2 else mods2
                bit_pos = py * 4 + px

            idx = (indices >> (2 * bit_pos)) & 0x3
            modifier = mods[idx]

            r = _clamp(c[0] + modifier)
            g = _clamp(c[1] + modifier)
            b = _clamp(c[2] + modifier)

            _write_pixel(out, width, height, bx * 4 + px, by * 4 + py, r, g, b, 255)


def _decode_etc2_rgb_block(out, width, height, bx, by, v):
    """Decode one 64-bit ETC2 RGB block into the output buffer."""
    high_byte = (v >> 56) & 0xFF
    hb_high_nibble = (high_byte >> 4) & 0xF

    # ETC2 extended modes: check bits 7-4 of byte 3
    if (high_byte & 0x02) == 0:
        # ETC1 modes (individual / differential)
        diff = (v >> 33) & 1
        flip = (v >> 32) & 1
        if diff == 0:
            c1, c2 = _rgb_individual(v)
        else:
            c1, c2 = _rgb_differential(v)
        t1 = (v >> 37) & 0x7
        t2 = (v >> 34) & 0x7
        indices = v & 0xFFFFFFFF
        _apply_etc1_block(out, width, height, bx, by, c1, c2, t1, t2, flip, indices)
    else:
        # Extended mode: T, H, or Planar based on bits 6-5
        if (high_byte & 0x08) != 0:
            _decode_t_or_h(out, width, height, bx, by, v)
        else:
            _decode_planar(out, width, height, bx, by, v)
def _decode_t_or_h(out, width, height, bx, by, v):
    """Decode T or H mode block. Falls back to gray if unsupported."""
    # Full T/H decoding is complex; approximate with the two endpoint colors.
    # R1 = bits 63-59 (5 bits), G1 = 59-55, B1 = 55-51 (approx)
    r1 = (v >> 59) & 0x1F
    g1 = (v >> 55) & 0x1F
    b1 = (v >> 51) & 0x1F
    r2 = (v >> 47) & 0x1F
    g2 = (v >> 43) & 0x1F
    b2 = (v >> 39) & 0x1F

    c1 = (_expand5(r1), _expand5(g1), _expand5(b1))
    c2 = (_expand5(r2), _expand5(g2), _expand5(b2))

    indices = v & 0xFFFFFFFF
    mods = _T_MODS

    for py in range(4):
        for px in range(4):
            bit_pos = py * 4 + px
            idx = (indices >> (3 * bit_pos)) & 0x1  # T/H use 1 bit + alternation
            c = c1 if idx == 0 else c2
            _write_pixel(out, width, height, bx * 4 + px, by * 4 + py, c[0], c[1], c[2], 255)


def _decode_planar(out, width, height, bx, by, v):
    """Decode Planar mode block."""
    ro = (v >> 57) & 0x3F
    go = (v >> 49) & 0x3F
    bo = (v >> 41) & 0x3F
    rh = (v >> 33) & 0x3F
    gh = (v >> 25) & 0x3F
    bh = (v >> 17) & 0x3F
    rv = (v >> 9) & 0x3F
    gv = (v >> 1) & 0x3F
    bv = (v << 7) & 0x3F

    def _expand6(x):
        return (x << 2) | (x >> 4)

    for py in range(4):
        for px in range(4):
            r = _clamp(_expand6(ro) + (px * (_expand6(rh) - _expand6(ro)) >> 2) + (py * (_expand6(rv) - _expand6(ro)) >> 2))
            g = _clamp(_expand6(go) + (px * (_expand6(gh) - _expand6(go)) >> 2) + (py * (_expand6(gv) - _expand6(go)) >> 2))
            b = _clamp(_expand6(bo) + (px * (_expand6(bh) - _expand6(bo)) >> 2) + (py * (_expand6(bv) - _expand6(bo)) >> 2))
            _write_pixel(out, width, height, bx * 4 + px, by * 4 + py, r, g, b, 255)


def decode_etc2_rgb(data, width, height):
    """Decode ETC2 RGB (8 bytes per 4x4 block) to RGBA8888 bytes."""
    out = bytearray(width * height * 4)
    bw = (width + 3) // 4
    bh = (height + 3) // 4
    pos = 0
    for by in range(bh):
        for bx in range(bw):
            if pos + 8 > len(data):
                break
            v = int.from_bytes(data[pos:pos + 8], "big")
            pos += 8
            _decode_etc2_rgb_block(out, width, height, bx, by, v)
    return bytes(out)


def decode_etc2_rgba8(data, width, height):
    """Decode ETC2 RGBA8 (16 bytes per 4x4 block) to RGBA8888 bytes."""
    out = bytearray(width * height * 4)
    bw = (width + 3) // 4
    bh = (height + 3) // 4
    pos = 0
    for by in range(bh):
        for bx in range(bw):
            if pos + 16 > len(data):
                break
            # First 8 bytes: ETC2 RGB (color)
            v = int.from_bytes(data[pos:pos + 8], "big")
            _decode_etc2_rgb_block(out, width, height, bx, by, v)
            # Next 8 bytes: alpha
            a_bytes = data[pos + 8:pos + 16]
            _apply_etc2_alpha(out, width, height, bx, by, a_bytes)
            pos += 16
    return bytes(out)


def _apply_etc2_alpha(out, width, height, bx, by, a):
    """Apply 64-bit ETC2 alpha data."""
    # Alpha block: 2 bytes base + 6 bytes indices, or other modes
    # Simplified: only handle base + 3-bit index mode
    a0 = a[0]
    a1 = a[1]
    if a0 > a1:
        table = (a0, a1, (6 * a0 + 1 * a1) // 7, (5 * a0 + 2 * a1) // 7,
                 (4 * a0 + 3 * a1) // 7, (3 * a0 + 4 * a1) // 7,
                 (2 * a0 + 5 * a1) // 7, (1 * a0 + 6 * a1) // 7)
    else:
        table = (a0, a1, (4 * a0 + 1 * a1) // 5, (3 * a0 + 2 * a1) // 5,
                 (2 * a0 + 3 * a1) // 5, (1 * a0 + 4 * a1) // 5, 0, 255)
    # 48 bits of indices (16 pixels x 3 bits)
    idx_bits = int.from_bytes(a[2:8], "big")
    for py in range(4):
        for px in range(4):
            bit_pos = py * 4 + px
            idx = (idx_bits >> (3 * bit_pos)) & 0x7
            alpha = table[idx]
            o = ((by * 4 + py) * width + (bx * 4 + px)) * 4 + 3
            if o < len(out):
                out[o] = alpha