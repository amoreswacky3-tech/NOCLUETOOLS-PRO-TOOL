"""Pure-Python ETC2 RGB / ETC2 RGBA8 decoder with correct ETC1 pixel index layout."""

_MODS = (
    (2, 8, -2, -8),
    (5, 17, -5, -17),
    (9, 29, -9, -29),
    (13, 42, -13, -42),
    (17, 56, -17, -56),
    (21, 71, -21, -71),
    (26, 86, -26, -86),
    (32, 102, -32, -102),
)

_MODS_T_H = (0, 3, 6, 9, 12, 15, 18, 21)


def _clamp(v):
    if v < 0: return 0
    if v > 255: return 255
    return v


def _expand4(x):
    return (x << 4) | x


def _expand5(x):
    return (x << 3) | (x >> 2)


def _expand6(x):
    return (x << 2) | (x >> 4)


def _sign3(v):
    return v - 8 if v >= 4 else v


def _write_pixel(out, width, height, x, y, r, g, b, a=255):
    if 0 <= x < width and 0 <= y < height:
        o = (y * width + x) * 4
        out[o] = r
        out[o + 1] = g
        out[o + 2] = b
        out[o + 3] = a


def _decode_etc1(v, out, bx, by, w, h):
    diff = (v >> 33) & 1

    if diff == 0:
        r1 = _expand4((v >> 60) & 0xF)
        g1 = _expand4((v >> 56) & 0xF)
        b1 = _expand4((v >> 52) & 0xF)
        r2 = _expand4((v >> 48) & 0xF)
        g2 = _expand4((v >> 44) & 0xF)
        b2 = _expand4((v >> 40) & 0xF)
    else:
        r1 = (v >> 59) & 0x1F
        r2 = max(0, min(31, r1 + _sign3((v >> 56) & 0x7)))
        g1 = (v >> 51) & 0x1F
        g2 = max(0, min(31, g1 + _sign3((v >> 48) & 0x7)))
        b1 = (v >> 43) & 0x1F
        b2 = max(0, min(31, b1 + _sign3((v >> 40) & 0x7)))
        r1 = _expand5(r1); g1 = _expand5(g1); b1 = _expand5(b1)
        r2 = _expand5(r2); g2 = _expand5(g2); b2 = _expand5(b2)

    c1 = (r1, g1, b1)
    c2 = (r2, g2, b2)

    flip = (v >> 32) & 1
    t1 = (v >> 37) & 0x7
    t2 = (v >> 34) & 0x7
    mods1 = _MODS[t1]
    mods2 = _MODS[t2]

    indices = v & 0xFFFFFFFF

    for py in range(4):
        for px in range(4):
            if flip == 0:
                # Vertical split: left columns use table1, right use table2
                if px < 2:
                    c = c1
                    mods = mods1
                    bit_shift = 2 * (py * 2 + px)
                else:
                    c = c2
                    mods = mods2
                    bit_shift = 16 + 2 * (py * 2 + (px - 2))
            else:
                # Horizontal split: top rows use table1, bottom use table2
                if py < 2:
                    c = c1
                    mods = mods1
                    bit_shift = 2 * (py * 4 + px)
                else:
                    c = c2
                    mods = mods2
                    bit_shift = 16 + 2 * ((py - 2) * 4 + px)

            idx = (indices >> bit_shift) & 0x3
            modifier = mods[idx]

            r = _clamp(c[0] + modifier)
            g = _clamp(c[1] + modifier)
            b = _clamp(c[2] + modifier)

            _write_pixel(out, w, h, bx * 4 + px, by * 4 + py, r, g, b, 255)


def _decode_t(v, out, bx, by, w, h):
    r1 = _expand4((v >> 59) & 0xF)
    g1 = _expand4((v >> 55) & 0xF)
    b1 = _expand4((v >> 51) & 0xF)
    r2 = _expand4((v >> 47) & 0xF)
    g2 = _expand4((v >> 43) & 0xF)
    b2 = _expand4((v >> 39) & 0xF)

    c1 = (r1, g1, b1)
    c2 = (r2, g2, b2)

    idx0 = (v >> 35) & 0x7
    idx15 = (v >> 32) & 0x7

    val0 = _MODS_T_H[idx0]
    val15 = _MODS_T_H[idx15]

    if idx0 == 0 and idx15 == 0:
        return  # not valid T mode

    # Full 4x4 with c2 as default
    colors = [c2] * 16
    colors[0] = (_clamp(c1[0] + val0), _clamp(c1[1] + val0), _clamp(c1[2] + val0))
    colors[15] = (_clamp(c2[0] + val15), _clamp(c2[1] + val15), _clamp(c2[2] + val15))

    # 14 remaining pixels use 2-bit indices
    mods2 = (0, val0, val15, (val0 + val15) // 2)
    bits = v & 0x3FFF

    bit_idx = 0
    for py in range(4):
        for px in range(4):
            if (py == 0 and px == 0) or (py == 3 and px == 3):
                continue
            idx = (bits >> bit_idx) & 0x3
            bit_idx += 2
            m = mods2[idx]
            colors[py * 4 + px] = (_clamp(c2[0] + m), _clamp(c2[1] + m), _clamp(c2[2] + m))

    for py in range(4):
        for px in range(4):
            c = colors[py * 4 + px]
            _write_pixel(out, w, h, bx * 4 + px, by * 4 + py, c[0], c[1], c[2], 255)


def _decode_h(v, out, bx, by, w, h):
    r1 = _expand4((v >> 59) & 0xF)
    g1 = _expand4((v >> 55) & 0xF)
    b1 = _expand4((v >> 51) & 0xF)
    r2 = _expand4((v >> 47) & 0xF)
    g2 = _expand4((v >> 43) & 0xF)
    b2 = _expand4((v >> 39) & 0xF)

    c1 = (r1, g1, b1)
    c2 = (r2, g2, b2)

    idx0 = (v >> 35) & 0x7
    idx15 = (v >> 32) & 0x7

    val0 = _MODS_T_H[idx0]
    val15 = _MODS_T_H[idx15]

    if idx0 == 0 and idx15 == 0:
        return

    colors = [c2] * 16
    colors[0] = (_clamp(c1[0] + val0), _clamp(c1[1] + val0), _clamp(c1[2] + val0))
    colors[15] = (_clamp(c2[0] + val15), _clamp(c2[1] + val15), _clamp(c2[2] + val15))

    mods2 = (0, val0, val15, (val0 + val15) // 2)
    bits = v & 0x3FFF

    bit_idx = 0
    for py in range(4):
        for px in range(4):
            if (py == 0 and px == 0) or (py == 3 and px == 3):
                continue
            idx = (bits >> bit_idx) & 0x3
            bit_idx += 2
            m = mods2[idx]
            colors[py * 4 + px] = (_clamp(c2[0] + m), _clamp(c2[1] + m), _clamp(c2[2] + m))

    for py in range(4):
        for px in range(4):
            c = colors[py * 4 + px]
            _write_pixel(out, w, h, bx * 4 + px, by * 4 + py, c[0], c[1], c[2], 255)


def _decode_planar(v, out, bx, by, w, h):
    ro = _expand6((v >> 57) & 0x3F)
    go = _expand6((v >> 51) & 0x3F)
    bo = _expand6((v >> 45) & 0x3F)
    rh = _expand6((v >> 39) & 0x3F)
    gh = _expand6((v >> 33) & 0x3F)
    bh = _expand6((v >> 27) & 0x3F)
    rv = _expand6((v >> 21) & 0x3F)
    gv = _expand6((v >> 15) & 0x3F)
    bv = _expand6((v >> 9) & 0x3F)

    for py in range(4):
        for px in range(4):
            r = _clamp(ro + ((px * (rh - ro)) >> 2) + ((py * (rv - ro)) >> 2))
            g = _clamp(go + ((px * (gh - go)) >> 2) + ((py * (gv - go)) >> 2))
            b = _clamp(bo + ((px * (bh - bo)) >> 2) + ((py * (bv - bo)) >> 2))
            _write_pixel(out, w, h, bx * 4 + px, by * 4 + py, r, g, b, 255)


def _decode_block(v, out, bx, by, w, h):
    diff = (v >> 33) & 1
    if diff == 0:
        _decode_etc1(v, out, bx, by, w, h)
        return
    r_check = (v >> 34) & 1
    g_check = (v >> 35) & 1
    if r_check == 1 and g_check == 0:
        _decode_planar(v, out, bx, by, w, h)
        return
    g_check = (v >> 36) & 1
    if g_check == 0:
        _decode_t(v, out, bx, by, w, h)
    else:
        _decode_h(v, out, bx, by, w, h)


def decode_etc2_rgb(data, width, height):
    out = bytearray(width * height * 4)
    bw = (width + 3) // 4
    bh = (height + 3) // 4
    pos = 0
    for by in range(bh):
        for bx in range(bw):
            if pos + 8 > len(data):
                break
            v = int.from_bytes(data[pos:pos + 8], "big")
            pos += 8
            _decode_block(v, out, bx, by, width, height)
    return bytes(out)


def decode_etc2_rgba8(data, width, height):
    out = bytearray(width * height * 4)
    bw = (width + 3) // 4
    bh = (height + 3) // 4
    pos = 0
    for by in range(bh):
        for bx in range(bw):
            if pos + 16 > len(data):
                break
            v = int.from_bytes(data[pos:pos + 8], "big")
            pos += 8
            _decode_block(v, out, bx, by, width, height)
            a = data[pos:pos + 8]
            pos += 8
            _apply_alpha(out, width, height, bx, by, a)
    return bytes(out)


def _apply_alpha(out, width, height, bx, by, a):
    a0 = a[0]
    a1 = a[1]
    if a0 > a1:
        table = (a0, a1, (6 * a0 + 1 * a1) // 7, (5 * a0 + 2 * a1) // 7,
                 (4 * a0 + 3 * a1) // 7, (3 * a0 + 4 * a1) // 7,
                 (2 * a0 + 5 * a1) // 7, (1 * a0 + 6 * a1) // 7)
    else:
        table = (a0, a1, (4 * a0 + 1 * a1) // 5, (3 * a0 + 2 * a1) // 5,
                 (2 * a0 + 3 * a1) // 5, (1 * a0 + 4 * a1) // 5, 0, 255)

    idx_bits = int.from_bytes(a[2:8], "big")
    for py in range(4):
        for px in range(4):
            bit_pos = py * 4 + px
            idx = (idx_bits >> (3 * bit_pos)) & 0x7
            alpha = table[idx]
            o = ((by * 4 + py) * width + (bx * 4 + px)) * 4 + 3
            if o < len(out):
                out[o] = alpha