"""Binary texture format detection and pure-Python decoders.

This module inspects the *actual bytes* of a texture resource (never trusting
filenames or extensions) and answers three questions:

1. **What is it?**  :func:`detect_container` identifies standard container and
   GPU-compressed formats by their signatures/headers (DDS, KTX, KTX2, PVR,
   TGA, BMP, PNG, JPEG, TIFF, WebP, EXR, HDR).
2. **Can we decode it?**  Decoders are provided for the formats this app can
   actually render in pure Python: DXT1/2/3/4/5 (BC1/BC2/BC3), BC4 (ATI1),
   BC5 (ATI2), TGA (raw + RLE), BMP (BI_RGB) and RGBE (Radiance HDR).
   ETC1/ETC2/EAC reuse :mod:`iffengine.etc2`.  Everything else is honestly
   reported as *detected but not decodable on this platform* -- we never
   claim full support for a format we cannot render.
3. **What could this unknown blob be?**  :func:`analyze_payload` ranks
   plausible interpretations (containers first, then block-compressed
   candidates by exact length match, then raw pixel layouts by spatial
   coherence) and returns ranked candidates with confidence levels, so the
   UI can offer them for a manual "decode as" attempt instead of failing.

All decoders emit 8-bit RGBA scanline bytes (``w*h*4``), matching the rest of
the engine.
"""
from __future__ import annotations
import struct
import zlib
from collections import Counter
from . import etc2
_BLOCK_FORMATS: dict[str, list] = {'DXT1': ['DXT1 / BC1', 8, True, None, 'block'], 'DXT2': ['DXT2 / BC2', 16, True, None, 'block'], 'DXT3': ['DXT3 / BC2', 16, True, None, 'block'], 'DXT4': ['DXT4 / BC3', 16, True, None, 'block'], 'DXT5': ['DXT5 / BC3', 16, True, None, 'block'], 'BC1': ['BC1 / DXT1', 8, True, None, 'block'], 'BC2': ['BC2 / DXT3', 16, True, None, 'block'], 'BC3': ['BC3 / DXT5', 16, True, None, 'block'], 'BC4': ['BC4 / ATI1', 8, False, None, 'block'], 'BC5': ['BC5 / ATI2', 16, False, None, 'block'], 'BC6H': ['BC6H', 16, False, None, 'block'], 'BC7': ['BC7', 16, True, None, 'block'], 'ATI1': ['ATI1 / BC4', 8, False, None, 'block'], 'ATI2': ['ATI2 / BC5', 16, False, None, 'block'], 'ETC1': ['ETC1 RGB', 8, False, None, 'block'], 'ETC2': ['ETC2 RGB', 8, False, etc2.decode_etc2_rgb, 'block'], 'ETC2A1': ['ETC2 RGB + A1', 8, True, None, 'block'], 'ETC2A8': ['ETC2 RGBA8', 16, True, etc2.decode_etc2_rgba8, 'block'], 'EACR': ['EAC R11', 8, False, None, 'block'], 'EACRG': ['EAC RG11', 16, False, None, 'block'], 'ASTC': ['ASTC', 16, True, None, 'block'], 'PVRTC': ['PVRTC', 8, True, None, 'block']}

def _install_decoders() -> None:
    _BLOCK_FORMATS['DXT1'][3] = decode_dxt1
    _BLOCK_FORMATS['DXT2'][3] = decode_dxt3
    _BLOCK_FORMATS['DXT3'][3] = decode_dxt3
    _BLOCK_FORMATS['DXT4'][3] = decode_dxt5
    _BLOCK_FORMATS['DXT5'][3] = decode_dxt5
    _BLOCK_FORMATS['BC1'][3] = decode_dxt1
    _BLOCK_FORMATS['BC2'][3] = decode_dxt3
    _BLOCK_FORMATS['BC3'][3] = decode_dxt5
    _BLOCK_FORMATS['BC4'][3] = decode_bc4
    _BLOCK_FORMATS['BC5'][3] = decode_bc5
    _BLOCK_FORMATS['ATI1'][3] = decode_bc4
    _BLOCK_FORMATS['ATI2'][3] = decode_bc5
    _BLOCK_FORMATS['ETC1'][3] = etc2.decode_etc2_rgb
    _BLOCK_FORMATS['EACR'][3] = decode_eac_r11
    _BLOCK_FORMATS['EACRG'][3] = decode_eac_rg11

def format_name(key: str) -> str:
    entry = _BLOCK_FORMATS.get(key)
    return entry[0] if entry else key

def block_bytes_per_block(key: str) -> int:
    entry = _BLOCK_FORMATS.get(key)
    return entry[1] if entry else 0

def block_has_alpha(key: str) -> bool:
    entry = _BLOCK_FORMATS.get(key)
    return entry[2] if entry else False

def block_decoder(key: str):
    entry = _BLOCK_FORMATS.get(key)
    return entry[3] if entry else None

def block_family(key: str) -> str:
    entry = _BLOCK_FORMATS.get(key)
    return entry[4] if entry else 'block'

def block_payload_size(key: str, width: int, height: int) -> int:
    """Exact payload size for one base level of a block-compressed format."""
    entry = _BLOCK_FORMATS.get(key)
    if entry is None:
        raise ValueError(f'unknown block format {key}')
    blocks_wide = max(1, (width + 3) // 4)
    blocks_high = max(1, (height + 3) // 4)
    return blocks_wide * blocks_high * entry[1]

def _expand565(value: int) -> tuple[int, int, int]:
    red = value >> 11 & 31
    green = value >> 5 & 63
    blue = value & 31
    return (red << 3 | red >> 2, green << 2 | green >> 4, blue << 3 | blue >> 2)

def _dxt1_palette(color0: int, color1: int) -> tuple[tuple[int, int, int, int], ...]:
    c0 = _expand565(color0)
    c1 = _expand565(color1)
    if color0 > color1:
        return ((c0[0], c0[1], c0[2], 255), (c1[0], c1[1], c1[2], 255), ((2 * c0[0] + c1[0]) // 3, (2 * c0[1] + c1[1]) // 3, (2 * c0[2] + c1[2]) // 3, 255), ((c0[0] + 2 * c1[0]) // 3, (c0[1] + 2 * c1[1]) // 3, (c0[2] + 2 * c1[2]) // 3, 255))
    return ((c0[0], c0[1], c0[2], 255), (c1[0], c1[1], c1[2], 255), ((c0[0] + c1[0]) // 2, (c0[1] + c1[1]) // 2, (c0[2] + c1[2]) // 2, 255), (0, 0, 0, 0))

def decode_dxt1(payload: bytes, width: int, height: int) -> bytes:
    """Decode DXT1 / BC1 into RGBA. 8 bytes per 4x4 block."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 8 > len(payload):
                raise ValueError('DXT1 payload is truncated')
            color0, color1, bits = struct.unpack_from('<HHI', payload, position)
            position += 8
            palette = _dxt1_palette(color0, color1)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    index = bits >> 2 * (row * 4 + col) & 3
                    pixel = palette[index]
                    out[target] = pixel[0]
                    out[target + 1] = pixel[1]
                    out[target + 2] = pixel[2]
                    out[target + 3] = pixel[3]
                    target += 4
    return bytes(out)

def decode_dxt3(payload: bytes, width: int, height: int) -> bytes:
    """Decode DXT2/DXT3 (BC2) into RGBA. 16 bytes per block: 4-bit alpha + DXT1 color."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 16 > len(payload):
                raise ValueError('DXT3 payload is truncated')
            alpha_word = int.from_bytes(payload[position:position + 8], 'little')
            color0, color1, bits = struct.unpack_from('<HHI', payload, position + 8)
            position += 16
            palette = _dxt1_palette(color0, color1)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    index = bits >> 2 * (row * 4 + col) & 3
                    alpha = (alpha_word >> 4 * (row * 4 + col) & 15) * 17
                    pixel = palette[index]
                    out[target] = pixel[0]
                    out[target + 1] = pixel[1]
                    out[target + 2] = pixel[2]
                    out[target + 3] = alpha
                    target += 4
    return bytes(out)

def decode_dxt5(payload: bytes, width: int, height: int) -> bytes:
    """Decode DXT4/DXT5 (BC3) into RGBA. 16 bytes per block: interpolated alpha + DXT1 color."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 16 > len(payload):
                raise ValueError('DXT5 payload is truncated')
            a0 = payload[position]
            a1 = payload[position + 1]
            alpha_bits = int.from_bytes(payload[position + 2:position + 8], 'little')
            color0, color1, bits = struct.unpack_from('<HHI', payload, position + 8)
            position += 16
            if a0 > a1:
                alpha_table = (a0, a1, (6 * a0 + 1 * a1) // 7, (5 * a0 + 2 * a1) // 7, (4 * a0 + 3 * a1) // 7, (3 * a0 + 4 * a1) // 7, (2 * a0 + 5 * a1) // 7, (1 * a0 + 6 * a1) // 7)
            else:
                alpha_table = (a0, a1, (4 * a0 + 1 * a1) // 5, (3 * a0 + 2 * a1) // 5, (2 * a0 + 3 * a1) // 5, (1 * a0 + 4 * a1) // 5, 0, 255)
            palette = _dxt1_palette(color0, color1)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    index = bits >> 2 * (row * 4 + col) & 3
                    alpha_index = alpha_bits >> 3 * (row * 4 + col) & 7
                    pixel = palette[index]
                    out[target] = pixel[0]
                    out[target + 1] = pixel[1]
                    out[target + 2] = pixel[2]
                    out[target + 3] = alpha_table[alpha_index]
                    target += 4
    return bytes(out)

def decode_bc4(payload: bytes, width: int, height: int) -> bytes:
    """Decode BC4 / ATI1 (single-channel) into RGBA grayscale. 8 bytes per block."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 8 > len(payload):
                raise ValueError('BC4 payload is truncated')
            r0 = payload[position]
            r1 = payload[position + 1]
            bits = int.from_bytes(payload[position + 2:position + 8], 'little')
            position += 8
            if r0 > r1:
                table = (r0, r1, (6 * r0 + r1) // 7, (5 * r0 + 2 * r1) // 7, (4 * r0 + 3 * r1) // 7, (3 * r0 + 4 * r1) // 7, (2 * r0 + 5 * r1) // 7, (r0 + 6 * r1) // 7)
            else:
                table = (r0, r1, (4 * r0 + r1) // 5, (3 * r0 + 2 * r1) // 5, (2 * r0 + 3 * r1) // 5, (r0 + 4 * r1) // 5, 0, 255)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    value = table[bits >> 3 * (row * 4 + col) & 7]
                    out[target] = value
                    out[target + 1] = value
                    out[target + 2] = value
                    out[target + 3] = 255
                    target += 4
    return bytes(out)

def decode_bc5(payload: bytes, width: int, height: int) -> bytes:
    """Decode BC5 / ATI2 (two-channel) into RGBA (R=first channel, G=second). 16 bytes per block."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 16 > len(payload):
                raise ValueError('BC5 payload is truncated')
            block = payload[position:position + 16]
            position += 16
            red = decode_bc4(block, 4, 4)
            green = decode_bc4(block[8:], 4, 4)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    offset = (row * 4 + col) * 4
                    out[target] = red[offset]
                    out[target + 1] = green[offset]
                    out[target + 2] = 0
                    out[target + 3] = 255
                    target += 4
    return bytes(out)

def decode_eac_r11(payload: bytes, width: int, height: int) -> bytes:
    """Decode EAC R11 (unsigned) into RGBA grayscale. 8 bytes per block.

    EAC R11 shares the exact block layout of the EAC alpha channel used by
    ETC2 RGBA8 (base + multiplier + 16x3-bit indices), which
    :mod:`iffengine.etc2` already implements; we reuse it per channel.
    """
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 8 > len(payload):
                raise ValueError('EAC R11 payload is truncated')
            block = payload[position:position + 8]
            position += 8
            channel = bytearray(64)
            etc2._decode_alpha_block(block, channel, 0)
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    value = channel[(row * 4 + col) * 4 + 3]
                    out[target] = value
                    out[target + 1] = value
                    out[target + 2] = value
                    out[target + 3] = 255
                    target += 4
    return bytes(out)

def decode_eac_rg11(payload: bytes, width: int, height: int) -> bytes:
    """Decode EAC RG11 (unsigned) into RGBA (R + G channels). 16 bytes per block."""
    blocks_x = max(1, (width + 3) // 4)
    blocks_y = max(1, (height + 3) // 4)
    out = bytearray(width * height * 4)
    position = 0
    for by in range(blocks_y):
        row_base = by * 4 * width * 4
        for bx in range(blocks_x):
            if position + 16 > len(payload):
                raise ValueError('EAC RG11 payload is truncated')
            red = bytearray(64)
            green = bytearray(64)
            etc2._decode_alpha_block(payload[position:position + 8], red, 0)
            etc2._decode_alpha_block(payload[position + 8:position + 16], green, 0)
            position += 16
            x0 = bx * 4
            for row in range(4):
                y = by * 4 + row
                if y >= height:
                    break
                target = row_base + row * width * 4 + x0 * 4
                for col in range(4):
                    x = x0 + col
                    if x >= width:
                        break
                    offset = (row * 4 + col) * 4
                    r_val = red[offset + 3]
                    g_val = green[offset + 3]
                    out[target] = r_val
                    out[target + 1] = g_val
                    nx = (r_val - 128.0) / 127.0
                    ny = (g_val - 128.0) / 127.0
                    nz_sq = 1.0 - nx * nx - ny * ny
                    nz = int((nz_sq ** 0.5 if nz_sq > 0 else 0.0) * 127.0 + 128.0)
                    out[target + 2] = min(255, max(0, nz))
                    out[target + 3] = 255
                    target += 4
    return bytes(out)

def decode_rg8_normal(payload: bytes, width: int, height: int) -> bytes:
    """Decode raw uncompressed 16 bpp RG8 normal map (2 bytes/pixel) into RGBA.

    Channel 0 is X (Normal X), Channel 1 is Y (Normal Y).
    Z is reconstructed via sqrt(max(0, 1 - X^2 - Y^2)) in tangent space.
    """
    expected_pixels = width * height
    out = bytearray(expected_pixels * 4)
    max_pixels = min(expected_pixels, len(payload) // 2)
    for i in range(max_pixels):
        r_val = payload[i * 2]
        g_val = payload[i * 2 + 1]
        target = i * 4
        out[target] = r_val
        out[target + 1] = g_val
        nx = (r_val - 128.0) / 127.0
        ny = (g_val - 128.0) / 127.0
        nz_sq = 1.0 - nx * nx - ny * ny
        nz = int((nz_sq ** 0.5 if nz_sq > 0 else 0.0) * 127.0 + 128.0)
        out[target + 2] = min(255, max(0, nz))
        out[target + 3] = 255
    return bytes(out)

def encode_rg8_normal(rgba: bytes, width: int, height: int) -> bytes:
    """Encode RGBA tangent-space normal map into raw 16 bpp RG8 (2 bytes/pixel)."""
    pixel_count = width * height
    out = bytearray(pixel_count * 2)
    max_pixels = min(pixel_count, len(rgba) // 4)
    for i in range(max_pixels):
        out[i * 2] = rgba[i * 4]
        out[i * 2 + 1] = rgba[i * 4 + 1]
    return bytes(out)

def decode_tga(payload: bytes) -> tuple[int, int, bytes]:
    """Decode a TGA (truecolor 24/32-bit, raw or RLE) into ``(w, h, rgba)``.

    Supports image types 2 (uncompressed truecolor) and 10 (RLE truecolor)
    with 24 or 32 bits per pixel.  Bottom-up origin by default; top-down
    (image descriptor bit 5) and left-to-right (bit 4) are honoured.
    """
    if len(payload) < 18:
        raise ValueError('TGA header is truncated')
    _id_length, _color_map_type, image_type = struct.unpack_from('<BBB', payload, 0)
    if image_type not in (2, 10):
        raise ValueError(f'unsupported TGA image type {image_type} (only truecolor raw/RLE)')
    _cmap_first, _cmap_length, _cmap_size = struct.unpack_from('<HHB', payload, 3)
    [_x_origin, _y_origin] = struct.unpack_from('<hh', payload, 8)
    width, height = struct.unpack_from('<HH', payload, 12)
    pixel_depth = payload[16]
    descriptor = payload[17]
    if width <= 0 or height <= 0:
        raise ValueError('invalid TGA dimensions')
    if pixel_depth not in (24, 32):
        raise ValueError(f'unsupported TGA pixel depth {pixel_depth}')
    channels = pixel_depth // 8
    right_to_left = bool(descriptor & 16)
    top_to_bottom = bool(descriptor & 32)
    alpha_bits = descriptor & 15
    data_start = 18 + _id_length + _cmap_length * (_cmap_size // 8)
    body = memoryview(payload)
    if data_start > len(body):
        raise ValueError('TGA data is truncated')
    cursor = data_start
    raw = bytearray(width * height * channels)
    if image_type == 2:
        need = width * height * channels
        if cursor + need > len(body):
            raise ValueError('TGA image data is truncated')
        raw[:] = body[cursor:cursor + need]
        cursor += need
    else:
        index = 0
        target = width * height
        while index < target and cursor < len(body):
            packet = body[cursor]
            cursor += 1
            count = (packet & 127) + 1
            if packet & 128:
                if cursor + channels > len(body):
                    raise ValueError('TGA RLE packet is truncated')
                pixel = bytes(body[cursor:cursor + channels])
                cursor += channels
                for _ in range(count):
                    if index >= target:
                        break
                    raw[index * channels:(index + 1) * channels] = pixel
                    index += 1
            else:
                need = count * channels
                if cursor + need > len(body):
                    raise ValueError('TGA raw packet is truncated')
                raw[index * channels:(index + count) * channels] = body[cursor:cursor + need]
                cursor += need
                index += count
    out = bytearray(width * height * 4)
    for i in range(width * height):
        base = i * channels
        blue = raw[base]
        green = raw[base + 1]
        red = raw[base + 2]
        alpha = raw[base + 3] if channels == 4 else 255 if alpha_bits else 255
        out[i * 4] = red
        out[i * 4 + 1] = green
        out[i * 4 + 2] = blue
        out[i * 4 + 3] = alpha
    if right_to_left or not top_to_bottom:
        rows = [bytes(out[y * width * 4:(y + 1) * width * 4]) for y in range(height)]
        if right_to_left:
            rows = [row[::-1] for row in rows]
        if not top_to_bottom:
            rows.reverse()
        out = bytearray(b''.join(rows))
    return (width, height, bytes(out))

def decode_bmp(payload: bytes) -> tuple[int, int, bytes]:
    """Decode an uncompressed (BI_RGB) 24/32-bit BMP into ``(w, h, rgba)``."""
    if len(payload) < 54 or payload[:2] != b'BM':
        raise ValueError('not a BMP file')
    data_offset = struct.unpack_from('<I', payload, 10)[0]
    header_size = struct.unpack_from('<I', payload, 14)[0]
    if header_size < 40:
        raise ValueError(f'unsupported BMP DIB header size {header_size}')
    width = struct.unpack_from('<i', payload, 18)[0]
    height_raw = struct.unpack_from('<i', payload, 22)[0]
    planes = struct.unpack_from('<H', payload, 26)[0]
    bit_count = struct.unpack_from('<H', payload, 28)[0]
    compression = struct.unpack_from('<I', payload, 30)[0]
    if planes != 1:
        raise ValueError('unsupported BMP planes')
    if compression not in (0, 3):
        raise ValueError(f'unsupported BMP compression {compression}')
    if bit_count not in (24, 32):
        raise ValueError(f'unsupported BMP bit depth {bit_count}')
    if width <= 0 or height_raw == 0:
        raise ValueError('invalid BMP dimensions')
    top_down = height_raw < 0
    height = abs(height_raw)
    channels = bit_count // 8
    row_bytes = (width * channels + 3) // 4 * 4
    if data_offset + height * row_bytes > len(payload):
        raise ValueError('BMP pixel data is truncated')
    out = bytearray(width * height * 4)
    for row in range(height):
        source_row = row if top_down else height - 1 - row
        source = data_offset + source_row * row_bytes
        target = row * width * 4
        for col in range(width):
            base = source + col * channels
            out[target] = payload[base + 2]
            out[target + 1] = payload[base + 1]
            out[target + 2] = payload[base]
            out[target + 3] = payload[base + 3] if channels == 4 else 255
            target += 4
    return (width, height, bytes(out))

def decode_rgbe(payload: bytes) -> tuple[int, int, bytes]:
    """Decode a Radiance RGBE .hdr into ``(w, h, rgba)``.

    Only the classic flat (non-run-length) scanline layout and the standard
    RLE scanline variant (0x02 0x02 prefix) are supported; everything else
    raises a clear error.  Colors are converted to 8-bit with a 1.0
    exposure.  (The engine is a modding tool; tone mapping is intentionally
    kept neutral rather than claiming a specific display transform.)
    """
    if len(payload) < 32 or not payload.startswith(b'#?'):
        raise ValueError('not a Radiance HDR file')
    header_end = payload.find(b'\n\n')
    if header_end < 0:
        raise ValueError('HDR header is not terminated')
    header = payload[:header_end].decode('ascii', 'replace')
    resolution = None
    for line in header.splitlines():
        stripped = line.strip()
        if stripped.upper().startswith('-Y ') or stripped.upper().startswith('+Y '):
            resolution = stripped
            break
    if resolution is None:
        raise ValueError('HDR resolution line not found')
    sign = resolution[0]
    parts = resolution[1:].strip().split()
    if len(parts) != 4:
        raise ValueError('malformed HDR resolution line')
    try:
        height = int(parts[1])
        width = int(parts[3])
    except ValueError as error:
        raise ValueError('malformed HDR resolution line') from error
    if width <= 0 or height <= 0:
        raise ValueError('invalid HDR dimensions')
    cursor = header_end + 2
    if len(payload) < cursor + width * height * 4:
        raise ValueError('HDR pixel data is truncated')

    def _decode_scanline(scan: bytes) -> list[tuple[int, int, int]]:
        if len(scan) != width * 4:
            raise ValueError('HDR scanline length mismatch')
        return list(zip(*[scan[channel::4] for channel in range(4)]))

    def _read_rle_scanline(payload: bytes, start: int, scan_width: int) -> tuple[list[tuple[int, int, int]], int]:
        """Parse one new-style RLE scanline; returns (pixels, bytes_consumed)."""
        if payload[start:start + 2] != b'\x02\x02':
            raise ValueError('malformed HDR RLE scanline marker')
        stored_width = payload[start + 2] << 8 | payload[start + 3]
        if stored_width != scan_width:
            raise ValueError('HDR RLE scanline width mismatch')
        position = start + 6
        channels = []
        for _channel in range(4):
            expanded = []
            while len(expanded) < scan_width:
                if position >= len(payload):
                    raise ValueError('HDR RLE scanline is truncated')
                count = payload[position]
                position += 1
                if count > 128:
                    count -= 128
                    if position >= len(payload):
                        raise ValueError('HDR RLE scanline is truncated')
                    expanded.extend([payload[position]] * count)
                    position += 1
                else:
                    if position + count > len(payload):
                        raise ValueError('HDR RLE scanline is truncated')
                    expanded.extend(payload[position:position + count])
                    position += count
            if len(expanded) > scan_width:
                raise ValueError('HDR RLE scanline overflows its channel')
            channels.append(expanded)
        return (list(zip(*channels)), position - start)
    out = bytearray(width * height * 4)
    for y in range(height):
        if payload[cursor:cursor + 2] == b'\x02\x02' and cursor + 8 <= len(payload) and (payload[cursor + 2] << 8 | payload[cursor + 3] == width):
            scan = _read_rle_scanline(payload, cursor, width)
            cursor += scan[1]
            pixels = scan[0]
        else:
            scan_bytes = payload[cursor:cursor + width * 4]
            cursor += width * 4
            pixels = _decode_scanline(scan_bytes)
        target = y * width * 4
        for red, green, blue, exponent in pixels:
            scale = 2.0 ** (exponent - 128)
            out[target] = max(0, min(255, int(red * scale + 0.5)))
            out[target + 1] = max(0, min(255, int(green * scale + 0.5)))
            out[target + 2] = max(0, min(255, int(blue * scale + 0.5)))
            out[target + 3] = 255
            target += 4
    return (width, height, bytes(out))
PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
DDS_MAGIC = b'DDS '
KTX_MAGIC = b'\xabKTX 11\r\n\x1a\n'
KTX2_MAGIC = b'\xabKTX 20\r\n\x1a\n'
PVR_MAGIC = b'PVR\x03'
TGA_JPEG = b'\xff\xd8\xff'

def _dds_fourcc_format(fourcc: bytes) -> str | None:
    if fourcc in (b'DXT1',):
        return 'DXT1'
    if fourcc in (b'DXT2',):
        return 'DXT2'
    if fourcc in (b'DXT3',):
        return 'DXT3'
    if fourcc in (b'DXT4',):
        return 'DXT4'
    if fourcc in (b'DXT5',):
        return 'DXT5'
    if fourcc in (b'BC1',):
        return 'BC1'
    if fourcc in (b'BC2',):
        return 'BC2'
    if fourcc in (b'BC3',):
        return 'BC3'
    if fourcc in (b'BC4', b'ATI1'):
        return 'BC4'
    if fourcc in (b'BC5', b'ATI2'):
        return 'BC5'
    if fourcc in (b'BC6H',):
        return 'BC6H'
    if fourcc in (b'BC7',):
        return 'BC7'
    if fourcc in (b'ETC1',):
        return 'ETC1'
    if fourcc == b'\x00\x00\x00\x00':
        return None

def _dxgi_format(dxgi: int) -> str | None:
    mapping = {70: 'BC1', 71: 'BC1', 72: 'BC1', 73: 'BC2', 74: 'BC2', 75: 'BC2', 76: 'BC3', 77: 'BC3', 78: 'BC3', 79: 'BC4', 80: 'BC4', 81: 'BC4', 82: 'BC5', 83: 'BC5', 84: 'BC5', 94: 'BC6H', 95: 'BC6H', 96: 'BC6H', 97: 'BC7', 98: 'BC7', 99: 'BC7'}
    return mapping.get(dxgi)

def _decode_fourcc(value: int) -> bytes:
    return value.to_bytes(4, 'little')

def dds_info(data: bytes, offset: int=0) -> dict | None:
    """Parse a DDS header at ``offset``; return info or None when invalid."""
    if offset + 128 > len(data) or data[offset:offset + 4] != DDS_MAGIC:
        return None
    header_size = struct.unpack_from('<I', data, offset + 4)[0]
    if header_size != 124:
        return None
    flags, height, width = struct.unpack_from('<3I', data, offset + 8)
    if width <= 0 or height <= 0 or width > 65536 or (height > 65536):
        return None
    _pitch, depth, mip_count = struct.unpack_from('<3I', data, offset + 20)
    pfsize, pfflags, fourcc_value, bitcount = struct.unpack_from('<4I', data, offset + 76)
    if pfsize != 32:
        return None
    fmt_key = None
    alpha = False
    decode_support = False
    payload_offset = offset + 128
    if pfflags & 4:
        fourcc = _decode_fourcc(fourcc_value)
        if fourcc == b'DX10':
            if offset + 148 > len(data):
                return None
            dxgi = struct.unpack_from('<I', data, offset + 128)[0]
            fmt_key = _dxgi_format(dxgi)
            payload_offset = offset + 148
        else:
            fmt_key = _dds_fourcc_format(fourcc)
        if fmt_key is None:
            return None
        decode_support = block_decoder(fmt_key) is not None
        alpha = block_has_alpha(fmt_key)
    elif pfflags & 64:
        masks = struct.unpack_from('<4I', data, offset + 92)
        alpha = bool(pfflags & 1)
        if bitcount == 32 and masks == (16711680, 65280, 255, 4278190080):
            fmt_key = 'RGBA8888'
        elif bitcount == 24 and masks[:3] == (16711680, 65280, 255):
            fmt_key = 'RGB888'
        elif bitcount == 32 and masks == (255, 65280, 16711680, 4278190080):
            fmt_key = 'BGRA8888'
        elif bitcount == 32 and masks[:3] == (16711680, 65280, 255):
            fmt_key = 'XRGB8888'
        elif bitcount == 16 and masks == (63488, 2016, 31, 0):
            fmt_key = 'RGB565'
        elif bitcount == 16 and masks == (31744, 992, 31, 32768):
            fmt_key = 'RGBA5551'
        elif bitcount == 16 and masks == (3840, 240, 15, 61440):
            fmt_key = 'RGBA4444'
        elif bitcount == 16 and masks == (61440, 3840, 240, 15):
            fmt_key = 'ARGB4444'
        decode_support = fmt_key is not None
    elif pfflags & 131072:
        if bitcount == 8:
            fmt_key = 'L8'
        elif bitcount == 16 and pfflags & 1:
            fmt_key = 'LA8'
        decode_support = fmt_key is not None
    else:
        return None
    if fmt_key is None:
        return None
    mip_count = mip_count if mip_count > 0 else 1
    return {'container': 'DDS', 'format': fmt_key, 'name': format_name(fmt_key), 'width': width, 'height': height, 'depth': max(depth, 1), 'mip_count': mip_count, 'alpha': alpha, 'decode_support': decode_support, 'block_bytes': block_bytes_per_block(fmt_key) if block_family(fmt_key) == 'block' else 0, 'bits_per_pixel': bitcount, 'confidence': 'high', 'payload_offset': payload_offset}

def _tga_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 18 > len(data):
        return None
    image_type = data[offset + 2]
    if image_type not in (2, 3, 10, 11):
        return None
    [width, height] = struct.unpack_from('<HH', data, offset + 12)
    depth = data[offset + 16]
    if width <= 0 or height <= 0 or width > 65536 or (height > 65536):
        return None
    if image_type in (2, 10):
        if depth not in (24, 32):
            return None
        fmt_key = 'TGA32' if depth == 32 else 'TGA24'
        name = 'TGA 32-bit' if depth == 32 else 'TGA 24-bit'
        decode_support = True
    else:
        fmt_key = 'TGAGRAY'
        name = 'TGA grayscale'
        decode_support = True
    return {'container': 'TGA', 'format': fmt_key, 'name': name, 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': depth == 32, 'decode_support': decode_support, 'bits_per_pixel': depth, 'confidence': 'high', 'payload_offset': offset}

def _bmp_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 54 > len(data) or data[offset:offset + 2] != b'BM':
        return None
    header_size = struct.unpack_from('<I', data, offset + 14)[0]
    if header_size < 40:
        return None
    width = struct.unpack_from('<i', data, offset + 18)[0]
    height_raw = struct.unpack_from('<i', data, offset + 22)[0]
    bit_count = struct.unpack_from('<H', data, offset + 28)[0]
    compression = struct.unpack_from('<I', data, offset + 30)[0]
    if width <= 0 or height_raw == 0 or width > 65536 or (abs(height_raw) > 65536):
        return None
    if compression not in (0, 3) or bit_count not in (24, 32):
        return None
    return {'container': 'BMP', 'format': 'BMP32' if bit_count == 32 else 'BMP24', 'name': 'BMP 32-bit' if bit_count == 32 else 'BMP 24-bit', 'width': width, 'height': abs(height_raw), 'depth': 1, 'mip_count': 1, 'alpha': bit_count == 32, 'decode_support': True, 'bits_per_pixel': bit_count, 'confidence': 'high', 'payload_offset': offset}

def _png_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 24 > len(data) or data[offset:offset + 8] != PNG_SIGNATURE:
        return None
    [width, height] = struct.unpack_from('>II', data, offset + 16)
    if width <= 0 or height <= 0:
        return None
    color_type = data[offset + 25]
    return {'container': 'PNG', 'format': 'PNG', 'name': 'PNG', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': color_type in (4, 6), 'decode_support': True, 'bits_per_pixel': 32, 'confidence': 'high', 'payload_offset': offset}

def _jpeg_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 4 > len(data) or data[offset:offset + 3] != b'\xff\xd8\xff':
        return None
    position = offset + 2
    end = min(len(data), offset + 262144)
    while position + 4 <= end:
        if data[position] != 255:
            position += 1
            continue
        marker = data[position + 1]
        if marker == 217 or marker == 218:
            break
        if marker in (192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207):
            if position + 9 > end:
                return None
            [height, width] = struct.unpack_from('>HH', data, position + 5)
            if width <= 0 or height <= 0:
                return None
            return {'container': 'JPEG', 'format': 'JPEG', 'name': 'JPEG', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': False, 'decode_support': False, 'bits_per_pixel': 24, 'confidence': 'high', 'payload_offset': offset}
        if marker in (216, 1) or 208 <= marker <= 215:
            position += 2
            continue
        if position + 4 > end:
            return None
        segment_size = struct.unpack_from('>H', data, position + 2)[0]
        if segment_size < 2:
            return None
        position += 2 + segment_size
    return None

def _webp_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 30 > len(data) or data[offset:offset + 4] != b'RIFF':
        return None
    if data[offset + 8:offset + 12] != b'WEBP':
        return None
    width = height = 0
    chunk = offset + 12
    if data[chunk:chunk + 4] == b'VP8 ' and chunk + 20 <= len(data):
        width = struct.unpack_from('<H', data, chunk + 14)[0] & 16383
        height = struct.unpack_from('<H', data, chunk + 16)[0] & 16383
    elif data[chunk:chunk + 4] == b'VP8L' and chunk + 25 <= len(data):
        bits = int.from_bytes(data[chunk + 5:chunk + 10], 'little')
        width = (bits & 16383) + 1
        height = (bits >> 14 & 16383) + 1
    elif data[chunk:chunk + 4] == b'VP8X' and chunk + 24 <= len(data):
        bits = int.from_bytes(data[chunk + 12:chunk + 18], 'little')
        width = (bits & 16777215) + 1
        height = (bits >> 24 & 16777215) + 1
    if width <= 0 or height <= 0:
        return None
    return {'container': 'WebP', 'format': 'WEBP', 'name': 'WebP', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': True, 'decode_support': False, 'bits_per_pixel': 32, 'confidence': 'high', 'payload_offset': offset}

def _ktx_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 64 > len(data):
        return None
    if data[offset:offset + 11] == KTX2_MAGIC:
        width = struct.unpack_from('<I', data, offset + 20)[0]
        height = struct.unpack_from('<I', data, offset + 24)[0]
        if width <= 0 or height <= 0:
            return None
        return {'container': 'KTX2', 'format': 'KTX2', 'name': 'KTX2', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': True, 'decode_support': False, 'bits_per_pixel': 0, 'confidence': 'high', 'payload_offset': offset}
    if data[offset:offset + 11] != KTX_MAGIC:
        return None
    width = struct.unpack_from('<I', data, offset + 36)[0]
    height = struct.unpack_from('<I', data, offset + 40)[0]
    if width <= 0 or height <= 0:
        return None
    return {'container': 'KTX', 'format': 'KTX', 'name': 'KTX', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': True, 'decode_support': False, 'bits_per_pixel': 0, 'confidence': 'high', 'payload_offset': offset}

def _pvr_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 52 > len(data) or data[offset:offset + 4] != PVR_MAGIC:
        return None
    width = struct.unpack_from('<I', data, offset + 44)[0]
    height = struct.unpack_from('<I', data, offset + 48)[0]
    if width <= 0 or height <= 0:
        return None
    return {'container': 'PVR', 'format': 'PVR', 'name': 'PVR texture container', 'width': width, 'height': height, 'depth': 1, 'mip_count': 1, 'alpha': True, 'decode_support': False, 'bits_per_pixel': 0, 'confidence': 'high', 'payload_offset': offset}

def _exr_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 4 > len(data) or data[offset:offset + 4] != b'v/1\x01':
        return None
    return {'container': 'EXR', 'format': 'EXR', 'name': 'OpenEXR', 'width': 0, 'height': 0, 'depth': 1, 'mip_count': 1, 'alpha': True, 'decode_support': False, 'bits_per_pixel': 0, 'confidence': 'high', 'payload_offset': offset}

def _hdr_info(data: bytes, offset: int=0) -> dict | None:
    if offset + 12 > len(data) or data[offset:offset + 2] not in (b'#?',):
        return None
    header_end = data.find(b'\n\n', offset, min(len(data), offset + 8192))
    if header_end < 0:
        return None
    if b'-Y ' not in data[offset:header_end]:
        if b'+Y ' not in data[offset:header_end]:
            return None
    return {'container': 'HDR', 'format': 'HDR', 'name': 'Radiance RGBE HDR', 'width': 0, 'height': 0, 'depth': 1, 'mip_count': 1, 'alpha': False, 'decode_support': True, 'bits_per_pixel': 32, 'confidence': 'high', 'payload_offset': offset}

def detect_container(data: bytes, offset: int=0) -> dict | None:
    """Identify a texture container by its bytes; None when unrecognized."""
    for detector in (dds_info, _png_info, _jpeg_info, _tga_info, _bmp_info, _webp_info, _ktx_info, _pvr_info, _exr_info, _hdr_info):
        info = detector(data, offset)
        if info is not None:
            return info
        continue

def _coherence(rgba: bytes, width: int, height: int) -> float:
    """Mean absolute RGB neighbor difference (lower = more spatially coherent)."""
    total = 0.0
    count = 0
    for y in range(height):
        row = y * width * 4
        end = row + (width - 1) * 4
        offset = row
        while offset < end:
            total += (abs(rgba[offset] - rgba[offset + 4]) + abs(rgba[offset + 1] - rgba[offset + 5]) + abs(rgba[offset + 2] - rgba[offset + 6])) / 3
            count += 1
            offset += 4
        continue
    return total / count if count else 0.0

def _factor_dimensions(length: int, max_side: int=16384, limit: int=12) -> list[tuple[int, int]]:
    """Plausible (w, h) pairs for a raw pixel buffer of ``length`` pixels.

    Collects divisor pairs efficiently (O(sqrt n)) and prefers exact
    power-of-two factors (common in games) with a sane aspect ratio.
    ``length`` is the pixel count; the caller has already checked that the
    byte length divides evenly by the pixel size.
    """
    if length <= 0:
        return []
    candidates = []
    width = 1
    while width * width <= length:
        if length % width == 0:
            height = length // width
            for pair in ((width, height), (height, width)):
                [w, h] = pair
                if w > max_side or h > max_side:
                    continue
                score = 0.0
                if w & w - 1 == 0:
                    score += 1
                if h & h - 1 == 0:
                    score += 1
                aspect = max(w, h) / min(w, h)
                if aspect <= 4:
                    score += 2
                elif aspect <= 16:
                    score += 1
                if w >= 4 and h >= 4:
                    score += 1
                candidates.append((score + 1.0 / (1.0 + aspect), w, h))
        width += 1
    candidates.sort(reverse=True)
    return [(w, h) for _score, w, h in candidates[:limit]]

def _raw_candidates(payload: bytes, hint_width: int, hint_height: int) -> list[dict]:
    """Rank raw pixel-layout interpretations by length match + coherence."""
    length = len(payload)
    candidates = []
    layouts = (('RGBA8888', 4, 'RGBA'), ('RGB888', 3, 'RGB'), ('BGRA8888', 4, 'BGRA'), ('ARGB8888', 4, 'ARGB'), ('RGBA4444', 2, 'RGBA4'), ('RGB565', 2, 'RGB565'), ('R5G6B5_SWAP', 2, 'RGB565SWAP'), ('RGBA5551', 2, 'RGBA5551'), ('LA88', 2, 'LA8'), ('L8', 1, 'L8'))
    for key, pixel_bytes, layout in layouts:
        if length % pixel_bytes != 0:
            continue
        pixel_count = length // pixel_bytes
        dims = []
        if hint_width > 0 and hint_height > 0 and (hint_width * hint_height == pixel_count):
            dims = [(hint_width, hint_height)]
        if not dims:
            dims = _factor_dimensions(pixel_count)
        for width, height in dims[:6]:
            try:
                rgba = decode_raw_layout(payload, layout, width, height)
            except Exception:
                continue
            c = _coherence(rgba, width, height)
            if c < 40.0:
                confidence = 'high' if c < 18.0 else 'medium'
                candidates.append({'format': key, 'name': key, 'width': width, 'height': height, 'confidence': confidence, 'coherence': round(c, 1), 'detail': f'raw {key}, {width}x{height}, coherence {c:.1f}', 'decode': True})
            continue
    candidates.sort(key=lambda item: item['coherence'])
    return candidates

def decode_raw_layout(payload: bytes, layout: str, width: int, height: int) -> bytes:
    """Decode a raw pixel layout into RGBA8 (used by candidate analysis)."""
    count = width * height
    out = bytearray(count * 4)
    if layout == 'RGBA':
        for i in range(count):
            base = i * 4
            out[i * 4] = payload[base]
            out[i * 4 + 1] = payload[base + 1]
            out[i * 4 + 2] = payload[base + 2]
            out[i * 4 + 3] = payload[base + 3]
    elif layout == 'BGRA':
        for i in range(count):
            base = i * 4
            out[i * 4] = payload[base + 2]
            out[i * 4 + 1] = payload[base + 1]
            out[i * 4 + 2] = payload[base]
            out[i * 4 + 3] = payload[base + 3]
    elif layout == 'ARGB':
        for i in range(count):
            base = i * 4
            out[i * 4] = payload[base + 1]
            out[i * 4 + 1] = payload[base + 2]
            out[i * 4 + 2] = payload[base + 3]
            out[i * 4 + 3] = payload[base]
    elif layout == 'RGB':
        for i in range(count):
            base = i * 3
            out[i * 4] = payload[base]
            out[i * 4 + 1] = payload[base + 1]
            out[i * 4 + 2] = payload[base + 2]
            out[i * 4 + 3] = 255
    elif layout == 'RGBA4':
        for i in range(count):
            value = struct.unpack_from('<H', payload, i * 2)[0]
            out[i * 4] = (value >> 12 & 15) * 17
            out[i * 4 + 1] = (value >> 8 & 15) * 17
            out[i * 4 + 2] = (value >> 4 & 15) * 17
            out[i * 4 + 3] = (value & 15) * 17
    elif layout == 'RGB565':
        for i in range(count):
            value = struct.unpack_from('<H', payload, i * 2)[0]
            red = value >> 11 & 31
            green = value >> 5 & 63
            blue = value & 31
            out[i * 4] = red << 3 | red >> 2
            out[i * 4 + 1] = green << 2 | green >> 4
            out[i * 4 + 2] = blue << 3 | blue >> 2
            out[i * 4 + 3] = 255
    elif layout == 'RGB565SWAP':
        for i in range(count):
            value = struct.unpack_from('>H', payload, i * 2)[0]
            red = value >> 11 & 31
            green = value >> 5 & 63
            blue = value & 31
            out[i * 4] = red << 3 | red >> 2
            out[i * 4 + 1] = green << 2 | green >> 4
            out[i * 4 + 2] = blue << 3 | blue >> 2
            out[i * 4 + 3] = 255
    elif layout == 'RGBA5551':
        for i in range(count):
            value = struct.unpack_from('<H', payload, i * 2)[0]
            red = value >> 11 & 31
            green = value >> 6 & 31
            blue = value >> 1 & 31
            out[i * 4] = red << 3 | red >> 2
            out[i * 4 + 1] = green << 3 | green >> 2
            out[i * 4 + 2] = blue << 3 | blue >> 2
            out[i * 4 + 3] = 255 if value & 1 else 0
    elif layout == 'LA8':
        for i in range(count):
            out[i * 4] = payload[i * 2]
            out[i * 4 + 1] = payload[i * 2]
            out[i * 4 + 2] = payload[i * 2]
            out[i * 4 + 3] = payload[i * 2 + 1]
    elif layout == 'L8':
        for i in range(count):
            value = payload[i]
            out[i * 4] = value
            out[i * 4 + 1] = value
            out[i * 4 + 2] = value
            out[i * 4 + 3] = 255
    else:
        raise ValueError(f'unknown raw layout {layout}')
    return bytes(out)

def analyze_payload(
    payload: bytes,
    hint_width: int = 0,
    hint_height: int = 0,
    prefer: tuple[str, ...] = (),
) -> dict:
    """Analyze unknown bytes and return ranked decode candidates.

    Order of investigation: container signatures -> exact block-compressed
    length matches -> raw pixel layouts.  Every candidate carries a
    confidence level and a human-readable detail string; the caller decides
    what to offer.  ``prefer`` lists format keys the caller already knows the
    game uses (e.g. the ETC family from an NBA 2K IFF) -- decode-capable
    candidates in that family are ranked first, since length + coherence
    alone cannot always separate two block formats.  Nothing is ever
    reported as a hard failure here -- ``unknown`` is a legitimate result
    when no interpretation fits.
    """
    candidates = []
    info = detect_container(payload)
    if info is not None:
        if info.get('format') != 'EXR':
            candidates.append({'format': info['format'], 'name': info['name'], 'width': info['width'], 'height': info['height'], 'confidence': info.get('confidence', 'high'), 'detail': f"{info['name']} container, {info['width']}x{info['height']}, {info.get('mip_count', 1)} mip(s)", 'decode': bool(info.get('decode_support'))})
    if len(payload) >= 8 and len(payload) % 8 == 0:
        for fmt_key in ('DXT1', 'DXT3', 'DXT5', 'BC4', 'BC5', 'ETC1', 'ETC2', 'ETC2A8', 'EACR', 'EACRG', 'BC6H', 'BC7'):
            block_bytes = block_bytes_per_block(fmt_key)
            blocks = len(payload) // block_bytes
            if blocks <= 0 or blocks * block_bytes != len(payload):
                continue
            block_dims = _factor_dimensions(blocks)
            for blocks_wide, blocks_high in block_dims[:4]:
                width = blocks_wide * 4
                height = blocks_high * 4
                if max(1, (width + 3) // 4) * max(1, (height + 3) // 4) != blocks:
                    continue
                decoder = block_decoder(fmt_key)
                detail = f'{format_name(fmt_key)}, {width}x{height} (exact block count match)'
                if decoder is not None:
                    try:
                        rgba = decoder(payload, width, height)
                        c = _coherence(rgba, width, height)
                        confidence = 'high' if c < 18.0 else 'medium' if c < 40.0 else 'low'
                        detail += f', coherence {c:.1f}'
                    except Exception:
                        confidence = 'low'
                else:
                    confidence = 'medium'
                candidates.append({'format': fmt_key, 'name': format_name(fmt_key), 'width': width, 'height': height, 'confidence': confidence, 'detail': detail, 'decode': decoder is not None})
    candidates.extend(_raw_candidates(payload, hint_width, hint_height))
    order = {'high': 0, 'medium': 1, 'low': 2}
    prefer_index = {fmt: index for index, fmt in enumerate(prefer)}
    candidates.sort(key=lambda item: (prefer_index.get(item.get('format'), len(prefer_index)), 0 if item.get('decode') else 1, order.get(item.get('confidence', 'low'), 2), item.get('coherence', 999.0)))
    if not candidates:
        return {'status': 'unknown', 'candidates': [], 'best': None, 'message': 'no recognizable texture signature, size match, or coherent pixel layout'}
    best = candidates[0]
    return {'status': 'candidates', 'candidates': candidates[:8], 'best': best, 'message': f"{best['name']} ({best['confidence']} confidence)"}
_install_decoders()

def decode_candidate(payload: bytes, fmt_key: str, width: int, height: int) -> bytes:
    """Decode ``payload`` as a specific candidate format into RGBA8.

    Raises a clear error when the format has no decoder on this platform or
    the payload length does not match the requested dimensions.
    """
    if fmt_key in ('TGA24', 'TGA32', 'TGAGRAY'):
        w, h, rgba = decode_tga(payload)
        return rgba
    if fmt_key in ('BMP24', 'BMP32'):
        w, h, rgba = decode_bmp(payload)
        return rgba
    if fmt_key == 'HDR':
        w, h, rgba = decode_rgbe(payload)
        return rgba
    if fmt_key == 'PNG':
        from . import pngio
        w, h, rgba = pngio.read_png_rgba(payload)
        return rgba
    if fmt_key in _BLOCK_FORMATS:
        decoder = block_decoder(fmt_key)
        if decoder is None:
            raise ValueError(f'{format_name(fmt_key)} is detected but has no decoder on this platform')
        expected = block_payload_size(fmt_key, width, height)
        if len(payload) < expected:
            raise ValueError(f'{format_name(fmt_key)} needs {expected} bytes for {width}x{height}, but the resource only has {len(payload)}')
        return decoder(payload[:expected], width, height)
    if fmt_key in ('RGBA8888', 'BGRA8888', 'ARGB8888', 'RGB888', 'RGBA4444', 'RGB565', 'R5G6B5_SWAP', 'RGBA5551', 'LA88', 'L8'):
        layout = {'RGBA8888': 'RGBA', 'BGRA8888': 'BGRA', 'ARGB8888': 'ARGB', 'RGB888': 'RGB', 'RGBA4444': 'RGBA4', 'RGB565': 'RGB565', 'R5G6B5_SWAP': 'RGB565SWAP', 'RGBA5551': 'RGBA5551', 'LA88': 'LA8', 'L8': 'L8'}[fmt_key]
        return decode_raw_layout(payload, layout, width, height)
    raise ValueError(f'unknown format {fmt_key}')
